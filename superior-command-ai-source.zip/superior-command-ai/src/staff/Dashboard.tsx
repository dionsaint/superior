import { useState } from 'react'
import { AlertTriangle, ArrowRight, Bot, CalendarCheck, CheckCircle2, Clock, FileWarning, Inbox, ListChecks, MessageSquareReply, PhoneMissed, Sparkles, UserCheck } from 'lucide-react'
import { useStore } from '../store'
import { STAGES, memberLabel, setStage, srcLabel } from '../actions'
import { attention, fmtMinutes, metrics, vName } from '../logic'
import { ago, fmtWhen } from '../time'
import type { LeadSource, Stage } from '../types'
import { Avatar, Badge, Btn, Card, CardHead, DemoTag, Help, PageTitle, Select, cx } from '../ui'

export function Dashboard() {
  const { s, act, nav } = useStore()
  const m = metrics(s)
  const a = attention(s)
  const [drag, setDrag] = useState<string | null>(null)
  const [over, setOver] = useState<Stage | null>(null)

  const queue = [
    { n: a.missed.length, icon: Inbox, tone: 'red', title: 'Customers waiting for a first reply', plain: 'Missed leads', go: () => nav('leads', a.missed[0]?.id) },
    { n: a.callbacks.length, icon: PhoneMissed, tone: 'red', title: 'Callback requests', plain: 'Someone asked us to call back', go: () => nav('leads', a.callbacks[0]?.id) },
    { n: a.missingDocs.length, icon: FileWarning, tone: 'amber', title: 'Deal files missing documents', plain: 'Paperwork gaps that could delay a sale', go: () => nav('deals', a.missingDocs[0]?.id) },
    { n: a.approvals.length, icon: MessageSquareReply, tone: 'amber', title: 'AI replies waiting for your OK', plain: 'Follow-ups awaiting approval', go: () => nav('leads', a.approvals[0]?.id) },
    { n: a.listing.length, icon: AlertTriangle, tone: 'blue', title: 'Website listings that need fixing', plain: 'Missing price, miles, photos, etc.', go: () => nav('listings') },
  ]

  const tiles = [
    { label: 'New inquiries (24h)', plain: 'Inbound leads', value: m.inbound, icon: Inbox },
    { label: 'Avg. time to first reply', plain: 'First response time', value: m.responded ? fmtMinutes(m.avgResponse) : '—', icon: Clock },
    { label: 'Test drives booked', plain: 'Appointments', value: m.appts, icon: CalendarCheck },
    { label: 'Deals stuck or waiting', plain: 'Open deal blockers', value: m.blockers, icon: FileWarning },
  ]

  const bySource = (['website', 'phone', 'email', 'facebook', 'offerup', 'walkin'] as LeadSource[]).map((k) => ({ k, n: s.leads.filter((l) => l.source === k).length }))
  const maxSrc = Math.max(1, ...bySource.map((x) => x.n))
  const openTasks = s.tasks.filter((t) => t.status !== 'done')

  return (
    <div>
      <PageTitle
        kicker="Owner command dashboard"
        title="Good morning — here's your dealership today"
        plain="Everything that needs a person's attention, in one place. The AI handles routine busywork and flags the rest. All numbers here are sample data."
      />

      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4" data-tour="kpis">
        {tiles.map((t) => {
          const I = t.icon
          return (
            <Card key={t.label} className="p-4">
              <div className="flex items-center justify-between">
                <span className="grid h-8 w-8 place-items-center rounded-lg bg-brand-50 text-brand-600"><I className="h-4 w-4" /></span>
                <DemoTag />
              </div>
              <div className="mt-3 text-3xl font-black tracking-tight">{t.value}</div>
              <div className="text-[13px] font-semibold text-ink-800">{t.label}</div>
              <div className="text-[11px] text-ink-400">{t.plain}</div>
            </Card>
          )
        })}
      </div>

      <div className="mt-5 grid gap-5 xl:grid-cols-[minmax(0,1.1fr)_minmax(0,1fr)]">
        <Card data-tour="attention">
          <CardHead icon={<ListChecks className="h-4 w-4" />} title="Today needs attention" sub="Most urgent first. Tap any row to jump straight to it." right={<DemoTag />} />
          <div className="divide-y divide-silver-100">
            {queue.map((q) => {
              const I = q.icon
              return (
                <button key={q.title} onClick={q.go} disabled={!q.n} className="flex w-full items-center gap-4 px-5 py-3.5 text-left transition hover:bg-silver-50 disabled:opacity-50">
                  <span className={cx('grid h-10 w-10 shrink-0 place-items-center rounded-xl text-lg font-black', q.n === 0 ? 'bg-emerald-50 text-emerald-700' : q.tone === 'red' ? 'bg-brand-600 text-white' : q.tone === 'amber' ? 'bg-amber-100 text-amber-800' : 'bg-sky-100 text-sky-800')}>
                    {q.n === 0 ? <CheckCircle2 className="h-5 w-5" /> : q.n}
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="block text-sm font-semibold">{q.title}</span>
                    <span className="block text-[12px] text-ink-500">{q.plain}</span>
                  </span>
                  <I className="h-4 w-4 text-ink-400" />
                  <ArrowRight className="h-4 w-4 text-ink-400" />
                </button>
              )
            })}
          </div>
        </Card>

        <Card>
          <CardHead icon={<Bot className="h-4 w-4" />} title="What the AI handled today" sub={<><span className="inline-flex items-center gap-1"><CheckCircle2 className="h-3 w-3 text-emerald-600" />done automatically (simulated)</span> · <span className="inline-flex items-center gap-1"><UserCheck className="h-3 w-3 text-amber-600" />needs a person</span></>} />
          <ol className="scroll-thin max-h-[340px] overflow-y-auto px-5 py-3">
            {s.audit.filter((e) => e.actor.startsWith('AI')).slice(0, 14).map((e) => (
              <li key={e.id} className="relative flex gap-3 pb-3 pl-1">
                <span className={cx('mt-0.5 grid h-5 w-5 shrink-0 place-items-center rounded-full', e.done ? 'bg-emerald-100 text-emerald-700' : 'bg-amber-100 text-amber-700')}>
                  {e.done ? <CheckCircle2 className="h-3.5 w-3.5" /> : <UserCheck className="h-3.5 w-3.5" />}
                </span>
                <div className="min-w-0 flex-1">
                  <button onClick={() => e.link && nav(e.link.screen, e.link.id)} className="text-left text-[13px] leading-snug hover:text-brand-700">{e.text}</button>
                  <div className="text-[11px] text-ink-400">{ago(e.at, s.now)} · {e.done ? 'Completed (demo)' : 'Recommended — staff action'}</div>
                </div>
              </li>
            ))}
          </ol>
        </Card>
      </div>

      <Card className="mt-5" data-tour="pipeline">
        <CardHead title="Sales pipeline" sub="Drag a customer card to a new column (or use the dropdown on phones). Counts update everywhere." right={<DemoTag>Sample leads</DemoTag>} />
        <div className="scroll-thin grid auto-cols-[minmax(190px,1fr)] grid-flow-col gap-3 overflow-x-auto p-4">
          {STAGES.map((st) => {
            const items = s.leads.filter((l) => l.stage === st.id)
            return (
              <div
                key={st.id}
                onDragOver={(e) => { e.preventDefault(); setOver(st.id) }}
                onDragLeave={() => setOver(null)}
                onDrop={() => { if (drag) act((x, c) => setStage(x, c, drag, st.id)); setDrag(null); setOver(null) }}
                className={cx('rounded-xl border p-2 transition', over === st.id ? 'border-brand-600 bg-brand-50' : 'border-silver-200 bg-panel-soft')}
              >
                <div className="mb-2 flex items-center justify-between px-1">
                  <span className="text-[12px] font-bold uppercase tracking-wide text-ink-700">{st.label}</span>
                  <span className={cx('rounded-full px-2 text-[12px] font-bold', st.id === 'sold' ? 'bg-emerald-100 text-emerald-700' : st.id === 'lost' ? 'bg-silver-200 text-ink-500' : 'bg-white text-ink-800 ring-1 ring-silver-200')}>{items.length}</span>
                </div>
                <div className="space-y-2">
                  {items.slice(0, 6).map((l) => (
                    <div key={l.id} draggable onDragStart={() => setDrag(l.id)} className="cursor-grab rounded-lg border border-silver-200 bg-white p-2.5 shadow-sm active:cursor-grabbing">
                      <div className="flex items-center justify-between gap-2">
                        <button onClick={() => nav('leads', l.id)} className="truncate text-left text-[13px] font-semibold hover:text-brand-700">{l.name}</button>
                        <Avatar id={l.assignedTo} />
                      </div>
                      <div className="truncate text-[11px] text-ink-500">{vName(s.vehicles.find((v) => v.id === l.vehicleId))}</div>
                      <div className="mt-1.5 flex items-center justify-between gap-1">
                        <Badge tone={l.missed ? 'red' : 'gray'}>{srcLabel(l.source)}</Badge>
                        <select aria-label="Move stage" value={l.stage} onChange={(e) => act((x, c) => setStage(x, c, l.id, e.target.value as Stage))} className="rounded border border-silver-200 bg-white text-[11px] lg:hidden">
                          {STAGES.map((o) => <option key={o.id} value={o.id}>{o.label}</option>)}
                        </select>
                      </div>
                    </div>
                  ))}
                  {items.length > 6 && <div className="text-center text-[11px] text-ink-500">+{items.length - 6} more</div>}
                </div>
              </div>
            )
          })}
        </div>
      </Card>

      <div className="mt-5 grid gap-5 xl:grid-cols-[minmax(0,1.3fr)_minmax(0,1fr)]">
        <Card>
          <CardHead title="Team workboard" sub="Who owns what, what's next, and when it's due. Roles shown instead of real names." />
          <div className="grid gap-3 p-4 sm:grid-cols-2 xl:grid-cols-4">
            {s.members.map((mb) => {
              const mine = openTasks.filter((t) => t.owner === mb.id)
              return (
                <div key={mb.id} className="rounded-xl border border-silver-200 bg-panel-soft p-3">
                  <div className="mb-2 flex items-center gap-2">
                    <Avatar id={mb.id} size="md" />
                    <div>
                      <div className="text-[13px] font-bold">{mb.label}</div>
                      <div className="text-[11px] text-ink-500">{mine.length} open</div>
                    </div>
                  </div>
                  <div className="space-y-1.5">
                    {mine.slice(0, 4).map((t) => (
                      <button key={t.id} onClick={() => nav(t.link.screen, t.link.id)} className="block w-full rounded-lg bg-white p-2 text-left ring-1 ring-silver-200 hover:ring-brand-600">
                        <div className="text-[12px] font-semibold leading-snug">{t.title}</div>
                        <div className="mt-1 flex items-center justify-between">
                          <span className="text-[10px] text-ink-500">Due {fmtWhen(t.due, s.now)}</span>
                          <Badge tone={t.status === 'awaiting-approval' ? 'amber' : t.status === 'in-progress' ? 'blue' : 'gray'}>{t.status === 'awaiting-approval' ? 'Needs OK' : t.status === 'in-progress' ? 'Doing' : 'To do'}</Badge>
                        </div>
                        {t.createdBy === 'ai' && <div className="mt-1 text-[10px] font-semibold text-violet-700">Created by AI (demo)</div>}
                      </button>
                    ))}
                    {!mine.length && <div className="rounded-lg bg-white p-2 text-center text-[12px] text-emerald-700 ring-1 ring-silver-200">All clear</div>}
                  </div>
                </div>
              )
            })}
          </div>
        </Card>
        <Card>
          <CardHead title="Where inquiries come from" sub="All channels land in one inbox." right={<DemoTag />} />
          <div className="space-y-2.5 p-5">
            {bySource.map((b) => (
              <div key={b.k} className="flex items-center gap-3">
                <span className="w-28 text-[12px] font-semibold text-ink-700">{srcLabel(b.k)}</span>
                <div className="h-6 flex-1 overflow-hidden rounded-md bg-silver-100">
                  <div className="h-full rounded-md bg-brand-600 transition-all duration-500" style={{ width: `${(b.n / maxSrc) * 100}%` }} />
                </div>
                <span className="w-6 text-right text-sm font-bold">{b.n}</span>
              </div>
            ))}
            <p className="pt-1 text-[11px] text-ink-500">Facebook Marketplace & OfferUp connections depend on partner approval — shown here as manual entry.</p>
          </div>
        </Card>
      </div>

      <BeforeAfter />
    </div>
  )
}

export function BeforeAfter() {
  const rows = [
    ['A shopper messages at 8:45 PM', 'Seen next morning. Shopper may have moved on.', 'Instant, honest reply from listing info + test-drive times offered. Staff confirm at opening.', '~12 hrs → ~1 min'],
    ['A call is missed', 'Voicemail sits until someone checks it.', 'Caller logged, callback text drafted. Manager taps "approve".', '~2 hrs → ~10 min'],
    ['A listing has no price or miles', 'Nobody notices until a shopper asks.', 'Flagged overnight with a task to verify and fix. Website updates on approval.', 'Weeks → same day'],
    ['A deal is missing a signature', 'Found at delivery or when the title gets rejected.', 'Caught by the checklist; task opened; customer request drafted for approval.', 'Days → hours'],
    ['Following up with shoppers', 'Depends on memory and sticky notes.', 'Follow-ups drafted on schedule, sent only with consent and approval.', 'Missed → tracked'],
  ]
  return (
    <Card className="mt-5" data-tour="before-after">
      <CardHead icon={<Sparkles className="h-4 w-4" />} title="Before AI vs. with AI" sub="How common busywork changes. Time figures are rough estimates to be measured in a pilot — not promises." right={<DemoTag>Estimates</DemoTag>} />
      <div className="scroll-thin overflow-x-auto">
        <table className="w-full min-w-[720px] text-[13px]">
          <thead>
            <tr className="text-left text-[11px] uppercase tracking-wide text-ink-500">
              <th className="px-5 py-2.5">Situation</th>
              <th className="px-3 py-2.5">Today (manual)</th>
              <th className="px-3 py-2.5 text-brand-700">With Superior Command AI</th>
              <th className="px-5 py-2.5">Est. change</th>
            </tr>
          </thead>
          <tbody>
            {rows.map((r) => (
              <tr key={r[0]} className="border-t border-silver-100 align-top">
                <td className="px-5 py-3 font-semibold">{r[0]}</td>
                <td className="px-3 py-3 text-ink-500">{r[1]}</td>
                <td className="px-3 py-3"><span className="inline-flex gap-1.5"><CheckCircle2 className="mt-0.5 h-4 w-4 shrink-0 text-emerald-600" />{r[2]}</span></td>
                <td className="px-5 py-3"><Badge tone="green">{r[3]}</Badge></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="p-4"><Help>The AI does the typing and checking. People still make the decisions — every customer message about paperwork, and every outreach without consent, waits for a human "OK".</Help></div>
    </Card>
  )
}

export { memberLabel, Select }
