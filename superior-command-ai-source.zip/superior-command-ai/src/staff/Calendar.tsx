import { useMemo, useState } from 'react'
import { BellRing, CalendarDays, Check, ChevronRight, Play, Plus, ShieldCheck, Sparkles, Workflow, Zap } from 'lucide-react'
import { useStore } from '../store'
import type { Appointment, Rule } from '../types'
import { assignLead, bookTestDrive, log, memberLabel, simulateLead, uid } from '../actions'
import { attention, vName, vehicleIssues } from '../logic'
import { DOW_NAMES, addMin, dateOf, dow, fmtDay, fmtTime, minutesOfDay, toMs } from '../time'
import { Avatar, Badge, Btn, Card, CardHead, DemoTag, Field, Help, Input, Modal, PageTitle, Select, Tabs, Toggle, cx } from '../ui'

export function CalendarScreen() {
  const [tab, setTab] = useState<'cal' | 'journey' | 'rules'>('cal')
  return (
    <div>
      <PageTitle kicker="Appointments & task automation" title="Calendar & Rules" plain="Test drives, callbacks and deliveries on one team calendar (Eastern Time). Simple rules decide what the AI may do on its own and what needs a person's OK." />
      <div className="mb-4"><Tabs value={tab} onChange={setTab} items={[{ id: 'cal', label: 'Team calendar' }, { id: 'journey', label: 'Watch a customer journey' }, { id: 'rules', label: 'Automation rules' }]} /></div>
      {tab === 'cal' ? <WeekCalendar /> : tab === 'journey' ? <Journey /> : <Rules />}
    </div>
  )
}

function WeekCalendar() {
  const { s, act, nav } = useStore()
  const [sel, setSel] = useState<Appointment | null>(null)
  const monday = useMemo(() => { const d = dow(s.now); return dateOf(addMin(s.now, -((d + 6) % 7) * 1440)) }, [s.now])
  const days = Array.from({ length: 6 }, (_, i) => dateOf(addMin(`${monday}T12:00`, i * 1440)))
  const H0 = 9, H1 = 18, PX = 52
  const nowMin = minutesOfDay(s.now)
  return (
    <div className="grid gap-4 xl:grid-cols-[1fr_300px]">
      <Card className="overflow-hidden" data-tour="calendar">
        <CardHead icon={<CalendarDays className="h-4 w-4" />} title={`Week of ${fmtDay(`${monday}T12:00`)}`} sub="Eastern Time · St. Petersburg, FL · gray = closed" right={<DemoTag>Sample schedule</DemoTag>} />
        <div className="scroll-thin overflow-x-auto">
          <div className="grid min-w-[760px]" style={{ gridTemplateColumns: `52px repeat(6, 1fr)` }}>
            <div />
            {days.map((d) => (
              <div key={d} className={cx('border-b border-l border-silver-100 py-2 text-center text-[12px] font-bold', d === dateOf(s.now) ? 'bg-brand-50 text-brand-700' : 'text-ink-700')}>{fmtDay(`${d}T12:00`)}</div>
            ))}
            <div className="relative" style={{ height: (H1 - H0) * PX }}>
              {Array.from({ length: H1 - H0 }, (_, i) => <div key={i} className="absolute right-1 text-[10px] text-ink-400" style={{ top: i * PX - 6 }}>{((H0 + i) % 12) || 12}{H0 + i < 12 ? 'a' : 'p'}</div>)}
            </div>
            {days.map((d) => {
              const h = s.hours[dow(`${d}T12:00`)]
              const [oh] = h ? h.open.split(':').map(Number) : [0]
              const [ch] = h ? h.close.split(':').map(Number) : [0]
              return (
                <div key={d} className="relative border-l border-silver-100" style={{ height: (H1 - H0) * PX }}>
                  {Array.from({ length: H1 - H0 }, (_, i) => <div key={i} className={cx('absolute inset-x-0 border-t border-silver-100', (!h || H0 + i < oh || H0 + i >= ch) && 'bg-silver-100/70')} style={{ top: i * PX, height: PX }} />)}
                  {d === dateOf(s.now) && nowMin >= H0 * 60 && nowMin <= H1 * 60 && <div className="absolute inset-x-0 z-10 border-t-2 border-brand-600" style={{ top: ((nowMin - H0 * 60) / 60) * PX }}><span className="absolute -left-1 -top-1 h-2 w-2 rounded-full bg-brand-600" /></div>}
                  {s.appointments.filter((a) => dateOf(a.start) === d).map((a) => {
                    const top = ((minutesOfDay(a.start) - H0 * 60) / 60) * PX
                    return (
                      <button key={a.id} onClick={() => setSel(a)} className={cx('absolute inset-x-1 z-20 overflow-hidden rounded-lg px-2 py-1 text-left text-[11px] shadow-sm ring-1 transition hover:z-30 hover:shadow-md', a.status === 'hold' ? 'bg-amber-50 text-amber-900 ring-amber-300 [background-image:repeating-linear-gradient(45deg,transparent,transparent_6px,rgba(217,119,6,.08)_6px,rgba(217,119,6,.08)_12px)]' : a.status === 'attended' ? 'bg-emerald-50 text-emerald-900 ring-emerald-200' : a.status === 'no-show' ? 'bg-silver-100 text-ink-500 ring-silver-200 line-through' : a.kind === 'Delivery' ? 'bg-ink-900 text-white ring-ink-900' : 'bg-brand-600 text-white ring-brand-700')} style={{ top, height: (a.duration / 60) * PX - 3 }}>
                        <div className="font-bold">{fmtTime(a.start)} {a.kind}</div>
                        <div className="truncate opacity-90">{a.customer}{a.status === 'hold' ? ' · to confirm' : ''}</div>
                      </button>
                    )
                  })}
                </div>
              )
            })}
          </div>
        </div>
      </Card>
      <div className="space-y-4">
        <Card className="p-4">
          <div className="mb-2 text-sm font-bold">Upcoming</div>
          <div className="space-y-2">
            {[...s.appointments].filter((a) => toMs(a.start) >= toMs(s.now) - 3600000).sort((a, b) => toMs(a.start) - toMs(b.start)).slice(0, 6).map((a) => (
              <button key={a.id} onClick={() => setSel(a)} className="flex w-full items-center gap-2 rounded-lg p-2 text-left ring-1 ring-silver-200 hover:ring-brand-600">
                <Avatar id={a.salesperson} />
                <div className="min-w-0 flex-1">
                  <div className="truncate text-[13px] font-semibold">{a.customer} · {a.kind}</div>
                  <div className="text-[11px] text-ink-500">{fmtDay(a.start)} {fmtTime(a.start)}{a.status === 'hold' && ' · requested'}</div>
                </div>
                {a.reminder === 'queued' && <BellRing className="h-3.5 w-3.5 text-ink-400" />}
              </button>
            ))}
          </div>
        </Card>
        <Help>Striped amber = requested online, waiting for staff to confirm. Reminders only queue when the customer agreed to texts — and nothing is actually sent in this demo.</Help>
      </div>
      <Modal open={!!sel} onClose={() => setSel(null)} title={sel ? `${sel.kind} · ${sel.customer}` : ''}>
        {sel && (() => {
          const a = s.appointments.find((x) => x.id === sel.id) ?? sel
          const v = s.vehicles.find((x) => x.id === a.vehicleId)
          const upd = (p: Partial<Appointment>, msg: string) => act((st, c) => { const x = st.appointments.find((y) => y.id === a.id)!; Object.assign(x, p); log(st, 'change', `${a.customer}: ${msg}`, true, { screen: 'calendar' }); c.toast(msg, 'ok') })
          return (
            <div className="space-y-3 text-sm">
              <div className="grid grid-cols-2 gap-3">
                <div><div className="text-[11px] text-ink-500">When</div><div className="font-semibold">{fmtDay(a.start)} · {fmtTime(a.start)} ET</div></div>
                <div><div className="text-[11px] text-ink-500">With</div><div className="font-semibold">{memberLabel(s, a.salesperson)}</div></div>
                <div><div className="text-[11px] text-ink-500">Vehicle</div><div className="font-semibold">{vName(v)}</div></div>
                <div><div className="text-[11px] text-ink-500">Reminder</div><div className="font-semibold">{a.reminder === 'queued' ? 'Queued (demo, not sent)' : 'Off'}</div></div>
              </div>
              <div className="rounded-lg bg-silver-50 p-2 text-[13px]">{a.notes}</div>
              <div className="flex flex-wrap gap-2">
                {a.status === 'hold' && <Btn size="sm" variant="primary" onClick={() => upd({ status: 'booked' }, 'Appointment confirmed')}>Confirm time</Btn>}
                <Btn size="sm" variant="success" onClick={() => upd({ status: 'attended' }, 'Attendance logged — follow-up queued for approval')}>Mark attended</Btn>
                <Btn size="sm" onClick={() => upd({ status: 'no-show' }, 'Marked no-show')}>No-show</Btn>
                {a.leadId && <Btn size="sm" variant="ghost" onClick={() => { setSel(null); nav('leads', a.leadId!) }}>Open conversation</Btn>}
              </div>
            </div>
          )
        })()}
      </Modal>
    </div>
  )
}

const STEPS = ['Inquiry arrives', 'Lead created', 'Time offered', 'Customer accepts', 'Reminder queued', 'Handed to salesperson', 'Attendance logged', 'Follow-up queued']

function Journey() {
  const { s, act, get } = useStore()
  const [step, setStep] = useState(-1)
  const [leadId, setLeadId] = useState<string | null>(null)
  const [log2, setLog] = useState<string[]>([])
  const run = (i: number) => {
    const add = (t: string) => setLog((l) => [...l, t])
    if (i === 0) add('A shopper asks on the website: "Could I test drive the Kia Soul this week?"')
    if (i === 1) act((st, c) => { const id = simulateLead(st, c, 4); setLeadId(id); add(`Lead created in the inbox: ${st.leads[0].name} (website, SMS consent ✓)`) })
    if (i === 2) { const l = get().leads.find((x) => x.id === leadId); add(`AI offers the next open times from the calendar to ${l?.name}.`) }
    if (i === 3 && leadId) act((st, c) => { bookTestDrive(st, c, leadId); const a = st.appointments[st.appointments.length - 1]; add(`Customer picks ${fmtDay(a.start)} ${fmtTime(a.start)} → appointment card created.`) })
    if (i === 4) add('Reminder queued for the day before (allowed: consent ✓, outside quiet hours ✓). Demo — nothing sent.')
    if (i === 5 && leadId) { const l = get().leads.find((x) => x.id === leadId); if (!l?.assignedTo) act((st, c) => assignLead(st, c, leadId)); add(`Handed to ${memberLabel(get(), get().leads.find((x) => x.id === leadId)?.assignedTo ?? null)} with notes.`) }
    if (i === 6 && leadId) act((st, c) => { const a = [...st.appointments].reverse().find((x) => x.leadId === leadId); if (a) a.status = 'attended'; log(st, 'change', 'Attendance logged', true, { screen: 'calendar' }); c.toast('Attendance logged', 'ok'); add('Customer showed up — attendance logged.') })
    if (i === 7 && leadId) act((st, c) => { const l = st.leads.find((x) => x.id === leadId)!; l.draft = `Hi ${l.name.split(' ')[0]}, thanks for coming by to drive the Soul today! Any questions I can answer? Reply STOP to opt out. (AI assistant)`; l.stage = 'negotiating'; log(st, 'suggestion', `Follow-up drafted for ${l.name} — awaiting approval`, false, { screen: 'leads', id: l.id }); c.toast('Follow-up drafted — waiting for staff approval', 'info'); add('Thank-you follow-up drafted and waiting for a person to approve.') })
    setStep(i)
  }
  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_380px]">
      <Card>
        <CardHead icon={<Workflow className="h-4 w-4" />} title="From first question to follow-up" sub="Press Next to walk through one shopper's journey. Each step really changes the inbox and calendar." right={<Btn size="sm" variant="primary" icon={<Play className="h-4 w-4" />} disabled={step >= STEPS.length - 1} onClick={() => run(step + 1)}>{step < 0 ? 'Start' : 'Next step'}</Btn>} />
        <ol className="grid gap-2 p-5 sm:grid-cols-2">
          {STEPS.map((t, i) => (
            <li key={t} className={cx('flex items-center gap-3 rounded-xl border p-3 transition', i <= step ? 'border-emerald-200 bg-emerald-50' : i === step + 1 ? 'border-brand-200 bg-brand-50' : 'border-silver-200')}>
              <span className={cx('grid h-7 w-7 shrink-0 place-items-center rounded-full text-[12px] font-bold', i <= step ? 'bg-emerald-600 text-white' : 'bg-silver-100 text-ink-500')}>{i <= step ? <Check className="h-4 w-4" /> : i + 1}</span>
              <span className="text-[13px] font-semibold">{t}</span>
              {i === step + 1 && <ChevronRight className="ml-auto h-4 w-4 text-brand-600" />}
            </li>
          ))}
        </ol>
      </Card>
      <Card className="p-4">
        <div className="mb-2 text-sm font-bold">What just happened</div>
        {log2.length === 0 ? <p className="text-[13px] text-ink-500">Press Start.</p> : <ol className="space-y-2 text-[13px]">{log2.map((l, i) => <li key={i} className="rise flex gap-2"><span className="font-bold text-brand-600">{i + 1}.</span>{l}</li>)}</ol>}
        {step >= STEPS.length - 1 && <Btn size="sm" className="mt-3" onClick={() => { setStep(-1); setLog([]); setLeadId(null) }}>Run again</Btn>}
      </Card>
    </div>
  )
}

const TRIGGERS = ['New inbound lead', 'Missed inbound call', 'Appointment in 24h', 'Deal checklist item missing', 'Listing scan', 'Lead unanswered']

function Rules() {
  const { s, act, can } = useStore()
  const [edit, setEdit] = useState<Rule | null>(null)
  const preview = (r: Rule): string[] => {
    const a = attention(s)
    if (r.trigger === 'Listing scan') return s.vehicles.filter((v) => !v.archived && (r.conditions.toLowerCase().includes('mileage') ? v.mileage == null : vehicleIssues(v, s.vehicles).length)).map((v) => `${v.stock} ${v.year} ${v.make} ${v.model} → flag + task`)
    if (r.trigger === 'Missed inbound call') return s.leads.filter((l) => l.source === 'phone' && (l.missed || l.callbackRequested)).map((l) => `${l.name} → callback task + draft text (needs OK)`)
    if (r.trigger === 'Appointment in 24h') return s.appointments.filter((x) => toMs(x.start) - toMs(s.now) < 26 * 3600000 && toMs(x.start) > toMs(s.now)).map((x) => `${x.customer} ${fmtDay(x.start)} ${fmtTime(x.start)} → ${x.reminder === 'queued' ? 'reminder queued' : 'no SMS consent — skipped'}`)
    if (r.trigger === 'Deal checklist item missing') return a.missingDocs.map((d) => `Deal ${d.number} → task for document owner + draft request (needs OK)`)
    if (r.trigger === 'Lead unanswered') return a.missed.map((l) => `${l.name} → escalate to Owner`)
    return ['Next after-hours web inquiry → AI acknowledgment + 3 open times (only with consent)']
  }
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <div className="space-y-3">
        <Help>Each rule has a <b>trigger</b> (when), <b>conditions</b> (only if), an <b>action</b> (what), and whether a person must <b>approve</b> it. Green "Safe to automate" rules only create tasks or send consented, factual acknowledgments.</Help>
        {s.rules.map((r) => (
          <Card key={r.id} className="p-4">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="flex items-center gap-2 text-[14px] font-bold"><Zap className="h-4 w-4 text-brand-600" />{r.name}</div>
                <div className="mt-1 text-[12px] text-ink-500"><b>When:</b> {r.trigger} · <b>If:</b> {r.conditions}</div>
                <div className="text-[12px] text-ink-500"><b>Then:</b> {r.action}</div>
              </div>
              <Toggle on={r.enabled} disabled={!can('edit:rules')} onChange={(on) => act((st, c) => { st.rules.find((x) => x.id === r.id)!.enabled = on; c.toast(`Rule ${on ? 'on' : 'off'}: ${r.name}`, 'ok') })} label={`Toggle ${r.name}`} />
            </div>
            <div className="mt-3 flex items-center justify-between">
              <Badge tone={r.review === 'auto-safe' ? 'green' : 'amber'}>{r.review === 'auto-safe' ? <><ShieldCheck className="h-3 w-3" /> Safe to automate</> : 'Staff must confirm'}</Badge>
              <Btn size="xs" variant="ghost" onClick={() => setEdit(r)}>Edit & preview</Btn>
            </div>
          </Card>
        ))}
        <Btn size="sm" icon={<Plus className="h-4 w-4" />} disabled={!can('edit:rules')} onClick={() => setEdit({ id: '', name: 'New rule', trigger: TRIGGERS[0], conditions: '', action: '', review: 'staff-confirm', enabled: false })}>New rule</Btn>
      </div>
      <Card className="self-start lg:sticky lg:top-32">
        <CardHead icon={<Sparkles className="h-4 w-4" />} title={edit ? (edit.id ? `Edit: ${edit.name}` : 'New rule') : 'Rule preview'} sub="See what a rule would do with today's sample data before turning it on." />
        {!edit ? <p className="p-5 text-[13px] text-ink-500">Choose “Edit & preview” on a rule.</p> : (
          <div className="space-y-3 p-5">
            <Field label="Name"><Input value={edit.name} onChange={(e) => setEdit({ ...edit, name: e.target.value })} /></Field>
            <Field label="Trigger (when)"><Select value={edit.trigger} onChange={(e) => setEdit({ ...edit, trigger: e.target.value })}>{TRIGGERS.map((t) => <option key={t}>{t}</option>)}</Select></Field>
            <Field label="Conditions (only if)"><Input value={edit.conditions} onChange={(e) => setEdit({ ...edit, conditions: e.target.value })} /></Field>
            <Field label="Proposed action (then)"><Input value={edit.action} onChange={(e) => setEdit({ ...edit, action: e.target.value })} /></Field>
            <Field label="Review requirement">
              <Select value={edit.review} onChange={(e) => setEdit({ ...edit, review: e.target.value as Rule['review'] })}>
                <option value="auto-safe">Safe to automate (tasks, consented acknowledgments)</option>
                <option value="staff-confirm">Staff must confirm</option>
              </Select>
            </Field>
            <div className="rounded-xl bg-silver-50 p-3">
              <div className="mb-1 text-[12px] font-bold">Would affect today ({preview(edit).length}):</div>
              <ul className="space-y-1 text-[12px] text-ink-700">{preview(edit).slice(0, 6).map((x) => <li key={x}>• {x}</li>)}{!preview(edit).length && <li className="text-ink-500">Nothing right now.</li>}</ul>
            </div>
            <div className="flex justify-end gap-2">
              <Btn variant="ghost" onClick={() => setEdit(null)}>Cancel</Btn>
              <Btn variant="primary" disabled={!can('edit:rules')} onClick={() => { act((st, c) => { if (edit.id) Object.assign(st.rules.find((x) => x.id === edit.id)!, edit); else st.rules.push({ ...edit, id: uid(st, 'r') }); log(st, 'change', `Rule saved: ${edit.name}`, true, { screen: 'calendar' }); c.toast('Rule saved', 'ok') }); setEdit(null) }}>Save rule</Btn>
            </div>
          </div>
        )}
      </Card>
    </div>
  )
}

export { DOW_NAMES }
