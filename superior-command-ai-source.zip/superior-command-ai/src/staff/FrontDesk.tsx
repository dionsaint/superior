import { useEffect, useRef, useState } from 'react'
import { Bot, Mic, Phone, PhoneCall, Play, RotateCcw, Send, ShieldCheck, User } from 'lucide-react'
import { useStore } from '../store'
import type { Wall } from '../types'
import { conciergeReply, isOffHours, isPublic, priceLabel, milesLabel } from '../logic'
import { fmtDay, fmtTime, nextSlots } from '../time'
import { uid, log, roundRobin, memberLabel } from '../actions'
import { Badge, Btn, Card, CardHead, DemoTag, Help, PageTitle, cx } from '../ui'

interface Line { who: 'caller' | 'ai' | 'system'; text: string }

export function FrontDesk() {
  return (
    <div>
      <PageTitle
        kicker="AI front desk — web, text & voice preview"
        title="After-Hours Desk"
        plain="This is how the assistant would greet customers when nobody is free — on the website, by text, or (in the future) on the phone. It always says it's an AI, only uses facts from your car records, and hands off to a person whenever asked."
      />
      <div className="grid gap-5 xl:grid-cols-2">
        <PhoneChat />
        <VoiceDemo />
      </div>
      <Card className="mt-5 p-5">
        <CardHead title="Before this goes live for real" icon={<ShieldCheck className="h-5 w-5 text-brand-600" />} sub="Checklist for a future production version — none of this is active in the demo" />
        <ul className="mt-3 grid gap-2 text-[13px] text-ink-700 sm:grid-cols-2">
          {['Customer consent for texts and calls (opt-in records kept)', 'Call-recording notice rules checked for Florida and the caller’s state', 'Clear “you’re talking to an AI” message at the start', '“Speak to a person” always available, with a real callback', 'Phone provider (telephony) rules and spam-labeling compliance', 'Quiet hours and message limits per customer'].map((x) => (
            <li key={x} className="flex gap-2"><span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-brand-600" />{x}</li>
          ))}
        </ul>
      </Card>
    </div>
  )
}

function PhoneChat() {
  const { s } = useStore()
  const cars = s.vehicles.filter(isPublic)
  const [vid, setVid] = useState(cars[0]?.id ?? null)
  const [msgs, setMsgs] = useState<{ from: 'me' | 'ai'; text: string }[]>([])
  const [text, setText] = useState('')
  const end = useRef<HTMLDivElement>(null)
  const v = cars.find((x) => x.id === vid) ?? null
  const off = isOffHours(s)
  useEffect(() => { end.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }) }, [msgs])
  const ask = (q: string) => {
    if (!q.trim()) return
    const out = conciergeReply(q, { vehicles: cars, offHours: off, slots: nextSlots(s.now, s.hours, s.appointments), first: msgs.length === 0, vehicleId: vid, hours: s.hours, sms: true })
    setMsgs((m) => [...m, { from: 'me', text: q }, { from: 'ai', text: out.text }])
    if (out.vehicleId) setVid(out.vehicleId)
    setText('')
  }
  return (
    <Card className="p-5">
      <CardHead title="Text / website chat preview" sub="Try asking about price, miles, financing or accidents" right={<Badge tone={off ? 'amber' : 'green'}>{off ? 'After hours' : 'Open'}</Badge>} />
      <div className="mt-4 flex flex-col items-center gap-4 sm:flex-row sm:items-start">
        <div className="w-full max-w-[300px] rounded-[2.2rem] border-[10px] border-ink-900 bg-white shadow-xl">
          <div className="flex items-center gap-2 border-b border-silver-200 bg-silver-50 px-3 py-2.5">
            <div className="flex h-7 w-7 items-center justify-center rounded-full bg-brand-600 text-white"><Bot className="h-4 w-4" /></div>
            <div className="leading-tight"><div className="text-[12px] font-bold">Superior Auto Mall</div><div className="text-[10px] text-ink-500">Virtual assistant (AI) · demo</div></div>
          </div>
          {v && <div className="border-b border-silver-100 px-3 py-2 text-[11px] text-ink-600">About: <b>{v.year} {v.make} {v.model}</b> · {priceLabel(v)} · {milesLabel(v)}</div>}
          <div className="scroll-thin h-72 space-y-2 overflow-y-auto px-3 py-3">
            {msgs.length === 0 && <div className="pt-8 text-center text-[11px] text-ink-400">Tap a question below to start</div>}
            {msgs.map((m, i) => (
              <div key={i} className={cx('max-w-[85%] rounded-2xl px-3 py-2 text-[12px] leading-snug', m.from === 'me' ? 'ml-auto rounded-br-sm bg-brand-600 text-white' : 'rounded-bl-sm bg-silver-100 text-ink-900')}>{m.text}</div>
            ))}
            <div ref={end} />
          </div>
          <form onSubmit={(e) => { e.preventDefault(); ask(text) }} className="flex gap-1.5 border-t border-silver-200 p-2">
            <input value={text} onChange={(e) => setText(e.target.value)} placeholder="Type a message…" aria-label="Message" className="h-8 min-w-0 flex-1 rounded-full border border-silver-300 px-3 text-[12px]" />
            <button className="flex h-8 w-8 items-center justify-center rounded-full bg-brand-600 text-white" aria-label="Send"><Send className="h-3.5 w-3.5" /></button>
          </form>
        </div>
        <div className="w-full space-y-2">
          <label className="block text-[12px] font-semibold text-ink-600">Car the customer is looking at
            <select value={vid ?? ''} onChange={(e) => { setVid(e.target.value); setMsgs([]) }} className="mt-1 h-9 w-full rounded-lg border border-silver-300 px-2 text-[13px]">
              {cars.map((c) => <option key={c.id} value={c.id}>{c.year} {c.make} {c.model} · {c.stock}</option>)}
            </select>
          </label>
          <div className="text-[12px] font-semibold text-ink-600">Quick questions</div>
          {['Is it still available?', 'What’s the price and mileage?', 'Has it been in an accident?', 'Can I get financing? What would my payment be?', 'Does it have a warranty?', 'Can I test drive it tomorrow?', 'I want to talk to a person', 'STOP'].map((q) => (
            <button key={q} onClick={() => ask(q)} className="block w-full rounded-lg border border-silver-200 bg-white px-3 py-1.5 text-left text-[12.5px] hover:border-brand-600">{q}</button>
          ))}
          <Help>Notice it never guesses: no accident history, no payment quotes, no warranty claims. Unknowns go to staff.</Help>
          <Btn size="xs" variant="ghost" icon={<RotateCcw className="h-3.5 w-3.5" />} onClick={() => setMsgs([])}>Clear chat</Btn>
        </div>
      </div>
    </Card>
  )
}

function VoiceDemo() {
  const { s, act, nav } = useStore()
  const [lines, setLines] = useState<Line[]>([])
  const [i, setI] = useState(-1)
  const [person, setPerson] = useState(false)
  const [done, setDone] = useState<string | null>(null)
  const v = s.vehicles.find((x) => x.id === 'v04')!
  const slot: Wall | undefined = nextSlots(s.now, s.hours, s.appointments)[0]
  const script: Line[] = [
    { who: 'system', text: `Incoming call · 8:52 PM · (727) 555-0177 · Demo transcript (no real call or recording)` },
    { who: 'ai', text: 'Thanks for calling Superior Auto Mall. I’m the virtual assistant — an AI. We’re closed right now, but I can help or take a message. You can say “person” anytime.' },
    { who: 'caller', text: 'Yeah, I saw a white Silverado on your site. Is it four-wheel drive?' },
    { who: 'ai', text: `Looking that up… Our record for the ${v.year} ${v.make} ${v.model} ${v.trim} lists ${v.drivetrain}, ${milesLabel(v)}, listed at ${priceLabel(v)}. Staff will confirm it’s on the lot before you visit.` },
    { who: 'caller', text: 'Can someone call me tomorrow? And maybe I can come see it.' },
    { who: 'ai', text: slot ? `Sure. I can hold ${fmtDay(slot)} at ${fmtTime(slot)} for a visit and ask a salesperson to call you in the morning. Is this number the best one?` : 'Sure — I’ll ask a salesperson to call you in the morning.' },
    { who: 'caller', text: 'Yes, this number is fine. My name is Dana.' },
    { who: 'ai', text: 'Got it, Dana. A team member will call you after we open. Thanks for calling!' },
  ]
  useEffect(() => {
    if (i < 0 || i >= script.length || person) return
    const t = setTimeout(() => { setLines((l) => [...l, script[i]]); setI(i + 1) }, i === 0 ? 200 : 1100)
    return () => clearTimeout(t)
  }, [i, person])
  const finished = i >= script.length
  const start = () => { setLines([]); setI(0); setPerson(false); setDone(null) }
  const save = (handoff: boolean) => {
    let id = ''
    act((st, c) => {
      id = uid(st, 'l')
      const who = roundRobin(st)
      st.leads.unshift({
        id, name: 'Dana (caller)', phone: '(727) 555-0177', email: '', source: 'phone', kind: 'inquiry', vehicleId: v.id, budget: null, tradeIn: null, channel: 'phone', assignedTo: who, stage: 'new',
        consent: { sms: false, email: false, call: true, source: 'Asked for a callback on the phone (demo)', at: st.now, stopped: false },
        urgency: 'high', nextAction: handoff ? 'Caller asked for a person — call back first thing' : 'Call back in the morning', createdAt: st.now,
        messages: [{ id: uid(st, 'm'), from: 'system', text: `After-hours call (demo transcript): asked about ${v.year} ${v.make} ${v.model} drivetrain; requested a callback${handoff ? ' and asked for a person' : ''}.`, at: st.now }],
        automationPaused: false, humanTakeover: handoff, missed: false, callbackRequested: true, autoSentToday: 0, draft: null,
      })
      if (slot && !handoff) st.appointments.push({ id: uid(st, 'a'), leadId: id, customer: 'Dana (caller)', vehicleId: v.id, start: slot, duration: 60, salesperson: who, notes: 'Held by the after-hours assistant — staff to confirm.', reminder: 'none', status: 'hold', kind: 'Test drive' })
      log(st, 'automation', `After-hours call captured: callback request for ${memberLabel(st, who)}${slot && !handoff ? `, visit held ${fmtDay(slot)} ${fmtTime(slot)}` : ''}`, true, { screen: 'leads', id })
      c.toast('Callback request added to the inbox' + (slot && !handoff ? ' and a visit hold to the calendar.' : '.'), 'ok')
    })
    setDone(id)
  }
  return (
    <Card className="p-5">
      <CardHead title="Phone call preview (future option)" sub="A scripted example of an after-hours call — no real calling or recording" right={<DemoTag>Simulated</DemoTag>} />
      <div className="mt-4 rounded-2xl bg-ink-900 p-4 text-white">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-[13px] font-semibold"><PhoneCall className="h-4 w-4 text-brand-500" /> After-hours line</div>
          {i >= 0 && !finished && !person && <span className="flex items-center gap-1 text-[11px] text-emerald-300"><Mic className="h-3.5 w-3.5 animate-pulse" /> live (demo)</span>}
        </div>
        <div className="scroll-thin mt-3 h-72 space-y-2 overflow-y-auto pr-1">
          {lines.length === 0 && <div className="pt-20 text-center text-[12px] text-silver-400">Press “Play the call” to hear how it would go.</div>}
          {lines.map((l, k) => (
            <div key={k} className={cx('flex gap-2 text-[12.5px] leading-snug', l.who === 'system' && 'text-[11px] text-silver-400')}>
              {l.who !== 'system' && <span className={cx('mt-0.5 flex h-6 w-6 shrink-0 items-center justify-center rounded-full', l.who === 'ai' ? 'bg-brand-600' : 'bg-silver-600')}>{l.who === 'ai' ? <Bot className="h-3.5 w-3.5" /> : <User className="h-3.5 w-3.5" />}</span>}
              <span>{l.text}</span>
            </div>
          ))}
          {person && <div className="rounded-lg bg-white/10 p-2 text-[12px]">AI: “No problem — I’ll have a person call you back as soon as we open. Could I get your name?” <span className="text-silver-400">(Handoff noted. In production this could ring a manager’s phone first.)</span></div>}
        </div>
      </div>
      <div className="mt-3 flex flex-wrap gap-2">
        <Btn variant="primary" size="sm" icon={<Play className="h-4 w-4" />} onClick={start}>{i < 0 ? 'Play the call' : 'Replay'}</Btn>
        <Btn size="sm" icon={<Phone className="h-4 w-4" />} disabled={i < 0 || person || !!done} onClick={() => setPerson(true)}>Speak to a person</Btn>
        <Btn size="sm" variant="success" disabled={!(finished || person) || !!done} onClick={() => save(person)}>Save to inbox & calendar</Btn>
        {done && <Btn size="sm" variant="ghost" onClick={() => nav('leads', done)}>Open in inbox →</Btn>}
      </div>
    </Card>
  )
}
