import { useState } from 'react'
import { ArrowDown, ArrowRight, Calendar, Database, FileSpreadsheet, Globe, History, Lock, Mail, MessageSquare, Phone, Server, ShieldCheck, Store } from 'lucide-react'
import { ROLE_LABEL, useStore } from '../store'
import type { Role } from '../types'
import { publicVehicles, slugOf, to12 } from '../logic'
import { DOW_NAMES, fmtWhen } from '../time'
import { Badge, Btn, Card, CardHead, Field, Help, Input, PageTitle, Tabs, Term, cx } from '../ui'

type Tab = 'connections' | 'business' | 'roles' | 'activity' | 'security' | 'website'

export function Settings() {
  const [tab, setTab] = useState<Tab>('connections')
  return (
    <div>
      <PageTitle
        kicker="Integration center, roles, security & settings"
        title="Settings"
        plain="How this would connect to the systems you already use, who can see what, your business details, and a log of everything the AI and staff did."
      />
      <div className="mb-4">
        <Tabs value={tab} onChange={setTab} items={[
          { id: 'connections', label: 'Connections' },
          { id: 'business', label: 'Business info & hours' },
          { id: 'roles', label: 'Team roles' },
          { id: 'activity', label: 'Activity log' },
          { id: 'security', label: 'Security & rollout' },
          { id: 'website', label: 'Website & SEO' },
        ]} />
      </div>
      {tab === 'connections' && <Connections />}
      {tab === 'business' && <Business />}
      {tab === 'roles' && <Roles />}
      {tab === 'activity' && <Activity />}
      {tab === 'security' && <Security />}
      {tab === 'website' && <Website />}
    </div>
  )
}

const INTEGRATIONS = [
  { name: 'Dealer Car Search', icon: Globe, what: 'Your current website & inventory feed, plus web leads', note: 'Shown in your current website footer.', opts: ['Official API / feed if available', 'Authorized CSV import/export', 'Manual approval workflow'] },
  { name: 'Frazer DMS', icon: Database, what: 'Deals, inventory, accounting, forms', note: 'Only if you confirm you use Frazer.', opts: ['Official API / feed if available', 'Authorized CSV import/export', 'Manual approval workflow'] },
  { name: 'DealerCenter', icon: Database, what: 'Alternative DMS / CRM', note: 'Only if this is the system you use.', opts: ['Official API / feed if available', 'Authorized CSV import/export', 'Manual approval workflow'] },
  { name: 'Email', icon: Mail, what: 'Read inquiries, send approved replies', note: 'e.g. Google Workspace or Microsoft 365.', opts: ['Official API if available', 'Forwarding address', 'Manual approval workflow'] },
  { name: 'Text messages (SMS)', icon: MessageSquare, what: 'Two-way texting with consent tracking', note: 'Requires carrier registration (10DLC).', opts: ['Approved SMS provider', 'Manual approval workflow'] },
  { name: 'Phone', icon: Phone, what: 'Missed-call capture, voicemail transcripts', note: 'Call recording and AI voice need legal review.', opts: ['Approved phone provider', 'Manual approval workflow'] },
  { name: 'Calendar', icon: Calendar, what: 'Test drives, deliveries, appraisals', note: 'Google or Outlook calendars.', opts: ['Official API if available', 'Manual approval workflow'] },
  { name: 'Facebook Marketplace / OfferUp', icon: Store, what: 'Future optional listing & message channels', note: 'Subject to each platform’s partner approval. No automatic posting assumed.', opts: ['Partner program if approved', 'Manual copy & paste'] },
]

function Connections() {
  return (
    <div className="space-y-5">
      <Help>
        This demo is <b>not connected to anything</b>. Frazer / DealerCenter / Dealer Car Search integration-ready; connection requires dealer authorization and supported data access. The simplest real first step is a <Term k="CSV">CSV file</Term> export and import — no special access needed.
      </Help>
      <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
        {INTEGRATIONS.map((it) => {
          const I = it.icon
          return (
            <Card key={it.name} className="flex flex-col p-4">
              <div className="flex items-start justify-between gap-2">
                <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-silver-100"><I className="h-5 w-5 text-ink-700" /></div>
                <Badge tone="gray">Not connected — demo</Badge>
              </div>
              <div className="mt-3 text-[14px] font-bold">{it.name}</div>
              <div className="text-[12.5px] text-ink-600">{it.what}</div>
              <div className="mt-1 text-[11.5px] text-ink-400">{it.note}</div>
              <div className="mt-3 space-y-1 border-t border-silver-100 pt-3">
                <div className="text-[10.5px] font-bold uppercase tracking-wide text-ink-400">Possible ways to connect</div>
                {it.opts.map((o) => <div key={o} className="text-[12px] text-ink-700">• {o}</div>)}
              </div>
            </Card>
          )
        })}
      </div>
      <SourceOfTruth />
    </div>
  )
}

function SourceOfTruth() {
  return (
    <Card className="p-5">
      <CardHead title="Who is in charge of which information" sub="Your existing systems stay the official record. This tool reads approved data, suggests tasks and keeps a log." />
      <div className="mt-5 grid items-center gap-3 lg:grid-cols-[1fr_auto_1.2fr_auto_1fr]">
        <div className="rounded-2xl border-2 border-ink-900 p-4">
          <div className="flex items-center gap-2 text-[14px] font-extrabold"><Database className="h-5 w-5" /> Your <Term k="DMS">DMS</Term></div>
          <div className="mt-1 text-[12px] text-ink-600">Frazer, DealerCenter or other</div>
          <ul className="mt-2 space-y-0.5 text-[12px] text-ink-700"><li>• Deals & contracts</li><li>• Accounting & payments</li><li>• Official title / DMV records</li><li>• Lender submissions</li></ul>
          <Badge tone="dark" className="mt-2">Official record — unchanged</Badge>
        </div>
        <div className="flex justify-center text-ink-400"><ArrowRight className="hidden h-6 w-6 lg:block" /><ArrowDown className="h-6 w-6 lg:hidden" /></div>
        <div className="rounded-2xl border-2 border-brand-600 bg-brand-50/40 p-4">
          <div className="text-[14px] font-extrabold text-brand-700">Superior Command AI</div>
          <div className="mt-1 text-[12px] text-ink-600">Reads only approved data</div>
          <ul className="mt-2 space-y-0.5 text-[12px] text-ink-700"><li>• Spots missing info & stuck deals</li><li>• Drafts replies & reminders</li><li>• Assigns tasks with due times</li><li>• Logs every suggestion & approval (<Term k="Audit trail">audit trail</Term>)</li></ul>
          <Badge tone="red" className="mt-2">Suggests — people approve</Badge>
        </div>
        <div className="flex justify-center text-ink-400"><ArrowRight className="hidden h-6 w-6 lg:block" /><ArrowDown className="h-6 w-6 lg:hidden" /></div>
        <div className="rounded-2xl border border-silver-300 p-4">
          <div className="flex items-center gap-2 text-[14px] font-extrabold"><Globe className="h-5 w-5" /> Website & inbox</div>
          <ul className="mt-2 space-y-0.5 text-[12px] text-ink-700"><li>• Approved listing changes</li><li>• Customer replies (with consent)</li><li>• Calendar holds</li></ul>
          <Badge tone="gray" className="mt-2">Only after approval</Badge>
        </div>
      </div>
    </Card>
  )
}

function Business() {
  const { s, act } = useStore()
  const [d, setD] = useState(s.dealer)
  const owner = s.role === 'owner' || s.role === 'admin'
  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <Card className="p-5">
        <CardHead title="Dealership details" sub="Shown on the customer website" />
        <div className="mt-3 rounded-lg border border-amber-200 bg-amber-50 p-3 text-[12px] text-amber-900">
          Public records disagree: the current website footer shows <b>541 34th St S</b>, but the old About page mentions <b>2500 34th St N Bldg 2</b>. Confirm the correct storefront address and ZIP with the owner before going live.
        </div>
        <div className="mt-3 grid gap-3 sm:grid-cols-2">
          <Field label="Business name"><Input value={d.name} onChange={(e) => setD({ ...d, name: e.target.value })} /></Field>
          <Field label="Phone"><Input value={d.phone} onChange={(e) => setD({ ...d, phone: e.target.value })} /></Field>
          <Field label="Street address"><Input value={d.street} onChange={(e) => setD({ ...d, street: e.target.value })} /></Field>
          <Field label="City, state"><Input value={d.city} onChange={(e) => setD({ ...d, city: e.target.value })} /></Field>
          <Field label="ZIP" hint="Left blank until confirmed"><Input value={d.zip} onChange={(e) => setD({ ...d, zip: e.target.value })} placeholder="Confirm with owner" /></Field>
          <Field label="Dealer fee included in advertised prices ($)" hint="Blank = not set. Prices must include dealer-required fees."><Input type="number" value={d.dealerFee ?? ''} onChange={(e) => setD({ ...d, dealerFee: e.target.value === '' ? null : Number(e.target.value) })} /></Field>
        </div>
        <Btn className="mt-4" variant="primary" disabled={!owner} onClick={() => act((st, c) => { st.dealer = d; c.toast('Business details saved — the customer website updated.', 'ok') })}>Save details</Btn>
      </Card>

      <div className="space-y-5">
        <Card className="p-5">
          <CardHead title="Business hours (Eastern Time)" sub="Used by the website, the AI assistant and the calendar" />
          <div className="mt-3 space-y-2">
            {[1, 2, 3, 4, 5, 6, 0].map((dw) => {
              const h = s.hours[dw]
              return (
                <div key={dw} className="flex items-center gap-2 text-[13px]">
                  <span className="w-24 font-semibold">{DOW_NAMES[dw]}</span>
                  <label className="flex items-center gap-1.5 text-[12px]"><input type="checkbox" className="accent-brand-600" checked={!!h} disabled={!owner} onChange={(e) => act((st) => { st.hours[dw] = e.target.checked ? { open: '10:00', close: '17:00' } : null })} /> Open</label>
                  {h ? (
                    <>
                      <input type="time" value={h.open} disabled={!owner} onChange={(e) => act((st) => { st.hours[dw] = { ...st.hours[dw]!, open: e.target.value } })} className="h-8 rounded border border-silver-300 px-1.5 text-[12px]" aria-label={`${DOW_NAMES[dw]} opening time`} />
                      <span>–</span>
                      <input type="time" value={h.close} disabled={!owner} onChange={(e) => act((st) => { st.hours[dw] = { ...st.hours[dw]!, close: e.target.value } })} className="h-8 rounded border border-silver-300 px-1.5 text-[12px]" aria-label={`${DOW_NAMES[dw]} closing time`} />
                      <span className="text-[11px] text-ink-400">{to12(h.open)}–{to12(h.close)}</span>
                    </>
                  ) : <span className="text-[12px] text-ink-400">Closed</span>}
                </div>
              )
            })}
          </div>
        </Card>
        <Card className="p-5">
          <CardHead title="Messaging safety" sub="Applies to every automated message" />
          <div className="mt-3 grid gap-3 sm:grid-cols-3">
            <Field label="Quiet hours start"><Input type="time" value={s.quietStart} onChange={(e) => act((st) => { st.quietStart = e.target.value })} /></Field>
            <Field label="Quiet hours end"><Input type="time" value={s.quietEnd} onChange={(e) => act((st) => { st.quietEnd = e.target.value })} /></Field>
            <Field label="Max automated messages / customer / day"><Input type="number" min={0} max={5} value={s.freqCap} onChange={(e) => act((st) => { st.freqCap = Number(e.target.value) })} /></Field>
          </div>
        </Card>
        <Card className="p-5">
          <CardHead title="Pitch theme preview" sub="Red & white is the default" />
          <div className="mt-3 flex gap-2">
            {([['white', 'Red / White'], ['silver', 'Red / Silver']] as const).map(([k, label]) => (
              <button key={k} onClick={() => act((st) => { st.theme = k })} className={cx('flex flex-1 items-center gap-2 rounded-xl border-2 p-3 text-left text-[13px] font-semibold', s.theme === k ? 'border-brand-600' : 'border-silver-200')}>
                <span className={cx('h-8 w-8 rounded-lg border border-silver-200', k === 'white' ? 'bg-white' : 'bg-silver-200')}><span className="m-2 block h-4 w-4 rounded bg-brand-600" /></span>{label}
              </button>
            ))}
          </div>
        </Card>
      </div>
    </div>
  )
}

const ROLE_INFO: Record<Role, { sees: string; approves: string }> = {
  owner: { sees: 'Everything, including costs, margins and the savings calculator', approves: 'All messages, listing changes and document requests' },
  sales: { sees: 'Customer inbox, calendar, cars (no costs), deal status', approves: 'Replies to their own customers' },
  admin: { sees: 'Deals & paperwork, cars, calendar, settings', approves: 'Document requests and listing fixes' },
  inventory: { sees: 'Cars, listing health, calendar', approves: 'Listing changes and photos' },
}

function Roles() {
  const { s, act } = useStore()
  return (
    <Card className="p-5">
      <CardHead title="Who can see and approve what" sub="Switch roles to see the app from each person’s point of view. No real names are used." />
      <div className="mt-4 grid gap-3 md:grid-cols-2">
        {(Object.keys(ROLE_INFO) as Role[]).map((r) => (
          <div key={r} className={cx('rounded-xl border p-4', s.role === r ? 'border-brand-600 bg-brand-50/30' : 'border-silver-200')}>
            <div className="flex items-center justify-between">
              <div className="text-[14px] font-bold">{ROLE_LABEL[r]}</div>
              {s.role === r ? <Badge tone="red">Viewing now</Badge> : <Btn size="xs" onClick={() => act((st, c) => { st.role = r; c.toast(`Now viewing as ${ROLE_LABEL[r]}.`, 'info') })}>View as</Btn>}
            </div>
            <div className="mt-2 text-[12.5px]"><b>Sees:</b> {ROLE_INFO[r].sees}</div>
            <div className="text-[12.5px]"><b>Can approve:</b> {ROLE_INFO[r].approves}</div>
          </div>
        ))}
      </div>
    </Card>
  )
}

function Activity() {
  const { s, nav } = useStore()
  const [f, setF] = useState<'all' | 'ai' | 'people'>('all')
  const rows = s.audit.filter((a) => f === 'all' || (f === 'ai' ? a.actor.startsWith('AI') : !a.actor.startsWith('AI')))
  return (
    <Card className="p-5">
      <CardHead title={<span>Activity log (<Term k="Audit trail">audit trail</Term>)</span>} sub="Every AI suggestion, staff approval and change — newest first" icon={<History className="h-5 w-5 text-brand-600" />} right={<Tabs value={f} onChange={setF} items={[{ id: 'all', label: 'All' }, { id: 'ai', label: 'AI' }, { id: 'people', label: 'People' }]} />} />
      <div className="mt-3 divide-y divide-silver-100">
        {rows.map((a) => (
          <div key={a.id} className="flex items-start gap-3 py-2.5">
            <span className={cx('mt-1.5 h-2 w-2 shrink-0 rounded-full', a.done ? 'bg-emerald-500' : 'bg-amber-500')} />
            <div className="min-w-0 flex-1">
              <div className="text-[13px]">{a.text}</div>
              <div className="text-[11px] text-ink-400">{fmtWhen(a.at, s.now)} · {a.actor} · {a.kind}{a.done ? '' : ' · needs a person'}</div>
            </div>
            {a.link && <Btn size="xs" variant="ghost" onClick={() => nav(a.link!.screen, a.link!.id)}>Open</Btn>}
          </div>
        ))}
      </div>
    </Card>
  )
}

function Security() {
  const items = [
    ['Two-step login', <><Term k="MFA">MFA</Term> for every staff account</>],
    ['Encryption', 'Data encrypted while moving and while stored'],
    ['Access control', 'Each role sees only what it needs'],
    ['Vendor checks', 'Due diligence on every AI and messaging provider'],
    ['Backups', 'Daily backups with tested restores'],
    ['Data retention', 'Written policy for how long data is kept'],
    ['FTC Safeguards Rule', 'Written security program where it applies to the dealership'],
    ['No sensitive data in the demo', 'No SSNs, license images, credit applications or real financing data — ever, in a demo or an unreviewed AI tool'],
  ] as const
  return (
    <div className="space-y-5">
      <Help title="Honest note">This is a demo running in your browser with made-up data. It is <b>not</b> production-grade or compliance-certified. Before real use, the items below must be in place.</Help>
      <Card className="p-5">
        <CardHead title="Required before real use" icon={<ShieldCheck className="h-5 w-5 text-brand-600" />} />
        <div className="mt-3 grid gap-2 sm:grid-cols-2">
          {items.map(([t, d]) => (
            <div key={t} className="flex gap-3 rounded-xl border border-silver-200 p-3"><Lock className="mt-0.5 h-4 w-4 shrink-0 text-ink-500" /><div><div className="text-[13px] font-bold">{t}</div><div className="text-[12px] text-ink-600">{d}</div></div></div>
          ))}
        </div>
      </Card>
      <Card className="p-5">
        <CardHead title="Pricing honesty" />
        <ul className="mt-2 space-y-1 text-[13px] text-ink-700">
          <li>• Never promise financing approval, an interest rate (APR) or a guaranteed monthly payment.</li>
          <li>• Advertised prices include dealer-required fees; government tax, tag and title shown separately.</li>
          <li>• No hidden fees, no unverified prices published, no misleading sales claims.</li>
        </ul>
      </Card>
      <Card className="p-5">
        <CardHead title="Rollout plan" icon={<Server className="h-5 w-5 text-brand-600" />} sub="Small, measured steps — the owner decides at each stage" />
        <div className="mt-4 grid gap-3 md:grid-cols-3">
          {[
            ['Phase 1', 'Learn & measure', 'Owner interviews, measure how long tasks take today, this demo, and a 2–4 week pilot with no sensitive data.'],
            ['Phase 2', 'Handle the routine', 'Authorized inquiry handling, appointment coordination and listing quality checks.'],
            ['Phase 3', 'Connect & verify', 'Approved DMS / feed connections, document checklist help, security review, and checking the savings against real numbers.'],
          ].map(([p, t, d]) => (
            <div key={p} className="rounded-xl bg-silver-50 p-4"><div className="text-[11px] font-bold uppercase tracking-wide text-brand-600">{p}</div><div className="text-[14px] font-bold">{t}</div><div className="mt-1 text-[12.5px] text-ink-600">{d}</div></div>
          ))}
        </div>
        <div className="mt-4 rounded-xl border border-silver-200 p-4 text-[12.5px] text-ink-700">
          <b>Technical note for later:</b> the production version is designed to run on a private server (for example a Hostinger KVM 8 VPS) using Docker containers: a web app, a database, background workers for reminders and checks, and an audit-log store. This static demo has none of that and makes no compliance claims.
        </div>
      </Card>
    </div>
  )
}

function Website() {
  const { s } = useStore()
  const cars = publicVehicles(s)
  const sitemap = ['/', '/inventory', '/trade-in', '/financing', '/about', '/contact', '/faq', ...cars.map((v) => `/inventory/${slugOf(v)}`)]
  return (
    <div className="grid gap-5 lg:grid-cols-2">
      <Card className="p-5">
        <CardHead title="Search-engine basics built in" sub="So Google can understand each page" />
        <ul className="mt-3 space-y-1.5 text-[13px] text-ink-700">
          <li>• A unique title and description for every car page</li>
          <li>• Proper headings and photo descriptions (also helps screen readers)</li>
          <li>• <Term k="Structured data">Structured data</Term> for the dealership and each car — only filled with real values</li>
          <li>• Canonical web addresses and a sitemap that updates with inventory</li>
        </ul>
        <Help title="Note">This demo copy is marked “noindex” so it never competes with the real website in Google. We don’t claim any rankings.</Help>
      </Card>
      <Card className="p-5">
        <CardHead title="Sitemap (live from inventory)" sub={`${sitemap.length} pages · updated ${fmtWhen(s.now, s.now)}`} icon={<FileSpreadsheet className="h-5 w-5 text-brand-600" />} />
        <pre className="scroll-thin mt-3 max-h-80 overflow-auto rounded-lg bg-ink-900 p-3 font-mono text-[11px] leading-relaxed text-silver-200">{`<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
${sitemap.map((p) => `  <url><loc>https://example-dealer-demo.com${p}</loc></url>`).join('\n')}
</urlset>`}</pre>
      </Card>
    </div>
  )
}
