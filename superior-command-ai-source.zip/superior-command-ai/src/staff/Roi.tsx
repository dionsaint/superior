import { useMemo, useState } from 'react'
import { Copy, Download, FileText, Printer } from 'lucide-react'
import { useStore } from '../store'
import type { RoiState } from '../types'
import { attention, money, roiCalc } from '../logic'
import { Badge, Btn, Card, CardHead, DemoTag, Help, Modal, PageTitle, cx } from '../ui'

const fmtH = (h: number) => (h >= 10 ? Math.round(h).toString() : h.toFixed(1))

function Slider({ label, hint, value, min, max, step = 1, unit, onChange }: { label: string; hint?: string; value: number; min: number; max: number; step?: number; unit?: string; onChange: (v: number) => void }) {
  return (
    <label className="block">
      <div className="flex items-baseline justify-between gap-2">
        <span className="text-[13px] font-semibold text-ink-800">{label}</span>
        <span className="text-[13px] font-bold tabular-nums text-brand-700">{unit === '$' ? `$${value}` : value}{unit && unit !== '$' ? unit : ''}</span>
      </div>
      {hint && <div className="text-[11px] text-ink-500">{hint}</div>}
      <input type="range" min={min} max={max} step={step} value={value} onChange={(e) => onChange(Number(e.target.value))} className="mt-1 w-full accent-[#c8102e]" aria-label={label} />
    </label>
  )
}

export function Roi() {
  const { s, act, setUi } = useStore()
  const r = s.roi
  const set = (k: keyof RoiState, v: number) => act((st) => { st.roi[k] = v })
  const base = roiCalc(r)
  const low = roiCalc(r, 0.6)
  const high = roiCalc(r, 1.3)
  const maxH = Math.max(...base.rows.map((x) => x.hours), 1)

  return (
    <div>
      <PageTitle
        kicker="Owner ROI & staffing capacity"
        title="Time & Money"
        plain="Move the sliders to match your dealership. It shows how many hours of routine work the system could take off your team each month, and what that time is worth. These are estimates you control — not promises."
        right={<Btn variant="primary" icon={<FileText className="h-4 w-4" />} onClick={() => setUi({ proposal: true })}>Generate pilot proposal</Btn>}
      />

      <div className="grid gap-5 lg:grid-cols-[380px_minmax(0,1fr)]">
        <Card className="p-5" data-tour="roi-inputs">
          <CardHead title="Your assumptions" sub="Change any number — results update instantly" right={<DemoTag>Editable estimate</DemoTag>} />
          <div className="mt-4 space-y-4">
            <Slider label="Employees" value={r.employees} min={1} max={10} onChange={(v) => set('employees', v)} />
            <Slider label="Average hourly pay" hint="Typical range $18–$30" value={r.hourly} min={18} max={30} unit="$" onChange={(v) => set('hourly', v)} />
            <Slider label="Extra cost on top of pay (taxes, benefits)" value={r.burden} min={0} max={35} unit="%" onChange={(v) => set('burden', v)} />
            <div className="rounded-xl bg-silver-50 p-3">
              <div className="mb-2 text-[12px] font-bold uppercase tracking-wide text-ink-500">Team hours per week spent on…</div>
              <div className="space-y-3">
                <Slider label="Answering inquiries" value={r.hLeads} min={0} max={40} unit=" h" onChange={(v) => set('hLeads', v)} />
                <Slider label="Scheduling & reminders" value={r.hScheduling} min={0} max={20} unit=" h" onChange={(v) => set('hScheduling', v)} />
                <Slider label="Updating car listings" value={r.hListings} min={0} max={20} unit=" h" onChange={(v) => set('hListings', v)} />
                <Slider label="Chasing paperwork & titles" value={r.hPaperwork} min={0} max={25} unit=" h" onChange={(v) => set('hPaperwork', v)} />
              </div>
            </div>
            <Slider label="How much of that routine work the system handles" hint="Start low. A pilot measures the real number." value={r.adoption} min={10} max={90} step={5} unit="%" onChange={(v) => set('adoption', v)} />
            <Slider label="Monthly software fee (example)" value={r.fee} min={99} max={1499} step={50} unit="$" onChange={(v) => set('fee', v)} />
          </div>
        </Card>

        <div className="space-y-5">
          <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4" data-tour="roi-results">
            <Card className="p-4"><div className="text-[12px] font-semibold text-ink-500">Hours freed per month</div><div className="mt-1 text-3xl font-black text-ink-900">{fmtH(base.monthly)}</div><div className="text-[11px] text-ink-500">{fmtH(base.weekly)} h/week × 4.33</div></Card>
            <Card className="p-4"><div className="text-[12px] font-semibold text-ink-500">What that time is worth</div><div className="mt-1 text-3xl font-black text-ink-900">{money(base.value)}</div><div className="text-[11px] text-ink-500">at {money(base.loaded)}/h incl. extra costs</div></Card>
            <Card className="p-4"><div className="text-[12px] font-semibold text-ink-500">Software fee</div><div className="mt-1 text-3xl font-black text-ink-900">{money(r.fee)}</div><div className="text-[11px] text-ink-500">per month (example)</div></Card>
            <Card className={cx('p-4', base.net >= 0 ? 'border-emerald-200 bg-emerald-50/50' : 'border-amber-200 bg-amber-50/50')}><div className="text-[12px] font-semibold text-ink-500">Estimated net value</div><div className={cx('mt-1 text-3xl font-black', base.net >= 0 ? 'text-emerald-700' : 'text-amber-700')}>{money(base.net)}</div><div className="text-[11px] text-ink-500">per month · estimate</div></Card>
          </div>

          <Help title="Important">
            “Hours freed” means time your team gets back for selling and customers. It is <b>not</b> the same as cutting payroll. Payroll only changes if you choose to change shifts, overtime or staffing — and only once the new way of working has proven safe. This equals about <b>{base.fte.toFixed(2)} of a full-time person’s monthly hours</b> ({fmtH(base.monthly)} of ~173). We never show “employees replaced.”
          </Help>

          <Card className="p-5">
            <CardHead title="Where the hours come from" sub="Gray = time spent today · Red = time the system could handle" right={<DemoTag />} />
            <div className="mt-4 space-y-3">
              {base.rows.map((x) => (
                <div key={x.key}>
                  <div className="mb-1 flex justify-between text-[12.5px]"><span className="font-semibold">{x.key}</span><span className="tabular-nums text-ink-500">{fmtH(x.saved)} of {x.hours} h/week</span></div>
                  <div className="relative h-3 overflow-hidden rounded-full bg-silver-100">
                    <div className="absolute inset-y-0 left-0 rounded-full bg-silver-300" style={{ width: `${(x.hours / maxH) * 100}%` }} />
                    <div className="absolute inset-y-0 left-0 rounded-full bg-brand-600 transition-all" style={{ width: `${(x.saved / maxH) * 100}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </Card>

          <Card className="p-5">
            <CardHead title="Careful, expected and best case" sub="Same inputs, different amounts of work handled" right={<DemoTag>Projection</DemoTag>} />
            <div className="mt-3 overflow-x-auto">
              <table className="w-full min-w-[460px] text-[13px]">
                <thead><tr className="text-left text-[11px] uppercase tracking-wide text-ink-500"><th className="py-2">Case</th><th>Work handled</th><th>Hours / month</th><th>Time value</th><th>Net / month</th></tr></thead>
                <tbody className="divide-y divide-silver-100">
                  {[['Careful', low], ['Expected', base], ['Best case', high]].map(([n, c]) => {
                    const x = c as typeof base
                    return <tr key={n as string} className={n === 'Expected' ? 'font-bold' : ''}><td className="py-2">{n as string}</td><td>{Math.round(x.adopt * 100)}%</td><td className="tabular-nums">{fmtH(x.monthly)}</td><td className="tabular-nums">{money(x.value)}</td><td className={cx('tabular-nums', x.net >= 0 ? 'text-emerald-700' : 'text-amber-700')}>{money(x.net)}</td></tr>
                  })}
                </tbody>
              </table>
            </div>
          </Card>

          <Scorecard />
        </div>
      </div>
    </div>
  )
}

function Scorecard() {
  const { s } = useStore()
  const a = attention(s)
  const c = roiCalc(s.roi)
  const [actual, setActual] = useState<Record<string, string>>({})
  const ramp = [0.25, 0.5, 0.75, 1]
  const rows = useMemo(() => {
    const titleDelays = s.deals.filter((d) => d.waitingDays >= 3).length
    return [
      { key: 'resp', label: 'Time to first reply (new inquiry)', base: 190, fmt: (v: number) => (v >= 60 ? `${Math.floor(v / 60)}h ${Math.round(v % 60)}m` : `${Math.round(v)}m`), effect: 0.9, down: true, note: 'baseline example — measure in week 0' },
      { key: 'unans', label: 'Inquiries left unanswered (per week)', base: Math.max(6, a.missed.length * 3), fmt: (v: number) => Math.round(v).toString(), effect: 0.85, down: true },
      { key: 'list', label: 'Listings with missing info', base: a.listing.length, fmt: (v: number) => Math.round(v).toString(), effect: 0.9, down: true },
      { key: 'title', label: 'Deals waiting 3+ days on paperwork', base: titleDelays, fmt: (v: number) => Math.round(v).toString(), effect: 0.6, down: true },
      { key: 'fu', label: 'Follow-ups done on time', base: 60, fmt: (v: number) => `${Math.round(v)}%`, effect: 0.6, down: false },
      { key: 'hrs', label: 'Hours/week on routine admin (measured)', base: c.totalWeekly, fmt: (v: number) => `${fmtH(v)} h`, effect: 1, down: true },
    ]
  }, [s.deals, a.missed.length, a.listing.length, c.totalWeekly])
  const proj = (b: number, eff: number, down: boolean, k: number) => (down ? b * (1 - c.adopt * eff * ramp[k]) : Math.min(98, b + (100 - b) * c.adopt * eff * ramp[k]))
  return (
    <Card className="p-5" data-tour="scorecard">
      <CardHead title="Pilot scorecard (2–4 weeks)" sub="Week 0 = measure how things are today. Weeks 1–4 = targets. Type real results in the last column during a pilot." right={<DemoTag>Targets are projections</DemoTag>} />
      <div className="mt-3 overflow-x-auto">
        <table className="w-full min-w-[680px] text-[12.5px]">
          <thead>
            <tr className="text-left text-[11px] uppercase tracking-wide text-ink-500"><th className="py-2 pr-2">What we measure</th><th>Week 0 (today)</th><th>Wk 1</th><th>Wk 2</th><th>Wk 3</th><th>Wk 4</th><th>Actual (enter)</th></tr>
          </thead>
          <tbody className="divide-y divide-silver-100">
            {rows.map((r) => (
              <tr key={r.key}>
                <td className="py-2 pr-2 font-semibold">{r.label}{r.note && <div className="text-[10.5px] font-normal text-ink-400">{r.note}</div>}</td>
                <td className="tabular-nums">{r.fmt(r.base)}</td>
                {ramp.map((_, k) => <td key={k} className="tabular-nums text-ink-600">{r.fmt(proj(r.base, r.effect, r.down, k))}</td>)}
                <td><input value={actual[r.key] ?? ''} onChange={(e) => setActual({ ...actual, [r.key]: e.target.value })} placeholder="—" className="h-7 w-20 rounded border border-silver-300 px-2 text-[12px]" aria-label={`Actual result for ${r.label}`} /></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </Card>
  )
}

export function ProposalModal() {
  const { s, ui, setUi, toast } = useStore()
  const c = roiCalc(s.roi)
  const low = roiCalc(s.roi, 0.6)
  const a = attention(s)
  const text = `PILOT PROPOSAL — Superior Command AI (concept demo)
Prepared for: ${s.dealer.name}, ${s.dealer.street}, ${s.dealer.city}
All figures are PROJECTIONS from editable assumptions, not guarantees.

What we'd solve
• Faster replies to website, phone, Marketplace and walk-in inquiries — including after hours
• Accurate listings: no missing prices or mileage, fewer stale or sold-but-listed cars
• Deal paperwork and titles that don't stall — with clear owners and reminders
• One owner view of what needs attention today

Pilot (2–4 weeks, no sensitive data)
1. Owner interview + measure today's numbers (week 0)
2. Turn on inquiry inbox, appointment reminders and listing checks
3. Weekly scorecard review; staff approve every customer message

Estimates (your inputs: ${s.roi.employees} staff, $${s.roi.hourly}/h, ${s.roi.adoption}% handled)
• Hours freed per month: ${Math.round(low.monthly)} (careful) to ${Math.round(c.monthly)} (expected)
• Time value: ${money(low.value)} – ${money(c.value)} / month vs. ${money(s.roi.fee)} fee
• This is time back for the team, not a payroll cut.

Today in the demo data
• ${a.missed.length} inquiries waiting · ${a.listing.length} listings need fixes · ${a.missingDocs.length} deal files missing documents

What we will NOT do
• Replace your DMS, accounting, lender or DMV systems
• Send messages without consent and staff approval
• Store SSNs, license images or credit applications

Connections: Frazer / DealerCenter / Dealer Car Search integration-ready; connection requires dealer authorization and supported data access.

Next step: 30-minute owner interview to confirm systems, hours and goals.`

  const copy = async () => {
    try { await navigator.clipboard.writeText(text); toast('Proposal text copied.', 'ok') } catch { toast('Copy not available — select the text and copy manually.', 'warn') }
  }
  const dl = () => {
    const u = URL.createObjectURL(new Blob([text], { type: 'text/plain' }))
    const el = document.createElement('a')
    el.href = u
    el.download = 'superior-pilot-proposal.txt'
    el.click()
  }

  return (
    <Modal open={ui.proposal} onClose={() => setUi({ proposal: false })} title="One-page pilot proposal" wide footer={
      <>
        <Btn size="sm" icon={<Copy className="h-4 w-4" />} onClick={copy}>Copy text</Btn>
        <Btn size="sm" icon={<Download className="h-4 w-4" />} onClick={dl}>Download .txt</Btn>
        <Btn size="sm" variant="primary" icon={<Printer className="h-4 w-4" />} onClick={() => window.print()}>Print / Save as PDF</Btn>
      </>
    }>
      <div id="print-area" className="text-[13px] leading-relaxed text-ink-800">
        <div className="flex items-start justify-between gap-4 border-b-4 border-brand-600 pb-3">
          <div>
            <div className="text-[11px] font-bold uppercase tracking-widest text-brand-600">Pilot proposal · projections</div>
            <h2 className="text-xl font-black text-ink-900">Superior Command AI for {s.dealer.name}</h2>
            <div className="text-[12px] text-ink-500">Independent concept demo — not an official Superior Auto Mall system</div>
          </div>
          <Badge tone="amber">Estimates, not guarantees</Badge>
        </div>
        <div className="mt-4 grid gap-4 sm:grid-cols-3">
          <div className="rounded-xl bg-silver-50 p-3"><div className="text-[11px] font-semibold text-ink-500">Hours freed / month</div><div className="text-2xl font-black">{Math.round(low.monthly)}–{Math.round(c.monthly)}</div></div>
          <div className="rounded-xl bg-silver-50 p-3"><div className="text-[11px] font-semibold text-ink-500">Time value / month</div><div className="text-2xl font-black">{money(low.value)}–{money(c.value)}</div></div>
          <div className="rounded-xl bg-silver-50 p-3"><div className="text-[11px] font-semibold text-ink-500">Example fee</div><div className="text-2xl font-black">{money(s.roi.fee)}</div></div>
        </div>
        <pre className="mt-4 whitespace-pre-wrap rounded-xl border border-silver-200 bg-white p-4 font-sans text-[12.5px]">{text}</pre>
      </div>
    </Modal>
  )
}
