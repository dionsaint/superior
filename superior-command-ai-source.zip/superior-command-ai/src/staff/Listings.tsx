import React, { useEffect, useMemo, useRef, useState } from 'react'
import { AlertTriangle, Archive, ArrowDown, ArrowUp, CheckCircle2, ClipboardList, Copy, Download, ExternalLink, Eye, EyeOff, FileUp, GripVertical, Hourglass, ImagePlus, Columns2, Plus, RefreshCw, ScanLine, Sparkles, Tag, Upload, Wand2, X } from 'lucide-react'
import { useStore } from '../store'
import type { DataState, Issue, Vehicle, VehicleStatus } from '../types'
import { SAMPLE_CSV, addCar, addPhotos, applyPhotoOrder, applyVehicle, archiveVehicle, bulkApply, duplicateDraft, exportCsv, importCsv, log, memberLabel, mockDecode, reorderPhoto, resolveSync, setListing, setVStatus, uid } from '../actions'
import { EXCLUDED_CLAIMS, factualDescription, isPublic, milesLabel, money, priceLabel, slugOf, statusLabel, vehicleIssues, vehicleScore } from '../logic'
import { PHOTO_SHOTS } from '../data'
import { addMin, ago } from '../time'
import { Avatar, Badge, Btn, Card, CardHead, CarArt, DemoTag, Drawer, Empty, Field, Help, Input, Modal, PageTitle, ScoreRing, Select, Tabs, Textarea, cx } from '../ui'
import { PriceTag } from '../public/common'

type Tab = 'all' | 'attention' | 'aging' | 'sync'

export function Listings() {
  const { s, ui, setUi, act, can } = useStore()
  const [tab, setTab] = useState<Tab>('all')
  const [q, setQ] = useState('')
  const [showArchived, setShowArchived] = useState(false)
  const [sel, setSel] = useState<string[]>([])
  const [importOpen, setImportOpen] = useState(false)
  const owner = s.role === 'owner'
  const approve = can('approve:listing')

  const rows = useMemo(() => s.vehicles.filter((v) => (showArchived ? v.archived : !v.archived) && (!q || `${v.stock} ${v.year} ${v.make} ${v.model}`.toLowerCase().includes(q.toLowerCase())) && (tab !== 'attention' || vehicleIssues(v, s.vehicles).length > 0)), [s.vehicles, q, showArchived, tab])
  const active = s.vehicles.filter((v) => !v.archived)
  const avg = Math.round(active.reduce((a, v) => a + vehicleScore(v, s.vehicles), 0) / Math.max(1, active.length))
  const flagged = active.filter((v) => vehicleIssues(v, s.vehicles).length).length
  const staged = s.sync.filter((x) => x.state === 'staged' || x.state === 'failed' || x.state === 'conflict').length

  const download = () => {
    const blob = new Blob([exportCsv(s)], { type: 'text/csv' })
    const a = document.createElement('a')
    a.href = URL.createObjectURL(blob)
    a.download = 'superior-demo-inventory.csv'
    a.click()
  }

  return (
    <div>
      <PageTitle
        kicker="Inventory health & listing studio"
        title="Manage Cars"
        plain="Add, fix and publish cars. When you approve a change here, the customer website updates instantly — and a copy is queued for your other systems (nothing is sent automatically in this demo)."
        right={
          <>
            <Btn data-tour="add-car" variant="primary" size="sm" icon={<Plus className="h-4 w-4" />} disabled={!approve} onClick={() => act((st, c) => { const id = addCar(st, c); setUi({ vehicleId: id }) })}>Add car</Btn>
            <Btn size="sm" icon={<FileUp className="h-4 w-4" />} disabled={!approve} onClick={() => setImportOpen(true)}>Import demo CSV</Btn>
            <Btn size="sm" icon={<Download className="h-4 w-4" />} onClick={download}>Export CSV</Btn>
          </>
        }
      />
      <div className="mb-4 grid grid-cols-2 gap-3 md:grid-cols-4">
        <Card className="flex items-center gap-3 p-4"><ScoreRing score={avg} size={52} /><div><div className="text-[13px] font-bold">Average listing health</div><div className="text-[11px] text-ink-500">100 = nothing missing</div></div></Card>
        <Card className="p-4"><div className="text-3xl font-black text-brand-600">{flagged}</div><div className="text-[13px] font-bold">Listings need fixing</div><div className="text-[11px] text-ink-500">Missing price, miles, photos…</div></Card>
        <Card className="p-4"><div className="text-3xl font-black">{active.filter(isPublic).length}<span className="text-base font-semibold text-ink-400">/{active.length}</span></div><div className="text-[13px] font-bold">Live on the website</div><div className="text-[11px] text-ink-500">Drafts & sold cars stay hidden</div></Card>
        <Card className="p-4"><div className="text-3xl font-black">{staged}</div><div className="text-[13px] font-bold">Waiting to sync</div><div className="text-[11px] text-ink-500">Dealer Car Search / DMS (simulated)</div></Card>
      </div>

      <div className="mb-3 flex flex-wrap items-center gap-2">
        <Tabs value={tab} onChange={setTab} items={[{ id: 'all', label: 'All cars' }, { id: 'attention', label: `Needs attention (${flagged})` }, { id: 'aging', label: 'Days on lot' }, { id: 'sync', label: `Sync queue (${staged})` }]} />
        {(tab === 'all' || tab === 'attention') && (
          <>
            <Input className="h-9 max-w-xs" placeholder="Search stock, make, model" value={q} onChange={(e) => setQ(e.target.value)} aria-label="Search listings" />
            <label className="flex items-center gap-1.5 text-[12px] font-semibold text-ink-700"><input type="checkbox" className="accent-brand-600" checked={showArchived} onChange={(e) => setShowArchived(e.target.checked)} /> Show archived</label>
          </>
        )}
      </div>

      {sel.length > 0 && (
        <div className="rise mb-3 flex flex-wrap items-center gap-2 rounded-xl bg-ink-900 px-4 py-2.5 text-white">
          <span className="text-sm font-semibold">{sel.length} selected — bulk edit:</span>
          {([['publish', 'Publish'], ['unpublish', 'Unpublish'], ['pending', 'Mark pending'], ['assign-admin', 'Assign Admin'], ['assign-owner', 'Assign Owner']] as const).map(([op, label]) => (
            <Btn key={op} size="xs" variant="white" disabled={!approve} onClick={() => { act((st, c) => bulkApply(st, c, sel, op)); setSel([]) }}>{label}</Btn>
          ))}
          <button className="ml-auto text-[12px] underline" onClick={() => setSel([])}>Clear</button>
        </div>
      )}

      {tab === 'aging' ? <Aging /> : tab === 'sync' ? <SyncQueue /> : (
        <Card className="overflow-hidden" data-tour="listing-table">
          <div className="scroll-thin overflow-x-auto">
            <table className="w-full min-w-[980px] text-[13px]">
              <thead className="bg-silver-50 text-left text-[11px] uppercase tracking-wide text-ink-500">
                <tr>
                  <th className="w-8 px-3 py-2.5"><input type="checkbox" aria-label="Select all" className="accent-brand-600" checked={sel.length === rows.length && rows.length > 0} onChange={(e) => setSel(e.target.checked ? rows.map((r) => r.id) : [])} /></th>
                  <th className="px-2 py-2.5">Car</th>
                  <th className="px-2 py-2.5">Price</th>
                  <th className="px-2 py-2.5">Miles</th>
                  <th className="px-2 py-2.5">Photos</th>
                  <th className="px-2 py-2.5">Status</th>
                  <th className="px-2 py-2.5">Health & issues</th>
                  {owner && <th className="px-2 py-2.5">Owner only</th>}
                  <th className="px-2 py-2.5" />
                </tr>
              </thead>
              <tbody>
                {rows.map((v) => {
                  const iss = vehicleIssues(v, s.vehicles)
                  return (
                    <tr key={v.id} data-tour={`row-${v.id}`} className={cx('border-t border-silver-100 align-middle hover:bg-silver-50/60', v.archived && 'opacity-60')}>
                      <td className="px-3"><input type="checkbox" aria-label={`Select ${v.stock}`} className="accent-brand-600" checked={sel.includes(v.id)} onChange={(e) => setSel(e.target.checked ? [...sel, v.id] : sel.filter((x) => x !== v.id))} /></td>
                      <td className="px-2 py-2.5">
                        <button onClick={() => setUi({ vehicleId: v.id })} className="flex items-center gap-3 text-left">
                          <div className="h-11 w-16 shrink-0 overflow-hidden rounded-md ring-1 ring-silver-200"><CarArt v={v} shot={v.photos[0]?.shot} src={v.photos[0]?.src} label={false} /></div>
                          <div>
                            <div className="font-semibold hover:text-brand-700">{v.year} {v.make || 'New'} {v.model || 'draft'}</div>
                            <div className="text-[11px] text-ink-500">{v.stock} · {v.trim || '—'} · <Avatar id={v.assignedTo} /></div>
                          </div>
                        </button>
                      </td>
                      <td className={cx('px-2', v.price == null && 'font-semibold text-brand-700')}>{priceLabel(v)}</td>
                      <td className={cx('px-2', v.mileage == null && 'font-semibold text-brand-700')}>{v.mileage == null ? 'Missing' : v.mileage.toLocaleString()}</td>
                      <td className={cx('px-2', v.photos.length < 8 && 'font-semibold text-amber-700')}>{v.photos.length}</td>
                      <td className="px-2">
                        <div className="flex flex-col gap-1">
                          <Badge tone={v.status === 'available' ? 'green' : v.status === 'pending' ? 'amber' : v.status === 'sold' ? 'dark' : 'red'}>{statusLabel(v)}</Badge>
                          <Badge tone={v.listing === 'published' ? 'blue' : 'gray'}>{v.listing === 'published' ? 'On website' : v.listing === 'draft' ? 'Draft' : 'Hidden'}</Badge>
                        </div>
                      </td>
                      <td className="px-2">
                        <div className="flex items-center gap-2">
                          <ScoreRing score={vehicleScore(v, s.vehicles)} size={36} />
                          <div className="flex max-w-[260px] flex-wrap gap-1">
                            {iss.slice(0, 3).map((i) => <Badge key={i.code} tone={i.severity === 'high' ? 'red' : i.severity === 'med' ? 'amber' : 'gray'} title={i.plain}>{i.label}</Badge>)}
                            {iss.length > 3 && <Badge>+{iss.length - 3}</Badge>}
                            {!iss.length && <span className="text-[12px] text-emerald-700">All good</span>}
                          </div>
                        </div>
                      </td>
                      {owner && (
                        <td className="px-2 text-[11px] leading-tight text-ink-500">
                          Cost {money(v.cost)} · Prep {money(v.prepCost)}<br />
                          {v.price != null ? <>Est. gross <b className="text-ink-800">{money(v.price - v.cost - v.prepCost)}</b></> : 'Gross: set price'} · {v.daysOnLot}d
                        </td>
                      )}
                      <td className="px-2">
                        <div className="flex gap-1">
                          <Btn size="xs" variant="primary" onClick={() => setUi({ vehicleId: v.id })}>Edit</Btn>
                          <PreviewBtn v={v} />
                        </div>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
          {!rows.length && <div className="p-6"><Empty title="No cars here" body="Try another search or tab." /></div>}
        </Card>
      )}

      <ImportModal open={importOpen} onClose={() => setImportOpen(false)} />
      {ui.vehicleId && !ui.split && <EditorDrawer id={ui.vehicleId} />}
      {ui.vehicleId && ui.split && <SplitView id={ui.vehicleId} />}
    </div>
  )
}

function PreviewBtn({ v, label = false }: { v: Vehicle; label?: boolean }) {
  const { go } = useStore()
  return <Btn size="xs" variant="secondary" icon={<Eye className="h-3.5 w-3.5" />} onClick={() => go(`/inventory/${slugOf(v)}${isPublic(v) ? '' : '?preview=1'}`)}>{label ? 'Preview public listing' : 'Preview'}</Btn>
}

// ---------------------------------------------------------------- Editor
type Draft = Pick<Vehicle, 'year' | 'make' | 'model' | 'trim' | 'body' | 'vin' | 'price' | 'mileage' | 'description' | 'conditionNotes' | 'disclosure' | 'titleStatus' | 'color' | 'engine' | 'transmission' | 'drivetrain' | 'fuel' | 'status' | 'assignedTo' | 'cost' | 'prepCost'> & { features: string }

const toDraft = (v: Vehicle): Draft => ({ year: v.year, make: v.make, model: v.model, trim: v.trim, body: v.body, vin: v.vin, price: v.price, mileage: v.mileage, description: v.description, conditionNotes: v.conditionNotes, disclosure: v.disclosure, titleStatus: v.titleStatus, color: v.color, engine: v.engine, transmission: v.transmission, drivetrain: v.drivetrain, fuel: v.fuel, status: v.status, assignedTo: v.assignedTo, cost: v.cost, prepCost: v.prepCost, features: v.features.join(', ') })

const LABELS: Record<string, string> = { price: 'Price', mileage: 'Mileage', vin: 'VIN', trim: 'Trim', description: 'Description', features: 'Features', status: 'Availability', conditionNotes: 'Dealer notes', year: 'Year', make: 'Make', model: 'Model', body: 'Body', color: 'Color', engine: 'Engine', transmission: 'Transmission', drivetrain: 'Drive', fuel: 'Fuel', disclosure: 'Disclosure', titleStatus: 'Title status', assignedTo: 'Assigned to', cost: 'Cost', prepCost: 'Prep cost' }

function useEditor(id: string) {
  const { s } = useStore()
  const v = s.vehicles.find((x) => x.id === id)!
  const [d, setD] = useState<Draft>(() => toDraft(v))
  const [dmsChoice, setDmsChoice] = useState<'web' | 'dms' | null>(null)
  useEffect(() => { setD(toDraft(v)); setDmsChoice(null) }, [id, v.updatedAt])
  // Guided tour can type verified values into the form (staff still presses Approve)
  useEffect(() => {
    const on = (e: Event) => setD((cur) => ({ ...cur, ...(e as CustomEvent<Partial<Draft>>).detail }))
    window.addEventListener('demo-fill', on)
    return () => window.removeEventListener('demo-fill', on)
  }, [])
  const base = toDraft(v)
  const changed = (Object.keys(d) as (keyof Draft)[]).filter((k) => String(d[k] ?? '') !== String(base[k] ?? ''))
  return { v, d, setD, changed, base, dmsChoice, setDmsChoice }
}

function commit(s: DataState, ed: ReturnType<typeof useEditor>, act: ReturnType<typeof useStore>['act']) {
  const { v, d, changed, base } = ed
  const patch: Partial<Vehicle> = {}
  const changes: { label: string; before: string; after: string }[] = []
  for (const k of changed) {
    const val = k === 'features' ? d.features.split(',').map((x) => x.trim()).filter(Boolean) : d[k]
    ;(patch as Record<string, unknown>)[k] = val
    changes.push({ label: LABELS[k] ?? k, before: String(base[k] ?? 'empty') || 'empty', after: String(d[k] ?? 'empty') })
  }
  if (changed.includes('vin') && v.dmsVin) patch.dmsVin = undefined
  if (changed.includes('trim') && v.dmsTrim && d.trim === v.dmsTrim) patch.dmsTrim = undefined
  if (changed.includes('status')) {
    if (v.dmsStatus && (d.status === v.dmsStatus || (v.dmsStatus === 'sold' && d.status === 'sold'))) patch.dmsStatus = undefined
  }
  act((st, c) => applyVehicle(st, c, v.id, patch, changes))
}

function EditorDrawer({ id }: { id: string }) {
  const { s, setUi, act, can } = useStore()
  const ed = useEditor(id)
  if (!ed.v) return null
  const { v, changed } = ed
  const approve = can('approve:listing')
  return (
    <Drawer
      open
      onClose={() => setUi({ vehicleId: null })}
      width="max-w-6xl"
      title={<span className="flex items-center gap-2">Edit {v.year} {v.make} {v.model} <span className="font-mono text-xs text-ink-500">{v.stock}</span> {v.archived && <Badge>Archived</Badge>}</span>}
      footer={
        <>
          <span className="mr-auto text-[12px] text-ink-500">{changed.length ? <b className="text-amber-700">{changed.length} unsaved change{changed.length > 1 ? 's' : ''}: {changed.map((k) => LABELS[k] ?? k).join(', ')}</b> : 'No unsaved changes'} · Last updated {ago(v.updatedAt, s.now)}</span>
          <Btn variant="ghost" disabled={!changed.length} onClick={() => ed.setD(ed.base)}>Undo changes</Btn>
          <Btn data-tour="approve-listing" variant="success" disabled={!changed.length || !approve} icon={<CheckCircle2 className="h-4 w-4" />} onClick={() => commit(s, ed, act)}>Approve changes → update website</Btn>
        </>
      }
    >
      <div className="grid gap-0 lg:grid-cols-[1fr_380px]">
        <EditorForm ed={ed} />
        <div className="space-y-4 border-silver-200 bg-panel-soft p-5 lg:border-l">
          <HealthPanel ed={ed} />
          <BeforeAfterPreview ed={ed} />
          <ListingActions v={v} />
        </div>
      </div>
    </Drawer>
  )
}

function SplitView({ id }: { id: string }) {
  const { s, setUi, act, can } = useStore()
  const ed = useEditor(id)
  const v = ed.v
  return (
    <div className="fixed inset-0 z-[60] flex flex-col bg-white">
      <div className="flex items-center justify-between gap-2 border-b border-silver-200 bg-ink-900 px-4 py-2.5 text-white">
        <div className="flex items-center gap-2 text-sm font-semibold"><Columns2 className="h-4 w-4" /> Side-by-side: edit here → the customer website updates there</div>
        <div className="flex gap-2">
          <Btn data-tour="approve-listing" size="sm" variant="success" disabled={!ed.changed.length || !can("approve:listing")} onClick={() => commit(s, ed, act)}>Approve changes</Btn>
          <Btn size="sm" variant="white" onClick={() => setUi({ split: false })}>Exit side-by-side</Btn>
        </div>
      </div>
      <div className="grid flex-1 overflow-hidden lg:grid-cols-2">
        <div className="scroll-thin overflow-y-auto border-r border-silver-200">
          <div className="border-b border-silver-100 bg-silver-50 px-5 py-2 text-[11px] font-bold uppercase tracking-wide text-ink-500">Staff portal · listing editor</div>
          <EditorForm ed={ed} compact />
        </div>
        <div className="scroll-thin overflow-y-auto bg-pearl">
          <div className="border-b border-silver-100 bg-white px-5 py-2 text-[11px] font-bold uppercase tracking-wide text-brand-700">Customer website · live demo view</div>
          <div className="p-5"><PublicPreview v={v} /></div>
        </div>
      </div>
    </div>
  )
}

export function PublicPreview({ v }: { v: Vehicle }) {
  const { s } = useStore()
  return (
    <div key={v.updatedAt} className="flash mx-auto max-w-lg overflow-hidden rounded-2xl border border-silver-200 bg-white shadow-sm">
      {!isPublic(v) && <div className="bg-amber-50 px-4 py-2 text-[12px] font-semibold text-amber-900">Not visible to shoppers right now ({v.archived ? 'archived' : v.status === 'sold' ? 'sold' : v.listing})</div>}
      <div className="aspect-[16/10]"><CarArt v={v} shot={v.photos[0]?.shot} src={v.photos[0]?.src} /></div>
      <div className="flex gap-1 overflow-hidden p-2">{v.photos.slice(1, 7).map((p) => <div key={p.id} className="h-10 w-14 shrink-0 overflow-hidden rounded"><CarArt v={v} shot={p.shot} src={p.src} label={false} /></div>)}</div>
      <div className="p-5 pt-2">
        <Badge tone={v.status === 'available' ? 'green' : 'amber'}>{statusLabel(v)}</Badge>
        <h3 className="mt-2 text-xl font-black">{v.year} {v.make} {v.model}</h3>
        <div className="text-sm text-ink-500">{v.trim} · {v.color}</div>
        <div className="mt-3 border-y border-silver-100 py-3" data-tour="preview-price"><PriceTag v={v} size="lg" /></div>
        <div className="mt-3 grid grid-cols-3 gap-2 text-sm">
          <div className="rounded-lg bg-silver-50 p-2"><div className="text-[11px] text-ink-500">Mileage</div><div className={cx('font-bold', v.mileage == null && 'font-normal italic text-amber-700')}>{v.mileage == null ? 'Confirm with dealer' : milesLabel(v)}</div></div>
          <div className="rounded-lg bg-silver-50 p-2"><div className="text-[11px] text-ink-500">Photos</div><div className="font-bold">{v.photos.length}</div></div>
          <div className="rounded-lg bg-silver-50 p-2"><div className="text-[11px] text-ink-500">Stock</div><div className="font-bold">{v.stock}</div></div>
        </div>
        <p className="mt-3 text-[13px] leading-relaxed text-ink-700">{v.description}</p>
        <div className="mt-2 text-[11px] text-ink-400">Updated {s.now.slice(11)} ET · demo</div>
      </div>
    </div>
  )
}

function EditorForm({ ed, compact }: { ed: ReturnType<typeof useEditor>; compact?: boolean }) {
  const { s, act, can } = useStore()
  const { v, d, setD } = ed
  const owner = s.role === 'owner'
  const [decoded, setDecoded] = useState<Partial<Vehicle> | null | 'none'>(null)
  const [genDesc, setGenDesc] = useState<string | null>(null)
  const set = <K extends keyof Draft>(k: K, val: Draft[K]) => setD({ ...d, [k]: val })
  const priceRef = useRef<HTMLInputElement>(null)
  const milesRef = useRef<HTMLInputElement>(null)
  useEffect(() => {
    const on = (e: Event) => {
      const f = (e as CustomEvent<string>).detail
      const el = f === 'price' ? priceRef.current : milesRef.current
      el?.scrollIntoView({ behavior: 'smooth', block: 'center' })
      el?.focus()
    }
    window.addEventListener('demo-focus-field', on)
    return () => window.removeEventListener('demo-focus-field', on)
  }, [])
  const hl = (k: keyof Draft) => ed.changed.includes(k) ? 'ring-2 ring-amber-300 border-amber-400' : ''

  return (
    <div className="space-y-6 p-5">
      <Help>Edit what's true about this car, then press <b>Approve changes</b>. Only verified facts — never guess mileage, history or condition.</Help>

      <section>
        <h4 className="mb-3 flex items-center gap-2 text-sm font-bold"><Tag className="h-4 w-4 text-brand-600" /> Price & mileage</h4>
        <div className="grid gap-3 sm:grid-cols-3">
          <Field label="Asking price ($)" hint={d.price == null ? 'Blank = shoppers see “Call for price”' : 'Shown on the website (dealer fees per Settings)'}>
            <Input data-tour="field-price" ref={priceRef} className={hl('price')} type="number" min={0} value={d.price ?? ''} placeholder="Please Call" onChange={(e) => set('price', e.target.value === '' ? null : Number(e.target.value))} />
          </Field>
          <Field label="Mileage (from the odometer)" hint="Read it off the car — don't estimate">
            <Input data-tour="field-miles" ref={milesRef} className={hl('mileage')} type="number" min={0} value={d.mileage ?? ''} placeholder="Not entered" onChange={(e) => set('mileage', e.target.value === '' ? null : Number(e.target.value))} />
          </Field>
          <Field label="Availability">
            <Select className={hl('status')} value={d.status} onChange={(e) => set('status', e.target.value as VehicleStatus)}>
              <option value="available">Available</option><option value="pending">Sale pending</option><option value="sold">Sold (removes from website)</option><option value="unclear">Unclear — needs checking</option>
            </Select>
          </Field>
        </div>
      </section>

      <section>
        <h4 className="mb-3 flex items-center gap-2 text-sm font-bold"><ScanLine className="h-4 w-4 text-brand-600" /> Basics</h4>
        <div className="grid gap-3 sm:grid-cols-4">
          <Field label="Year"><Input className={hl('year')} type="number" value={d.year} onChange={(e) => set('year', Number(e.target.value))} /></Field>
          <Field label="Make"><Input className={hl('make')} value={d.make} onChange={(e) => set('make', e.target.value)} /></Field>
          <Field label="Model"><Input className={hl('model')} value={d.model} onChange={(e) => set('model', e.target.value)} /></Field>
          <Field label="Trim"><Input className={hl('trim')} value={d.trim} onChange={(e) => set('trim', e.target.value)} /></Field>
          <Field label="VIN (demo)" className="sm:col-span-2">
            <div className="flex gap-2">
              <Input className={cx('font-mono text-[12px]', hl('vin'))} value={d.vin} onChange={(e) => set('vin', e.target.value)} />
              <Btn type="button" size="sm" onClick={() => setDecoded(mockDecode(d.vin) ?? 'none')}>Decode</Btn>
            </div>
          </Field>
          <Field label="Body"><Select className={hl('body')} value={d.body} onChange={(e) => set('body', e.target.value as Vehicle['body'])}>{['Sedan', 'SUV', 'Truck', 'Hatchback', 'Coupe', 'Van'].map((b) => <option key={b}>{b}</option>)}</Select></Field>
          <Field label="Color"><Input className={hl('color')} value={d.color} onChange={(e) => set('color', e.target.value)} /></Field>
        </div>
        {decoded && (
          <div className="rise mt-3 rounded-xl border border-dashed border-silver-400 bg-silver-50 p-3 text-[13px]">
            <div className="mb-1 flex items-center justify-between"><b>VIN decode — MOCK result</b><button onClick={() => setDecoded(null)} aria-label="Close"><X className="h-4 w-4" /></button></div>
            {decoded === 'none' ? <p>No mock match for this demo VIN.</p> : (
              <>
                <p>{Object.entries(decoded).map(([k, val]) => `${LABELS[k] ?? k}: ${val}`).join(' · ')}</p>
                <Btn size="xs" className="mt-2" onClick={() => { const fill: Partial<Draft> = {}; Object.entries(decoded).forEach(([k, val]) => { if (!d[k as keyof Draft]) (fill as Record<string, unknown>)[k] = val }); setD({ ...d, ...fill }); setDecoded(null) }}>Fill empty fields only</Btn>
              </>
            )}
            <p className="mt-2 text-[11px] text-ink-500">In production this could use NHTSA's free vPIC service (manufacturer-submitted data). Staff must still verify trim, options and condition.</p>
          </div>
        )}
      </section>

      {!compact && (
        <section>
          <h4 className="mb-3 text-sm font-bold">Specs</h4>
          <div className="grid gap-3 sm:grid-cols-4">
            <Field label="Engine"><Input className={hl('engine')} value={d.engine} onChange={(e) => set('engine', e.target.value)} /></Field>
            <Field label="Transmission"><Input className={hl('transmission')} value={d.transmission} onChange={(e) => set('transmission', e.target.value)} /></Field>
            <Field label="Drive"><Input className={hl('drivetrain')} value={d.drivetrain} onChange={(e) => set('drivetrain', e.target.value)} /></Field>
            <Field label="Fuel"><Input className={hl('fuel')} value={d.fuel} onChange={(e) => set('fuel', e.target.value)} /></Field>
          </div>
        </section>
      )}

      <section>
        <h4 className="mb-3 flex items-center gap-2 text-sm font-bold"><Wand2 className="h-4 w-4 text-brand-600" /> Description & features</h4>
        <Field label="Description shown to shoppers">
          <Textarea className={hl('description')} value={d.description} onChange={(e) => set('description', e.target.value)} />
        </Field>
        <div className="mt-2 flex flex-wrap gap-2">
          <Btn data-tour="gen-desc" size="sm" icon={<Sparkles className="h-4 w-4" />} onClick={() => setGenDesc(factualDescription({ ...v, ...d, features: d.features.split(',').map((x) => x.trim()).filter(Boolean) } as Vehicle))}>Write factual description (AI)</Btn>
        </div>
        {genDesc && (
          <div className="rise mt-3 rounded-xl border border-violet-200 bg-violet-50/60 p-3 text-[13px]">
            <div className="mb-1 font-bold text-violet-900">AI draft — built only from the fields above</div>
            <p className="rounded-lg bg-white p-2 ring-1 ring-violet-100">{genDesc}</p>
            <div className="mt-2 text-[11px] text-violet-900">Left out on purpose (not verified): {EXCLUDED_CLAIMS.join(', ')}.</div>
            <div className="mt-2 flex gap-2"><Btn size="xs" variant="primary" onClick={() => { set('description', genDesc); setGenDesc(null) }}>Use this draft</Btn><Btn size="xs" variant="ghost" onClick={() => setGenDesc(null)}>Discard</Btn></div>
          </div>
        )}
        {!compact && (
          <div className="mt-3 grid gap-3 sm:grid-cols-2">
            <Field label="Features (comma-separated, dealer-verified)"><Input className={hl('features')} value={d.features} onChange={(e) => set('features', e.target.value)} /></Field>
            <Field label="Dealer condition notes (shown as 'From the dealer')"><Input className={hl('conditionNotes')} value={d.conditionNotes} onChange={(e) => set('conditionNotes', e.target.value)} placeholder="e.g. small scuff on rear bumper" /></Field>
          </div>
        )}
      </section>

      <PhotoManager v={v} />

      {!compact && (
        <section>
          <h4 className="mb-3 text-sm font-bold">Disclosures & paperwork</h4>
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Warranty / As-Is disclosure"><Input className={hl('disclosure')} value={d.disclosure} onChange={(e) => set('disclosure', e.target.value)} /></Field>
            <Field label="Title status (admin)"><Input className={hl('titleStatus')} value={d.titleStatus} onChange={(e) => set('titleStatus', e.target.value)} /></Field>
            <Field label="Assigned to"><Select className={hl('assignedTo')} value={d.assignedTo} onChange={(e) => set('assignedTo', e.target.value as Draft['assignedTo'])}>{s.members.map((m) => <option key={m.id} value={m.id}>{m.label}</option>)}</Select></Field>
            <Field label="Acquired"><Input value={v.acquired} disabled /></Field>
          </div>
        </section>
      )}

      {owner && !compact && (
        <section className="rounded-xl border border-silver-300 bg-silver-50 p-4">
          <h4 className="mb-3 text-sm font-bold">Owner only — never shown publicly</h4>
          <div className="grid gap-3 sm:grid-cols-3">
            <Field label="Acquisition cost ($)"><Input className={hl('cost')} type="number" value={d.cost} onChange={(e) => set('cost', Number(e.target.value))} /></Field>
            <Field label="Prep / recon cost ($)"><Input className={hl('prepCost')} type="number" value={d.prepCost} onChange={(e) => set('prepCost', Number(e.target.value))} /></Field>
            <div className="text-sm"><div className="text-[12px] font-semibold text-ink-700">Est. gross / days</div><div className="mt-2 font-bold">{d.price != null ? money(d.price - d.cost - d.prepCost) : '—'} · {v.daysOnLot} days</div></div>
          </div>
        </section>
      )}
      {!can('approve:listing') && <Badge tone="amber">Your role can't approve listing changes</Badge>}
    </div>
  )
}

function PhotoManager({ v }: { v: Vehicle }) {
  const { act } = useStore()
  const [drag, setDrag] = useState<number | null>(null)
  const [suggest, setSuggest] = useState(false)
  const fileRef = useRef<HTMLInputElement>(null)
  const missing = PHOTO_SHOTS.slice(0, 10).filter((sh) => !v.photos.some((p) => p.shot === sh))
  const onFiles = (files: FileList | null) => {
    if (!files?.length) return
    const arr = Array.from(files).slice(0, 8)
    Promise.all(arr.map((f) => new Promise<string>((res) => { const r = new FileReader(); r.onload = () => res(String(r.result)); r.readAsDataURL(f) }))).then((srcs) => act((st, c) => addPhotos(st, c, v.id, srcs)))
  }
  const rank = (shot: string) => { const i = PHOTO_SHOTS.indexOf(shot); return i < 0 ? 99 : i }
  const suggested = [...v.photos].sort((a, b) => rank(a.shot) - rank(b.shot))
  return (
    <section>
      <div className="mb-3 flex flex-wrap items-center justify-between gap-2">
        <h4 className="flex items-center gap-2 text-sm font-bold"><ImagePlus className="h-4 w-4 text-brand-600" /> Photos ({v.photos.length}) <span className="text-[11px] font-normal text-ink-500">Drag to reorder · saves instantly</span></h4>
        <div className="flex flex-wrap gap-2">
          <input ref={fileRef} type="file" accept="image/*" multiple className="hidden" onChange={(e) => onFiles(e.target.files)} />
          <Btn size="xs" icon={<Upload className="h-3.5 w-3.5" />} onClick={() => fileRef.current?.click()}>Upload photos</Btn>
          <Btn data-tour="add-photos" size="xs" onClick={() => act((st, c) => addPhotos(st, c, v.id, Array.from({ length: Math.min(4, Math.max(1, 10 - v.photos.length)) }, () => undefined)))}>Add sample photos</Btn>
          <Btn size="xs" icon={<Sparkles className="h-3.5 w-3.5" />} onClick={() => setSuggest(!suggest)}>Suggest photo order</Btn>
        </div>
      </div>
      {suggest && (
        <div className="rise mb-3 rounded-xl border border-violet-200 bg-violet-50/60 p-3">
          <div className="mb-2 text-[12px] font-bold text-violet-900">Suggested order: exterior first, then interior, then details</div>
          <div className="flex gap-1 overflow-x-auto">{suggested.slice(0, 10).map((p, i) => <div key={p.id} className="relative h-12 w-16 shrink-0 overflow-hidden rounded"><CarArt v={v} shot={p.shot} src={p.src} label={false} /><span className="absolute left-0.5 top-0.5 rounded bg-white/90 px-1 text-[9px] font-bold">{i + 1}</span></div>)}</div>
          <div className="mt-2 flex gap-2"><Btn size="xs" variant="primary" onClick={() => { act((st, c) => applyPhotoOrder(st, c, v.id)); setSuggest(false) }}>Approve order</Btn><Btn size="xs" variant="ghost" onClick={() => setSuggest(false)}>Cancel</Btn></div>
        </div>
      )}
      <div className="grid grid-cols-3 gap-2 sm:grid-cols-5">
        {v.photos.map((p, i) => (
          <div key={p.id} draggable onDragStart={() => setDrag(i)} onDragOver={(e) => e.preventDefault()} onDrop={() => { if (drag != null) act((st) => reorderPhoto(st, v.id, drag, i)); setDrag(null) }} className="group relative aspect-[4/3] cursor-grab overflow-hidden rounded-lg ring-1 ring-silver-200">
            <CarArt v={v} shot={p.shot} src={p.src} label={false} />
            <span className="absolute left-1 top-1 rounded bg-ink-900/75 px-1 text-[10px] font-bold text-white">{i + 1}</span>
            {i === 0 && <span className="absolute right-1 top-1 rounded bg-brand-600 px-1 text-[9px] font-bold text-white">MAIN</span>}
            <div className="absolute inset-x-0 bottom-0 flex items-center justify-between bg-white/90 px-1 py-0.5 opacity-0 transition group-hover:opacity-100">
              <GripVertical className="h-3 w-3 text-ink-400" />
              <span className="truncate text-[9px]">{p.shot}</span>
              <span className="flex">
                <button aria-label="Move earlier" onClick={() => act((st) => reorderPhoto(st, v.id, i, i - 1))}><ArrowUp className="h-3 w-3" /></button>
                <button aria-label="Move later" onClick={() => act((st) => reorderPhoto(st, v.id, i, i + 1))}><ArrowDown className="h-3 w-3" /></button>
              </span>
            </div>
          </div>
        ))}
        {!v.photos.length && <div className="col-span-full"><Empty title="No photos yet" body="Upload real photos of this exact car. Demo uploads stay in your browser." /></div>}
      </div>
      {missing.length > 0 && <p className="mt-2 text-[11px] text-ink-500">Checklist — still missing: {missing.join(' · ')}</p>}
      <p className="mt-1 text-[11px] text-ink-500">Photos must show the actual vehicle, including any wear. Any AI background cleanup must keep the car and its condition unchanged and be approved by a person.</p>
    </section>
  )
}

function HealthPanel({ ed }: { ed: ReturnType<typeof useEditor> }) {
  const { s, act, can } = useStore()
  const { v, d, setD } = ed
  const iss = vehicleIssues(v, s.vehicles)
  const approve = can('approve:listing')
  const fix = (i: Issue): React.ReactNode => {
    switch (i.code) {
      case 'price': return <Btn size="xs" onClick={() => window.dispatchEvent(new CustomEvent('demo-focus-field', { detail: 'price' }))}>Enter verified price</Btn>
      case 'mileage': return <Btn size="xs" onClick={() => window.dispatchEvent(new CustomEvent('demo-focus-field', { detail: 'mileage' }))}>Enter odometer reading</Btn>
      case 'description': return <Btn size="xs" onClick={() => setD({ ...d, description: factualDescription({ ...v, ...d, features: v.features } as Vehicle) })}>Insert factual draft</Btn>
      case 'photos': return <Btn size="xs" onClick={() => act((st, c) => addPhotos(st, c, v.id, Array.from({ length: 8 - v.photos.length }, () => undefined)))}>Add sample photos</Btn>
      case 'vin': return (
        <div className="flex flex-wrap gap-1">
          <Btn size="xs" onClick={() => undefined} disabled>Website: …{v.vin.slice(-5)}</Btn>
          <Btn size="xs" onClick={() => { act((st, c) => { const x = st.vehicles.find((y) => y.id === v.id)!; x.dmsVin = undefined; x.syncState = 'staged'; log(st, 'approval', `VIN conflict on ${x.stock}: kept website VIN (verified on vehicle)`, true, { screen: 'listings', id: x.id }); st.sync.forEach((it) => { if (it.vehicleId === x.id && it.state === 'conflict') it.state = 'resolved' }); c.toast('VIN conflict resolved — website value kept.', 'ok') }) }}>Keep website VIN</Btn>
          <Btn size="xs" onClick={() => setD({ ...d, vin: v.dmsVin! })}>Use DMS VIN</Btn>
        </div>
      )
      case 'trim': return <Btn size="xs" onClick={() => setD({ ...d, trim: v.dmsTrim! })}>Use DMS trim “{v.dmsTrim}”</Btn>
      case 'duplicate': return <Btn size="xs" variant="danger" disabled={!approve} onClick={() => { if (confirm('Archive this duplicate listing? You can restore it later.')) act((st, c) => archiveVehicle(st, c, v.id, true)) }}>Archive duplicate</Btn>
      case 'soldNotRemoved': return <Btn size="xs" variant="danger" disabled={!approve} onClick={() => act((st, c) => setVStatus(st, c, v.id, 'sold'))}>Mark sold (remove from site)</Btn>
      case 'availability': return <Btn size="xs" onClick={() => setD({ ...d, status: v.dmsStatus && v.dmsStatus !== 'sold' ? v.dmsStatus : 'available' })}>Use DMS status: {v.dmsStatus ?? 'available'}</Btn>
      case 'stale': return <Btn size="xs" onClick={() => act((st, c) => { const x = st.vehicles.find((y) => y.id === v.id)!; x.reviewTask = true; st.tasks.unshift({ id: uid(st, 'tk'), title: `Review aged unit ${x.stock} (${x.daysOnLot} days)`, owner: 'owner', due: addMin(st.now, 1440), status: 'todo', link: { screen: 'listings', id: x.id }, createdBy: 'ai' }); log(st, 'suggestion', `Review task created for aged unit ${x.stock} — no market pricing used`, false, { screen: 'listings', id: x.id }); c.toast('Review task assigned to Owner.', 'ok') })}>Assign review task</Btn>
      default: return null
    }
  }
  return (
    <div data-tour="health">
      <div className="mb-3 flex items-center gap-3">
        <ScoreRing score={vehicleScore(v, s.vehicles)} size={56} />
        <div>
          <div className="text-sm font-bold">Listing health</div>
          <div className="text-[12px] text-ink-500">{iss.length ? `${iss.length} thing${iss.length > 1 ? 's' : ''} to fix` : 'Everything checks out'}</div>
        </div>
      </div>
      <div className="space-y-2">
        {iss.map((i) => (
          <div key={i.code} className="rounded-xl border border-silver-200 bg-white p-3">
            <div className="flex items-start gap-2">
              <AlertTriangle className={cx('mt-0.5 h-4 w-4 shrink-0', i.severity === 'high' ? 'text-brand-600' : i.severity === 'med' ? 'text-amber-600' : 'text-ink-400')} />
              <div className="min-w-0 flex-1">
                <div className="text-[13px] font-semibold">{i.plain}</div>
                <div className="text-[11px] text-ink-500">{i.detail}</div>
                <div className="mt-2">{fix(i)}</div>
              </div>
              <span className="text-[11px] font-bold text-ink-400">−{i.points}</span>
            </div>
          </div>
        ))}
        {!iss.length && <div className="flex items-center gap-2 rounded-xl bg-emerald-50 p-3 text-[13px] font-semibold text-emerald-800"><CheckCircle2 className="h-4 w-4" /> No issues found</div>}
      </div>
    </div>
  )
}

function BeforeAfterPreview({ ed }: { ed: ReturnType<typeof useEditor> }) {
  const { s } = useStore()
  const { v, d, changed } = ed
  if (!changed.length) return null
  const proposed = { ...v, ...d, features: d.features.split(',').map((x) => x.trim()).filter(Boolean) } as Vehicle
  const row = (label: string, a: string, b: string) => a !== b && (
    <div key={label} className="grid grid-cols-[80px_1fr_1fr] gap-2 border-t border-silver-100 py-1.5 text-[12px]">
      <span className="font-semibold text-ink-500">{label}</span>
      <span className="text-ink-500 line-through decoration-brand-600/50">{a || 'empty'}</span>
      <span className="font-semibold text-emerald-700">{b || 'empty'}</span>
    </div>
  )
  return (
    <div className="rise rounded-xl border border-amber-200 bg-white p-3" data-tour="before-after-fix">
      <div className="mb-1 text-[13px] font-bold">Before → Proposed fix</div>
      <div className="mb-1 grid grid-cols-[80px_1fr_1fr] gap-2 text-[10px] font-bold uppercase text-ink-400"><span /><span>Now on website</span><span>After approval</span></div>
      {row('Price', priceLabel(v), priceLabel(proposed))}
      {row('Mileage', milesLabel(v), milesLabel(proposed))}
      {row('Status', statusLabel(v), statusLabel(proposed))}
      {row('Trim', v.trim, proposed.trim)}
      {row('VIN', v.vin, proposed.vin)}
      {row('Description', v.description.slice(0, 50) + (v.description.length > 50 ? '…' : ''), proposed.description.slice(0, 50) + (proposed.description.length > 50 ? '…' : ''))}
      <div className="mt-2 flex items-center justify-between rounded-lg bg-silver-50 px-2 py-1.5 text-[12px]">
        <span>Health score</span>
        <span className="font-bold">{vehicleScore(v, s.vehicles)} → <span className="text-emerald-700">{vehicleScore(proposed, s.vehicles)}</span></span>
      </div>
    </div>
  )
}

function ListingActions({ v }: { v: Vehicle }) {
  const { act, setUi, can } = useStore()
  const ok = can('approve:listing')
  return (
    <div className="space-y-2">
      <div className="text-[11px] font-bold uppercase tracking-wide text-ink-500">Listing actions</div>
      <div className="grid grid-cols-2 gap-2">
        <PreviewBtn v={v} label />
        <Btn data-tour="split" size="xs" variant="dark" icon={<Columns2 className="h-3.5 w-3.5" />} onClick={() => setUi({ split: true })}>Side-by-side view</Btn>
        {v.listing === 'published' ? (
          <Btn size="xs" disabled={!ok} icon={<EyeOff className="h-3.5 w-3.5" />} onClick={() => act((st, c) => setListing(st, c, v.id, 'unpublished'))}>Unpublish</Btn>
        ) : (
          <Btn data-tour="publish" size="xs" variant="primary" disabled={!ok || !v.make} icon={<ExternalLink className="h-3.5 w-3.5" />} onClick={() => act((st, c) => setListing(st, c, v.id, 'published'))}>Publish to website</Btn>
        )}
        <Btn size="xs" disabled={!ok || v.status === 'pending'} icon={<Hourglass className="h-3.5 w-3.5" />} onClick={() => act((st, c) => setVStatus(st, c, v.id, 'pending'))}>Mark pending</Btn>
        <Btn size="xs" disabled={!ok || v.status === 'sold'} icon={<CheckCircle2 className="h-3.5 w-3.5" />} onClick={() => act((st, c) => setVStatus(st, c, v.id, 'sold'))}>Mark sold</Btn>
        <Btn size="xs" disabled={!ok} icon={<Copy className="h-3.5 w-3.5" />} onClick={() => act((st, c) => { const id = duplicateDraft(st, c, v.id); if (id) setUi({ vehicleId: id }) })}>Duplicate draft</Btn>
        {v.archived ? (
          <Btn size="xs" disabled={!ok} icon={<RefreshCw className="h-3.5 w-3.5" />} onClick={() => act((st, c) => archiveVehicle(st, c, v.id, false))}>Restore</Btn>
        ) : (
          <Btn size="xs" variant="danger" disabled={!ok} icon={<Archive className="h-3.5 w-3.5" />} onClick={() => { if (confirm(`Archive ${v.stock}? It will be hidden everywhere but can be restored.`)) act((st, c) => archiveVehicle(st, c, v.id, true)) }}>Archive</Btn>
        )}
      </div>
      <p className="text-[11px] text-ink-500">Nothing is ever hard-deleted in this demo. Every action is logged in the audit trail.</p>
    </div>
  )
}

function Aging() {
  const { s, setUi } = useStore()
  const act = s.vehicles.filter((v) => !v.archived && v.status !== 'sold')
  const buckets = [
    { label: '0–30 days', test: (d: number) => d <= 30, color: 'bg-emerald-500' },
    { label: '31–60 days', test: (d: number) => d > 30 && d <= 60, color: 'bg-sky-500' },
    { label: '61–90 days', test: (d: number) => d > 60 && d <= 90, color: 'bg-amber-500' },
    { label: '90+ days', test: (d: number) => d > 90, color: 'bg-brand-600' },
  ]
  const max = Math.max(1, ...buckets.map((b) => act.filter((v) => b.test(v.daysOnLot)).length))
  return (
    <div className="grid gap-4 lg:grid-cols-2">
      <Card>
        <CardHead title="How long cars have been on the lot" sub="Older units tie up cash. Tap a car to assign a review." right={<DemoTag />} />
        <div className="flex h-56 items-end gap-4 px-6 pb-4 pt-6">
          {buckets.map((b) => {
            const n = act.filter((v) => b.test(v.daysOnLot)).length
            return (
              <div key={b.label} className="flex flex-1 flex-col items-center gap-2">
                <span className="text-lg font-black">{n}</span>
                <div className={cx('w-full rounded-t-lg transition-all duration-500', b.color)} style={{ height: `${(n / max) * 140}px` }} />
                <span className="text-[11px] font-semibold text-ink-500">{b.label}</span>
              </div>
            )
          })}
        </div>
        <div className="px-5 pb-5"><Help>No market-pricing data is connected, so the system doesn't suggest price changes. It simply makes sure aged cars get a person's attention.</Help></div>
      </Card>
      <Card>
        <CardHead title="Oldest units" />
        <div className="divide-y divide-silver-100">
          {[...act].sort((a, b) => b.daysOnLot - a.daysOnLot).slice(0, 7).map((v) => (
            <button key={v.id} onClick={() => setUi({ vehicleId: v.id })} className="flex w-full items-center gap-3 px-5 py-2.5 text-left hover:bg-silver-50">
              <span className={cx('w-14 text-right text-sm font-black', v.daysOnLot > 90 ? 'text-brand-600' : v.daysOnLot > 60 ? 'text-amber-600' : 'text-ink-700')}>{v.daysOnLot}d</span>
              <span className="flex-1 text-[13px] font-semibold">{v.year} {v.make} {v.model} <span className="font-normal text-ink-500">· {v.stock}</span></span>
              {v.reviewTask ? <Badge tone="green">Review assigned</Badge> : v.daysOnLot > 90 ? <Badge tone="red">Needs review</Badge> : null}
              <span className="text-[12px] text-ink-500">{memberLabel(s, v.assignedTo)}</span>
            </button>
          ))}
        </div>
      </Card>
    </div>
  )
}

function SyncQueue() {
  const { s, act, setUi } = useStore()
  const tone = { staged: 'blue', exported: 'green', failed: 'red', conflict: 'amber', resolved: 'green' } as const
  const label = { staged: 'Queued — not sent', exported: 'Exported manually', failed: 'Failed (simulated)', conflict: 'Conflict — choose', resolved: 'Resolved' }
  return (
    <Card>
      <CardHead icon={<ClipboardList className="h-4 w-4" />} title="Changes waiting to go to your other systems" sub="Dealer Car Search / Frazer / DealerCenter integration-ready; connection requires dealer authorization and supported data access." right={<DemoTag>Nothing is sent</DemoTag>} />
      <div className="p-4"><Help>Approved edits update this demo website right away. For your existing systems, the realistic first step is a <b>CSV export</b> you upload yourself — or an official feed later, if your vendor supports it and you authorize it.</Help></div>
      <div className="divide-y divide-silver-100">
        {s.sync.map((it) => {
          const v = s.vehicles.find((x) => x.id === it.vehicleId)
          return (
            <div key={it.id} className="flex flex-wrap items-center gap-3 px-5 py-3 text-[13px]">
              <Badge tone={tone[it.state]}>{label[it.state]}</Badge>
              <button onClick={() => setUi({ vehicleId: it.vehicleId })} className="font-semibold hover:text-brand-700">{v?.stock} · {v?.year} {v?.make} {v?.model}</button>
              <span className="text-ink-500">{it.label}: {it.before && <span className="line-through">{it.before}</span>} → <b className="text-ink-800">{it.after}</b></span>
              <span className="text-[11px] text-ink-400">{it.target} · {ago(it.at, s.now)}</span>
              <span className="ml-auto flex gap-1">
                {it.state === 'staged' && <Btn size="xs" onClick={() => act((st, c) => resolveSync(st, c, it.id, 'exported'))}>Mark exported (CSV)</Btn>}
                {it.state === 'failed' && <Btn size="xs" onClick={() => act((st, c) => resolveSync(st, c, it.id, 'retry'))}>Retry (simulated)</Btn>}
                {it.state === 'conflict' && (
                  <>
                    <Btn size="xs" onClick={() => act((st, c) => resolveSync(st, c, it.id, 'keep-ours'))}>Keep website value</Btn>
                    <Btn size="xs" onClick={() => act((st, c) => resolveSync(st, c, it.id, 'keep-theirs'))}>Keep DMS value</Btn>
                  </>
                )}
              </span>
            </div>
          )
        })}
        {!s.sync.length && <div className="p-6"><Empty title="Queue is empty" body="Approve a listing change to see it queued here." /></div>}
      </div>
    </Card>
  )
}

function ImportModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const { act } = useStore()
  const [text, setText] = useState(SAMPLE_CSV)
  return (
    <Modal open={open} onClose={onClose} title="Import cars from a CSV file (demo)" footer={<><Btn variant="ghost" onClick={onClose}>Cancel</Btn><Btn variant="primary" onClick={() => { act((st, c) => importCsv(st, c, text)); onClose() }}>Import as drafts</Btn></>}>
      <p className="mb-2 text-[13px] text-ink-500">Paste rows or choose a file. Imported cars become <b>drafts</b> — hidden from shoppers until someone checks and publishes them.</p>
      <input type="file" accept=".csv,text/csv" className="mb-2 text-[12px]" onChange={(e) => { const f = e.target.files?.[0]; if (f) f.text().then(setText) }} />
      <Textarea className="min-h-[160px] font-mono text-[12px]" value={text} onChange={(e) => setText(e.target.value)} />
      <p className="mt-2 text-[11px] text-ink-500">Columns: stock, year, make, model, trim, body, mileage, price, color. Blank price/mileage are flagged automatically.</p>
    </Modal>
  )
}
