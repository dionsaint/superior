import { useState } from 'react'
import { AlertTriangle, Bot, CheckCircle2, Circle, CircleDashed, ClipboardCheck, FileSearch, FileText, Hourglass, Plus, ScrollText, Send, Wrench, XCircle } from 'lucide-react'
import { useStore } from '../store'
import type { DocStatus, MemberId, PromiseItem } from '../types'
import { DEAL_COLS, approveDocRequest, draftDocRequest, log, managerSummary, memberLabel, moveDeal, runDocCheck, uid } from '../actions'
import { checkDocText, dealMissing } from '../logic'
import { fmtWhen } from '../time'
import { Avatar, Badge, Btn, Card, CardHead, DemoTag, Drawer, Field, Help, Input, PageTitle, Select, Tabs, Toggle, cx } from '../ui'

const DOC_ICON: Record<DocStatus, JSX.Element> = {
  complete: <CheckCircle2 className="h-4 w-4 text-emerald-600" />,
  pending: <CircleDashed className="h-4 w-4 text-amber-600" />,
  missing: <XCircle className="h-4 w-4 text-brand-600" />,
  na: <Circle className="h-4 w-4 text-silver-300" />,
}

export function Deals() {
  const { s, ui, setUi, act } = useStore()
  const [tab, setTab] = useState<'board' | 'promises'>('board')
  const [drag, setDrag] = useState<string | null>(null)
  return (
    <div>
      <PageTitle
        kicker="Deal desk · documents · titles"
        title="Deals & Paperwork"
        plain="See which sales are ready to deliver and which are stuck. The AI checks sample paperwork for gaps, opens tasks and drafts requests — but it never signs, files with the DMV, approves loans or makes legal calls."
      />
      <div className="mb-4"><Tabs value={tab} onChange={setTab} items={[{ id: 'board', label: 'Deal readiness board' }, { id: 'promises', label: `"We owe" promises (${s.promises.filter((p) => p.status !== 'done').length})` }]} /></div>
      {tab === 'promises' ? <Promises /> : (
        <>
          <div className="scroll-thin grid auto-cols-[minmax(230px,1fr)] grid-flow-col gap-3 overflow-x-auto pb-3" data-tour="deal-board">
            {DEAL_COLS.map((c) => {
              const items = s.deals.filter((d) => d.stage === c.id)
              return (
                <div key={c.id} onDragOver={(e) => e.preventDefault()} onDrop={() => { if (drag) act((st, cx2) => moveDeal(st, cx2, drag, c.id)); setDrag(null) }} className={cx('rounded-xl border border-silver-200 bg-panel-soft p-2', c.id === 'delivery' && 'border-emerald-200 bg-emerald-50/40')}>
                  <div className="mb-2 flex items-center justify-between px-1">
                    <span className="text-[12px] font-bold text-ink-700">{c.label}</span>
                    <span className="rounded-full bg-white px-2 text-[12px] font-bold ring-1 ring-silver-200">{items.length}</span>
                  </div>
                  <div className="space-y-2">
                    {items.map((d) => {
                      const miss = dealMissing(d)
                      const done = d.docs.filter((x) => x.applicable && x.status === 'complete').length
                      const total = d.docs.filter((x) => x.applicable).length
                      return (
                        <button key={d.id} data-tour={`deal-${d.id}`} draggable onDragStart={() => setDrag(d.id)} onClick={() => setUi({ dealId: d.id })} className="block w-full rounded-lg border border-silver-200 bg-white p-3 text-left shadow-sm transition hover:border-brand-600">
                          <div className="flex items-center justify-between">
                            <span className="font-mono text-[11px] font-bold text-ink-500">{d.number}</span>
                            <Avatar id={d.salesperson} />
                          </div>
                          <div className="mt-1 text-[13px] font-semibold">{d.customer}</div>
                          <div className="text-[11px] text-ink-500">{d.vehicleLabel}</div>
                          <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-silver-100"><div className={cx('h-full rounded-full', miss.length ? 'bg-brand-600' : 'bg-emerald-500')} style={{ width: `${(done / total) * 100}%` }} /></div>
                          <div className="mt-1 text-[11px] text-ink-500">{done}/{total} documents complete</div>
                          {miss.length > 0 && <div className="mt-2"><Badge tone="red">Missing: {miss.map((m) => m.label).join(', ')}</Badge></div>}
                          {d.waitingDays >= 3 && <div className="mt-2 flex items-start gap-1 rounded-md bg-amber-50 px-2 py-1 text-[11px] font-semibold text-amber-900"><Hourglass className="mt-px h-3 w-3 shrink-0" /> {d.waitingFor} — waiting {d.waitingDays} days</div>}
                          {d.pendingRequest && <div className="mt-2"><Badge tone="amber">Customer request needs approval</Badge></div>}
                          {d.depositFlag && <div className="mt-1 text-[10px] text-ink-400">Deposit flag (demo — no payment processed)</div>}
                        </button>
                      )
                    })}
                  </div>
                </div>
              )
            })}
          </div>
          <Help>Drag a deal to another column, or open it to see the checklist. Which documents apply should be set and reviewed by a qualified dealership professional — this demo just tracks them.</Help>
        </>
      )}
      {ui.dealId && <DealDrawer id={ui.dealId} />}
    </div>
  )
}

function DealDrawer({ id }: { id: string }) {
  const { s, setUi, act, can } = useStore()
  const d = s.deals.find((x) => x.id === id)
  const [findings, setFindings] = useState<ReturnType<typeof checkDocText> | null>(null)
  if (!d) return null
  const canDoc = can('approve:doc')
  const owner = (k: MemberId) => memberLabel(s, k)
  return (
    <Drawer open onClose={() => setUi({ dealId: null })} width="max-w-4xl" title={<span>Deal {d.number} · {d.customer} <span className="text-sm font-normal text-ink-500">· {d.vehicleLabel}</span></span>}>
      <div className="grid gap-0 lg:grid-cols-[1fr_340px]">
        <div className="space-y-5 p-5">
          {d.waitingDays >= 3 && (
            <div className="flex items-center gap-2 rounded-xl border border-amber-200 bg-amber-50 px-4 py-2.5 text-[13px] font-semibold text-amber-900"><AlertTriangle className="h-4 w-4" /> Escalation: {d.waitingFor} — has waited {d.waitingDays} days</div>
          )}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-[12px] font-semibold text-ink-500">Stage:</span>
            <Select className="h-8 w-auto py-0 text-[13px]" value={d.stage} onChange={(e) => act((st, c) => moveDeal(st, c, d.id, e.target.value as typeof d.stage))}>
              {DEAL_COLS.map((c) => <option key={c.id} value={c.id}>{c.label}</option>)}
            </Select>
            <span className="text-[12px] text-ink-500">Salesperson: <b>{owner(d.salesperson)}</b></span>
          </div>

          <Card>
            <CardHead icon={<ClipboardCheck className="h-4 w-4" />} title="Document checklist" sub="Status, who owns the next step, and whether it applies to this deal." right={<DemoTag>Sample documents</DemoTag>} />
            <div className="divide-y divide-silver-100">
              {d.docs.map((doc) => (
                <div key={doc.key} className={cx('flex flex-wrap items-center gap-3 px-5 py-2.5', !doc.applicable && 'opacity-50')}>
                  {DOC_ICON[doc.applicable ? doc.status : 'na']}
                  <div className="min-w-0 flex-1">
                    <div className="text-[13px] font-semibold">{doc.label}</div>
                    <div className="text-[11px] text-ink-500">Next step: {owner(doc.owner)}{doc.note && ` · ${doc.note}`}</div>
                  </div>
                  <Select className="h-8 w-auto py-0 text-[12px]" disabled={!doc.applicable} value={doc.status} onChange={(e) => act((st, c) => { const x = st.deals.find((y) => y.id === d.id)!.docs.find((y) => y.key === doc.key)!; x.status = e.target.value as DocStatus; log(st, 'change', `${doc.label} → ${x.status} (Deal ${d.number})`, true, { screen: 'deals', id: d.id }); c.toast('Checklist updated', 'ok') })}>
                    <option value="complete">Complete</option><option value="pending">Pending</option><option value="missing">Missing</option>
                  </Select>
                  {doc.status === 'missing' && doc.applicable && <Btn size="xs" onClick={() => act((st, c) => draftDocRequest(st, c, d.id, doc.key))}>Draft request</Btn>}
                  <label className="flex items-center gap-1 text-[11px] text-ink-500" title="Does this document apply to this deal?">Applies <Toggle on={doc.applicable} onChange={(on) => act((st) => { const x = st.deals.find((y) => y.id === d.id)!.docs.find((y) => y.key === doc.key)!; x.applicable = on; if (!on) x.status = 'na'; else if (x.status === 'na') x.status = 'pending' })} /></label>
                </div>
              ))}
            </div>
          </Card>

          {d.pendingRequest && (
            <div className="rise rounded-xl border border-amber-200 bg-amber-50/70 p-4" data-tour="doc-request">
              <div className="mb-2 flex items-center gap-1.5 text-[13px] font-bold text-amber-900"><Send className="h-4 w-4" /> Customer request — a person must approve</div>
              <p className="rounded-lg bg-white p-3 text-[13px] ring-1 ring-amber-200">{d.pendingRequest.text}</p>
              <div className="mt-3 flex gap-2">
                <Btn data-tour="approve-doc" size="sm" variant="success" disabled={!canDoc} onClick={() => act((st, c) => approveDocRequest(st, c, d.id))}>Approve & send (demo)</Btn>
                <Btn size="sm" variant="ghost" onClick={() => act((st) => { st.deals.find((y) => y.id === d.id)!.pendingRequest = null })}>Discard</Btn>
              </div>
              {!canDoc && <p className="mt-2 text-[11px] text-amber-900">Only Owner or Admin/Title can approve document messages.</p>}
            </div>
          )}

          <Card>
            <CardHead icon={<FileText className="h-4 w-4" />} title="Sample document text" sub="Fictional text the AI can read to spot possible gaps." right={<Btn data-tour="ai-check" size="sm" variant="primary" icon={<FileSearch className="h-4 w-4" />} onClick={() => act((st, c) => setFindings(runDocCheck(st, c, d.id)))}>Run AI check</Btn>} />
            <pre className="scroll-thin overflow-x-auto whitespace-pre-wrap bg-panel-soft px-5 py-4 font-mono text-[11.5px] leading-relaxed text-ink-700">{d.sampleDocText}</pre>
            {findings && (
              <div className="rise border-t border-silver-100 px-5 py-4">
                <div className="mb-2 text-[13px] font-bold">AI found {findings.length} possible omission{findings.length === 1 ? '' : 's'}</div>
                {findings.map((f, i) => <div key={i} className="flex items-start gap-2 py-1 text-[13px]"><AlertTriangle className={cx('mt-0.5 h-4 w-4', f.severity === 'high' ? 'text-brand-600' : 'text-ink-400')} />{f.text}</div>)}
                <p className="mt-2 text-[11px] text-ink-500">These are flags for a person to check — not legal determinations.</p>
              </div>
            )}
          </Card>
        </div>

        <div className="space-y-4 border-silver-200 bg-panel-soft p-5 lg:border-l">
          <div>
            <Btn size="sm" className="w-full" icon={<Bot className="h-4 w-4" />} onClick={() => act((st, c) => managerSummary(st, c, d.id))}>Write manager summary</Btn>
            {d.summary && <p className="rise mt-2 rounded-xl bg-white p-3 text-[12.5px] leading-relaxed ring-1 ring-silver-200">{d.summary}</p>}
          </div>
          <div>
            <div className="mb-2 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-ink-500"><ScrollText className="h-3.5 w-3.5" /> Timeline</div>
            <ol className="space-y-2.5 border-l-2 border-silver-200 pl-4">
              {[...d.events].reverse().map((e, i) => (
                <li key={i} className="relative text-[12.5px]">
                  <span className="absolute -left-[21px] top-1 h-2.5 w-2.5 rounded-full border-2 border-white bg-brand-600" />
                  <div>{e.text}</div>
                  <div className="text-[11px] text-ink-400">{fmtWhen(e.at, s.now)} · {e.who}</div>
                </li>
              ))}
            </ol>
          </div>
          <Help title="Limits">The AI never signs, fabricates or finalizes forms, submits to the DMV or lenders, approves loans, or decides legal questions. The DMS stays the official record.</Help>
        </div>
      </div>
    </Drawer>
  )
}

function Promises() {
  const { s, act } = useStore()
  const [f, setF] = useState({ dealNumber: '', customer: '', vehicle: '', item: '', owner: 'admin' as MemberId, due: '' })
  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
      <Card>
        <CardHead icon={<Wrench className="h-4 w-4" />} title='Post-sale "we owe" promises' sub="Written promises made at sale (repairs, second keys, detailing) and who's on it. Only staff-entered items — nothing invented." />
        <div className="divide-y divide-silver-100">
          {s.promises.map((p) => (
            <div key={p.id} className="flex flex-wrap items-center gap-3 px-5 py-3">
              <Badge tone={p.status === 'done' ? 'green' : p.status === 'scheduled' ? 'blue' : 'amber'}>{p.status}</Badge>
              <div className="min-w-0 flex-1">
                <div className="text-[13px] font-semibold">{p.item}</div>
                <div className="text-[11px] text-ink-500">{p.customer} · {p.vehicle} · Deal {p.dealNumber} · Due {p.due} {p.sample && '· sample'}</div>
              </div>
              <Avatar id={p.owner} />
              <Select className="h-8 w-auto py-0 text-[12px]" value={p.status} onChange={(e) => act((st, c) => { const x = st.promises.find((y) => y.id === p.id)!; x.status = e.target.value as PromiseItem['status']; log(st, 'change', `Promise "${x.item}" → ${x.status}`, true, { screen: 'deals' }); c.toast('Promise updated', 'ok') })}>
                <option value="open">Open</option><option value="scheduled">Scheduled</option><option value="done">Done</option>
              </Select>
            </div>
          ))}
        </div>
      </Card>
      <Card className="p-4">
        <div className="mb-3 text-sm font-bold">Add a promise</div>
        <form className="space-y-2.5" onSubmit={(e) => { e.preventDefault(); act((st, c) => { st.promises.unshift({ id: uid(st, 'p'), ...f, status: 'open' }); log(st, 'change', `Promise added: ${f.item}`, true, { screen: 'deals' }); c.toast('Promise added', 'ok') }); setF({ ...f, item: '', customer: '', vehicle: '', dealNumber: '', due: '' }) }}>
          <Field label="What was promised"><Input required value={f.item} onChange={(e) => setF({ ...f, item: e.target.value })} placeholder="e.g. Replace worn wiper blades" /></Field>
          <div className="grid grid-cols-2 gap-2">
            <Field label="Customer"><Input required value={f.customer} onChange={(e) => setF({ ...f, customer: e.target.value })} /></Field>
            <Field label="Deal #"><Input value={f.dealNumber} onChange={(e) => setF({ ...f, dealNumber: e.target.value })} /></Field>
            <Field label="Vehicle"><Input value={f.vehicle} onChange={(e) => setF({ ...f, vehicle: e.target.value })} /></Field>
            <Field label="Due"><Input value={f.due} onChange={(e) => setF({ ...f, due: e.target.value })} placeholder="Fri" /></Field>
          </div>
          <Field label="Owner"><Select value={f.owner} onChange={(e) => setF({ ...f, owner: e.target.value as MemberId })}>{s.members.map((m) => <option key={m.id} value={m.id}>{m.label}</option>)}</Select></Field>
          <Btn type="submit" variant="primary" className="w-full" icon={<Plus className="h-4 w-4" />}>Add promise</Btn>
        </form>
      </Card>
    </div>
  )
}
