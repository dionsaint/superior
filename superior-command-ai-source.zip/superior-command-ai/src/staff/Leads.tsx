import { useEffect, useMemo, useState } from 'react'
import { ArrowLeft, Bot, CalendarPlus, CheckCircle2, Hand, MessageSquare, PauseCircle, PhoneMissed, PlayCircle, Send, ShieldCheck, Sparkles, UserPlus, Wand2 } from 'lucide-react'
import { useStore } from '../store'
import type { Lead, MemberId, TradeInfo } from '../types'
import { approveDraft, assignLead, bookTestDrive, draftReply, kindLabel, memberLabel, setAppraisal, simulateLead, simulateMissedCall, srcLabel, uid, log } from '../actions'
import { canAutoMessage, conciergeReply, isOffHours, vFull } from '../logic'
import { ago, fmtDay, fmtTime, fmtWhen, nextSlots } from '../time'
import { Avatar, Badge, Btn, Card, CardHead, Empty, Help, Input, PageTitle, Select, Tabs, Textarea, Toggle, cx } from '../ui'

type Filter = 'all' | 'reply' | 'approval' | 'trade' | 'appt'

export function Leads() {
  const { s, ui, setUi, act, can } = useStore()
  const [filter, setFilter] = useState<Filter>('all')
  const [tab, setTab] = useState<'inbox' | 'tester'>('inbox')
  const list = useMemo(() => s.leads.filter((l) => {
    if (filter === 'reply') return l.missed || l.callbackRequested
    if (filter === 'approval') return !!l.draft
    if (filter === 'trade') return l.kind === 'trade-in'
    if (filter === 'appt') return l.stage === 'appointment'
    return true
  }), [s.leads, filter])
  const sel = s.leads.find((l) => l.id === ui.leadId) ?? null

  return (
    <div>
      <PageTitle
        kicker="Unified inbox · 24/7 AI assistant"
        title="Customer Inbox"
        plain="Every inquiry — website, phone, email, Facebook Marketplace, OfferUp, walk-ins — in one list. The AI drafts short, honest replies using only listing info. A person approves anything sensitive."
        right={
          <>
            <Btn data-tour="sim-lead" size="sm" icon={<Sparkles className="h-4 w-4" />} onClick={() => act((st, c) => { const id = simulateLead(st, c); setUi({ leadId: id }) })}>Simulate new lead</Btn>
            <Btn data-tour="sim-missed" size="sm" icon={<PhoneMissed className="h-4 w-4" />} onClick={() => act((st, c) => { const id = simulateMissedCall(st, c); setUi({ leadId: id }) })}>Simulate missed call</Btn>
          </>
        }
      />
      <div className="mb-4 flex flex-wrap items-center gap-3">
        <Tabs value={tab} onChange={setTab} items={[{ id: 'inbox', label: 'Inbox' }, { id: 'tester', label: 'Try the AI assistant' }]} />
        {!can('approve:lead') && <Badge tone="amber">Your role can view but not approve replies</Badge>}
      </div>
      {tab === 'tester' ? <ConciergeTester /> : (
        <div className="grid gap-4 lg:grid-cols-[360px_minmax(0,1fr)]">
          <Card className={cx('overflow-hidden', sel && 'hidden lg:block')}>
            <div className="border-b border-silver-100 p-3">
              <Select aria-label="Filter" value={filter} onChange={(e) => setFilter(e.target.value as Filter)}>
                <option value="all">All conversations ({s.leads.length})</option>
                <option value="reply">Waiting for a reply ({s.leads.filter((l) => l.missed || l.callbackRequested).length})</option>
                <option value="approval">AI draft needs approval ({s.leads.filter((l) => l.draft).length})</option>
                <option value="trade">Trade-in inquiries ({s.leads.filter((l) => l.kind === 'trade-in').length})</option>
                <option value="appt">Has an appointment</option>
              </Select>
            </div>
            <div className="scroll-thin max-h-[70vh] divide-y divide-silver-100 overflow-y-auto">
              {list.map((l) => (
                <button key={l.id} onClick={() => setUi({ leadId: l.id })} className={cx('block w-full px-4 py-3 text-left transition hover:bg-silver-50', ui.leadId === l.id && 'bg-brand-50/60')}>
                  <div className="flex items-center justify-between gap-2">
                    <span className="flex min-w-0 items-center gap-2">
                      {(l.missed || l.callbackRequested) && <span className="h-2 w-2 shrink-0 rounded-full bg-brand-600" />}
                      <span className="truncate text-sm font-semibold">{l.name}</span>
                    </span>
                    <span className="shrink-0 text-[11px] text-ink-400">{ago(l.createdAt, s.now)}</span>
                  </div>
                  <div className="mt-0.5 truncate text-[12px] text-ink-500">{l.messages[l.messages.length - 1]?.text ?? '—'}</div>
                  <div className="mt-1.5 flex flex-wrap gap-1">
                    <Badge>{srcLabel(l.source)}</Badge>
                    {l.kind !== 'inquiry' && <Badge tone="violet">{kindLabel(l.kind)}</Badge>}
                    {l.draft && <Badge tone="amber">Draft ready</Badge>}
                    {l.callbackRequested && <Badge tone="red">Callback</Badge>}
                    {l.consent.stopped && <Badge tone="gray">Opted out</Badge>}
                  </div>
                </button>
              ))}
              {!list.length && <div className="p-6"><Empty title="Nothing here" body="No conversations match this filter." /></div>}
            </div>
          </Card>
          {sel ? <LeadDetail l={sel} onBack={() => setUi({ leadId: null })} /> : (
            <Card className="hidden place-items-center p-10 lg:grid"><Empty icon={<MessageSquare className="h-10 w-10" />} title="Pick a conversation" body="Or press “Simulate new lead” to see the AI react to a new inquiry." /></Card>
          )}
        </div>
      )}
    </div>
  )
}

function LeadDetail({ l, onBack }: { l: Lead; onBack: () => void }) {
  const { s, act, can, nav } = useStore()
  const [edit, setEdit] = useState<string | null>(null)
  const [staffMsg, setStaffMsg] = useState('')
  const [slotOpen, setSlotOpen] = useState(false)
  const v = s.vehicles.find((x) => x.id === l.vehicleId)
  const gate = canAutoMessage(s, l)
  const slots = nextSlots(s.now, s.hours, s.appointments, 4)
  useEffect(() => setEdit(null), [l.id])
  const appt = s.appointments.filter((a) => a.leadId === l.id)
  const canApprove = can('approve:lead')

  return (
    <Card className="overflow-hidden" data-tour="lead-detail">
      <div className="flex flex-wrap items-start justify-between gap-3 border-b border-silver-100 px-5 py-4">
        <div className="flex items-start gap-3">
          <button className="mt-1 rounded-lg p-1 hover:bg-silver-100 lg:hidden" onClick={onBack} aria-label="Back"><ArrowLeft className="h-5 w-5" /></button>
          <div>
            <h2 className="text-lg font-bold">{l.name}</h2>
            <div className="mt-0.5 flex flex-wrap items-center gap-1.5 text-[12px] text-ink-500">
              <Badge>{srcLabel(l.source)}</Badge>
              <Badge tone="violet">{kindLabel(l.kind)}</Badge>
              <Badge tone={l.urgency === 'high' ? 'red' : l.urgency === 'med' ? 'amber' : 'gray'}>{l.urgency === 'high' ? 'Urgent' : l.urgency === 'med' ? 'Normal' : 'Low'}</Badge>
              <span>Stage: <b className="text-ink-800">{l.stage}</b></span>
              <span>· {l.phone}{l.email && ` · ${l.email}`}</span>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Avatar id={l.assignedTo} size="md" />
          <Select data-tour="assign" aria-label="Assign salesperson" className="h-9 w-auto py-0 text-[13px]" value={l.assignedTo ?? ''} onChange={(e) => act((st, c) => assignLead(st, c, l.id, (e.target.value || undefined) as MemberId))}>
            <option value="">Auto-assign (round-robin)</option>
            {s.members.map((m) => <option key={m.id} value={m.id}>{m.label}</option>)}
          </Select>
        </div>
      </div>

      <div className="grid gap-0 xl:grid-cols-[1fr_300px]">
        <div className="border-silver-100 xl:border-r">
          <div className="scroll-thin max-h-[420px] space-y-3 overflow-y-auto bg-panel-soft px-5 py-4">
            {l.messages.map((m) => (
              <div key={m.id} className={cx('flex', (m.from === 'staff' || m.from === 'ai') && 'justify-end', m.from === 'system' && 'justify-center')}>
                {m.from === 'system' ? (
                  <div className="max-w-[90%] rounded-lg bg-silver-100 px-3 py-1.5 text-center text-[12px] text-ink-500">{m.text}</div>
                ) : (
                  <div className={cx('max-w-[80%] rounded-2xl px-3.5 py-2 text-[13px] leading-relaxed', m.from === 'customer' ? 'rounded-bl-sm bg-white ring-1 ring-silver-200' : m.from === 'ai' ? 'rounded-br-sm bg-ink-900 text-white' : 'rounded-br-sm bg-brand-600 text-white')}>
                    {m.text}
                    <div className={cx('mt-1 text-[10px]', m.from === 'customer' ? 'text-ink-400' : 'text-white/70')}>
                      {m.from === 'ai' ? 'AI assistant' : m.from === 'staff' ? 'Staff' : 'Customer'} · {fmtWhen(m.at, s.now)}{m.status === 'sent-demo' && ' · DEMO, not actually sent'}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>

          {l.draft && (
            <div className="rise border-t border-amber-200 bg-amber-50/60 px-5 py-4" data-tour="draft">
              <div className="mb-2 flex items-center justify-between">
                <span className="flex items-center gap-1.5 text-[13px] font-bold text-amber-900"><Bot className="h-4 w-4" /> AI draft — waiting for approval</span>
                <span className="text-[11px] text-amber-800">Uses only demo listing fields</span>
              </div>
              {edit != null ? <Textarea value={edit} onChange={(e) => setEdit(e.target.value)} /> : <p className="rounded-xl bg-white p-3 text-[13px] leading-relaxed ring-1 ring-amber-200">{l.draft}</p>}
              <div className="mt-3 flex flex-wrap gap-2">
                <Btn data-tour="approve" size="sm" variant="success" disabled={!canApprove || l.consent.stopped} icon={<CheckCircle2 className="h-4 w-4" />} onClick={() => act((st, c) => approveDraft(st, c, l.id, edit ?? undefined))}>Approve & send (demo)</Btn>
                {edit == null ? <Btn size="sm" onClick={() => setEdit(l.draft)}>Edit</Btn> : <Btn size="sm" variant="ghost" onClick={() => setEdit(null)}>Cancel edit</Btn>}
                <Btn size="sm" variant="ghost" onClick={() => act((st) => { const x = st.leads.find((y) => y.id === l.id); if (x) x.draft = null })}>Discard</Btn>
              </div>
              <p className="mt-2 text-[11px] text-amber-900">Channel: {l.channel.toUpperCase()} · {l.channel === 'sms' && !l.consent.sms ? 'No SMS consent — send on the original platform or call instead.' : 'Consent on file for this channel.'} Approving logs it; no real message is sent.</p>
            </div>
          )}

          <div className="border-t border-silver-100 px-5 py-4">
            <div className="flex flex-wrap gap-2">
              <Btn size="sm" icon={<Wand2 className="h-4 w-4" />} onClick={() => act((st, c) => draftReply(st, c, l.id))}>Draft personalized reply</Btn>
              <Btn data-tour="book" size="sm" icon={<CalendarPlus className="h-4 w-4" />} onClick={() => setSlotOpen(!slotOpen)}>Book test drive</Btn>
              <Btn size="sm" variant={l.automationPaused ? 'dark' : 'secondary'} icon={l.automationPaused ? <PlayCircle className="h-4 w-4" /> : <PauseCircle className="h-4 w-4" />} onClick={() => act((st, c) => { const x = st.leads.find((y) => y.id === l.id)!; x.automationPaused = !x.automationPaused; log(st, 'change', `Automation ${x.automationPaused ? 'paused' : 'resumed'} for ${x.name}`, true, { screen: 'leads', id: x.id }); c.toast(x.automationPaused ? 'Automation paused for this customer.' : 'Automation resumed.', 'ok') })}>{l.automationPaused ? 'Resume automation' : 'Pause automation'}</Btn>
              <Btn size="sm" variant={l.humanTakeover ? 'dark' : 'secondary'} icon={<Hand className="h-4 w-4" />} onClick={() => act((st, c) => { const x = st.leads.find((y) => y.id === l.id)!; x.humanTakeover = !x.humanTakeover; log(st, 'change', `${x.humanTakeover ? 'Staff took over' : 'Returned to AI assist'}: ${x.name}`, true, { screen: 'leads', id: x.id }); c.toast(x.humanTakeover ? 'You’re handling this conversation. The AI will stay quiet.' : 'AI assist re-enabled.', 'ok') })}>{l.humanTakeover ? 'Hand back to AI' : 'Take over conversation'}</Btn>
            </div>
            {slotOpen && (
              <div className="rise mt-3 flex flex-wrap gap-2 rounded-xl bg-silver-50 p-3">
                <span className="w-full text-[12px] font-semibold text-ink-700">Next open slots (Eastern Time):</span>
                {slots.map((w) => <Btn key={w} size="sm" variant="secondary" onClick={() => { act((st, c) => bookTestDrive(st, c, l.id, w)); setSlotOpen(false) }}>{fmtDay(w)} {fmtTime(w)}</Btn>)}
              </div>
            )}
            <form className="mt-3 flex gap-2" onSubmit={(e) => { e.preventDefault(); if (!staffMsg.trim()) return; act((st, c) => { const x = st.leads.find((y) => y.id === l.id)!; x.messages.push({ id: uid(st, 'm'), from: 'staff', text: staffMsg, at: st.now, status: 'sent-demo' }); x.missed = false; x.callbackRequested = false; if (x.stage === 'new') x.stage = 'contacted'; log(st, 'message', `Staff message to ${x.name} — DEMO, not sent`, true, { screen: 'leads', id: x.id }, 'Staff'); c.toast('DEMO — no real message sent.', 'demo') }); setStaffMsg('') }}>
              <Input value={staffMsg} onChange={(e) => setStaffMsg(e.target.value)} placeholder="Write your own reply…" aria-label="Staff reply" disabled={l.consent.stopped} />
              <Btn type="submit" variant="primary" disabled={!staffMsg.trim() || l.consent.stopped} icon={<Send className="h-4 w-4" />}>Send</Btn>
            </form>
          </div>
        </div>

        <div className="space-y-4 px-5 py-4 text-[13px]">
          <section>
            <h4 className="mb-1.5 text-[11px] font-bold uppercase tracking-wide text-ink-500">Vehicle of interest</h4>
            {v ? <button onClick={() => nav('listings', v.id)} className="text-left font-semibold hover:text-brand-700">{vFull(v)} · {v.stock}</button> : <span className="text-ink-500">Not specified</span>}
          </section>
          <section className="grid grid-cols-2 gap-2">
            <div><div className="text-[11px] text-ink-500">Budget (if shared)</div><div className="font-semibold">{l.budget ?? '—'}</div></div>
            <div><div className="text-[11px] text-ink-500">Trade-in</div><div className="font-semibold">{l.tradeIn ?? '—'}</div></div>
            <div><div className="text-[11px] text-ink-500">Prefers</div><div className="font-semibold">{l.channel === 'sms' ? 'Text' : l.channel === 'email' ? 'Email' : 'Phone'}</div></div>
            <div><div className="text-[11px] text-ink-500">Next step</div><div className="font-semibold">{l.nextAction}</div></div>
          </section>
          {l.trade && <AppraisalPanel l={l} />}
          {appt.length > 0 && (
            <section>
              <h4 className="mb-1.5 text-[11px] font-bold uppercase tracking-wide text-ink-500">Appointments</h4>
              {appt.map((a) => (
                <button key={a.id} onClick={() => nav('calendar')} className="mb-1.5 block w-full rounded-lg bg-silver-50 p-2 text-left ring-1 ring-silver-200 hover:ring-brand-600">
                  <div className="font-semibold">{a.kind} · {fmtDay(a.start)} {fmtTime(a.start)}</div>
                  <div className="text-[11px] text-ink-500">{memberLabel(s, a.salesperson)} · {a.status === 'hold' ? 'Requested — staff to confirm' : a.status} · Reminder {a.reminder === 'queued' ? 'queued (demo)' : 'off'}</div>
                </button>
              ))}
            </section>
          )}
          <section className="rounded-xl border border-silver-200 p-3" data-tour="consent">
            <h4 className="mb-2 flex items-center gap-1.5 text-[11px] font-bold uppercase tracking-wide text-ink-500"><ShieldCheck className="h-3.5 w-3.5" /> Permission to contact</h4>
            <div className="space-y-1.5">
              {(['sms', 'email', 'call'] as const).map((k) => (
                <div key={k} className="flex items-center justify-between">
                  <span>{k === 'sms' ? 'Text messages' : k === 'email' ? 'Email' : 'Phone calls'}</span>
                  <Badge tone={l.consent[k] && !l.consent.stopped ? 'green' : 'gray'}>{l.consent[k] && !l.consent.stopped ? 'Allowed' : 'No'}</Badge>
                </div>
              ))}
            </div>
            <div className="mt-2 text-[11px] text-ink-500">Source: {l.consent.source}{l.consent.at && ` · ${fmtWhen(l.consent.at, s.now)}`}</div>
            <div className={cx('mt-2 rounded-lg px-2 py-1.5 text-[11px]', gate.ok ? 'bg-emerald-50 text-emerald-800' : 'bg-silver-100 text-ink-700')}>
              <b>Automatic messages:</b> {gate.ok ? 'allowed' : 'blocked'} — {gate.reason}
            </div>
            <div className="mt-2 text-[11px] text-ink-500">Quiet hours {s.quietStart}–{s.quietEnd} · Max {s.freqCap} automated msgs/day · Sent today: {l.autoSentToday}</div>
            {!l.consent.stopped ? (
              <Btn size="xs" variant="danger" className="mt-2" onClick={() => act((st, c) => { const x = st.leads.find((y) => y.id === l.id)!; x.messages.push({ id: uid(st, 'm'), from: 'customer', text: 'STOP', at: st.now }, { id: uid(st, 'm'), from: 'system', text: 'Opt-out recorded. All automated messages stopped for this contact.', at: st.now }); x.consent.stopped = true; x.draft = null; log(st, 'system', `${x.name} replied STOP — automation disabled`, true, { screen: 'leads', id: x.id }, 'System'); c.toast('Simulated STOP reply: contact opted out.', 'warn') })}>Simulate customer replying STOP</Btn>
            ) : <div className="mt-2 text-[11px] font-semibold text-brand-700">Opted out — no outreach allowed.</div>}
          </section>
        </div>
      </div>
    </Card>
  )
}

function AppraisalPanel({ l }: { l: Lead }) {
  const { act } = useStore()
  const steps: TradeInfo['appraisal'][] = ['Awaiting review', 'Inspection booked', 'Offer prepared by staff', 'Declined']
  return (
    <section className="rounded-xl border border-violet-200 bg-violet-50/60 p-3">
      <h4 className="mb-1 text-[11px] font-bold uppercase tracking-wide text-violet-800">Trade-in appraisal (staff workflow)</h4>
      <div className="text-[12px]">{l.trade!.year} {l.trade!.make} {l.trade!.model} · {l.trade!.mileage || '?'} mi · {l.trade!.condition}</div>
      <Select className="mt-2 h-8 py-0 text-[12px]" value={l.trade!.appraisal} onChange={(e) => act((st, c) => setAppraisal(st, c, l.id, e.target.value as TradeInfo['appraisal']))}>
        {steps.map((x) => <option key={x}>{x}</option>)}
      </Select>
      <p className="mt-1.5 text-[11px] text-violet-900">No automated valuation. Any number comes from staff after seeing the car.</p>
    </section>
  )
}

function ConciergeTester() {
  const { s, act } = useStore()
  const [off, setOff] = useState(isOffHours(s))
  const [msgs, setMsgs] = useState<{ from: 'me' | 'ai'; text: string; intents?: string[] }[]>([])
  const [q, setQ] = useState('')
  const ask = (text: string) => {
    if (!text.trim()) return
    const vid = [...msgs].reverse().find((m) => m.from === 'ai') ? undefined : null
    const out = conciergeReply(text, { vehicles: s.vehicles, offHours: off, slots: nextSlots(s.now, s.hours, s.appointments), first: msgs.length === 0, vehicleId: vid ?? lastVid, hours: s.hours })
    lastVid = out.vehicleId
    setMsgs((m) => [...m, { from: 'me', text }, { from: 'ai', text: out.text, intents: out.intents }])
    setQ('')
  }
  const samples = ['Is the Camry still available?', 'How many miles on the Rogue? What’s the price?', 'Does the BMW have AWD?', 'Any accidents on the Tacoma?', 'Can I get approved with bad credit?', 'Can I test drive the Silverado Saturday?', 'Does the Equinox have a warranty?', 'I want to talk to a person']
  return (
    <div className="grid gap-4 lg:grid-cols-[1fr_340px]">
      <Card className="flex h-[620px] flex-col overflow-hidden">
        <CardHead icon={<Bot className="h-4 w-4" />} title="AI Buyer Concierge — test drive it" sub="Ask anything a shopper might. It answers ONLY from the demo listing fields and says “staff must verify” when it doesn't know." right={<label className="flex items-center gap-2 text-[12px] font-semibold">After hours <Toggle on={off} onChange={setOff} label="After-hours mode" /></label>} />
        <div className="scroll-thin flex-1 space-y-3 overflow-y-auto bg-panel-soft p-4">
          {msgs.length === 0 && <Empty icon={<MessageSquare className="h-8 w-8" />} title="Try a sample question" body="Pick one on the right, or type your own below." />}
          {msgs.map((m, i) => (
            <div key={i} className={cx('flex', m.from === 'me' && 'justify-end')}>
              <div className={cx('max-w-[80%] rounded-2xl px-3.5 py-2 text-[13px] leading-relaxed', m.from === 'me' ? 'bg-brand-600 text-white' : 'bg-white ring-1 ring-silver-200')}>
                {m.text}
                {m.intents && m.intents.length > 0 && <div className="mt-1.5 flex flex-wrap gap-1">{m.intents.map((x) => <Badge key={x} tone="gray">{x}</Badge>)}</div>}
              </div>
            </div>
          ))}
        </div>
        <form className="flex gap-2 border-t border-silver-100 p-3" onSubmit={(e) => { e.preventDefault(); ask(q) }}>
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Ask as a shopper would…" aria-label="Question" />
          <Btn type="submit" variant="primary" icon={<Send className="h-4 w-4" />}>Ask</Btn>
          <Btn type="button" variant="ghost" onClick={() => { setMsgs([]); lastVid = null }}>Reset</Btn>
        </form>
      </Card>
      <div className="space-y-4">
        <Card className="p-4">
          <div className="mb-2 text-sm font-bold">Sample questions</div>
          <div className="flex flex-col gap-1.5">{samples.map((x) => <button key={x} onClick={() => ask(x)} className="rounded-lg border border-silver-200 px-3 py-2 text-left text-[13px] hover:border-brand-600 hover:text-brand-700">{x}</button>)}</div>
        </Card>
        <Help title="Guardrails">It never guesses about availability, condition, accident history, warranty, financing approval, price, or features. It introduces itself as AI, offers a person anytime, and honors STOP. Edit a car in Manage Cars and ask again — the answer changes.</Help>
        <Btn size="sm" variant="ghost" onClick={() => act((st, c) => { simulateLead(st, c, 0) })}>Send a simulated shopper to the inbox</Btn>
      </div>
    </div>
  )
}
let lastVid: string | null = null
