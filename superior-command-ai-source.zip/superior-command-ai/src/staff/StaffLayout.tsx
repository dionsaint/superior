import React, { useMemo, useState } from 'react'
import { Calculator, CalendarDays, Car, FileCheck2, Globe, Inbox, LayoutDashboard, Lock, Menu, PhoneCall, PlayCircle, Plug, RotateCcw, Search, X } from 'lucide-react'
import { ROLE_LABEL, useStore } from '../store'
import type { Role, ScreenId } from '../types'
import { attention, isOffHours, vName } from '../logic'
import { fmtDayLong, fmtTime } from '../time'
import { Badge, Btn, Select, cx } from '../ui'
import { ConceptLogo } from '../public/PublicSite'
import { DemoControls } from '../tour'

export const SCREENS: { id: ScreenId; label: string; sub: string; icon: React.ElementType }[] = [
  { id: 'dashboard', label: 'Today', sub: 'Owner dashboard', icon: LayoutDashboard },
  { id: 'leads', label: 'Customer Inbox', sub: 'Leads & AI replies', icon: Inbox },
  { id: 'listings', label: 'Manage Cars', sub: 'Listings & health', icon: Car },
  { id: 'deals', label: 'Deals & Paperwork', sub: 'Documents & titles', icon: FileCheck2 },
  { id: 'calendar', label: 'Calendar & Rules', sub: 'Appointments, automations', icon: CalendarDays },
  { id: 'frontdesk', label: 'After-Hours Desk', sub: 'Phone & chat preview', icon: PhoneCall },
  { id: 'roi', label: 'Time & Money', sub: 'Savings calculator', icon: Calculator },
  { id: 'settings', label: 'Settings', sub: 'Connections, roles, security', icon: Plug },
]

const ALLOWED: Record<Role, ScreenId[]> = {
  owner: SCREENS.map((s) => s.id),
  sales: ['dashboard', 'leads', 'listings', 'calendar', 'frontdesk', 'deals'],
  admin: ['dashboard', 'leads', 'listings', 'deals', 'calendar', 'settings'],
  inventory: ['dashboard', 'listings', 'calendar'],
}
export const allowed = (r: Role, id: ScreenId) => ALLOWED[r].includes(id)

function GlobalSearch() {
  const { s, nav } = useStore()
  const [q, setQ] = useState('')
  const res = useMemo(() => {
    if (q.length < 2) return []
    const t = q.toLowerCase()
    const out: { label: string; sub: string; go: () => void }[] = []
    s.leads.filter((l) => l.name.toLowerCase().includes(t)).slice(0, 4).forEach((l) => out.push({ label: l.name, sub: `Customer · ${vName(s.vehicles.find((v) => v.id === l.vehicleId))}`, go: () => nav('leads', l.id) }))
    s.vehicles.filter((v) => `${v.stock} ${v.year} ${v.make} ${v.model}`.toLowerCase().includes(t)).slice(0, 4).forEach((v) => out.push({ label: `${v.stock} · ${v.year} ${v.make} ${v.model}`, sub: 'Car listing', go: () => nav('listings', v.id) }))
    s.deals.filter((d) => `${d.number} ${d.customer}`.toLowerCase().includes(t)).slice(0, 3).forEach((d) => out.push({ label: `Deal ${d.number} · ${d.customer}`, sub: 'Deal file', go: () => nav('deals', d.id) }))
    return out
  }, [q, s, nav])
  return (
    <div className="relative hidden w-72 md:block">
      <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
      <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search customers, cars, deals…" aria-label="Search" className="h-9 w-full rounded-lg border border-silver-200 bg-silver-50 pl-9 pr-3 text-sm focus:border-brand-600 focus:bg-white focus:outline-none" />
      {res.length > 0 && (
        <div className="absolute left-0 right-0 top-11 z-50 overflow-hidden rounded-xl border border-silver-200 bg-white shadow-xl">
          {res.map((r, i) => (
            <button key={i} onClick={() => { r.go(); setQ('') }} className="block w-full px-3 py-2 text-left hover:bg-silver-50">
              <div className="text-sm font-semibold">{r.label}</div>
              <div className="text-[11px] text-ink-500">{r.sub}</div>
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

export function StaffLayout({ children }: { children: React.ReactNode }) {
  const { s, ui, nav, go, act, setUi, reset } = useStore()
  const a = attention(s)
  const counts: Partial<Record<ScreenId, number>> = {
    leads: a.missed.length + a.approvals.length + a.callbacks.length,
    listings: a.listing.length,
    deals: a.missingDocs.length,
  }
  const off = isOffHours(s)
  const side = (
    <nav className="flex flex-col gap-0.5 p-3" aria-label="Staff">
      {SCREENS.map((it) => {
        const ok = allowed(s.role, it.id)
        const active = ui.screen === it.id
        const I = it.icon
        return (
          <button key={it.id} data-tour={`nav-${it.id}`} onClick={() => nav(it.id)} className={cx('group flex items-center gap-3 rounded-xl px-3 py-2.5 text-left transition', active ? 'bg-brand-600 text-white shadow-md shadow-brand-600/20' : 'text-ink-700 hover:bg-silver-100')}>
            <I className={cx('h-[18px] w-[18px] shrink-0', active ? 'text-white' : 'text-ink-500 group-hover:text-brand-600')} />
            <span className="min-w-0 flex-1">
              <span className="block text-[13.5px] font-semibold leading-tight">{it.label}</span>
              <span className={cx('block text-[11px] leading-tight', active ? 'text-white/75' : 'text-ink-400')}>{it.sub}</span>
            </span>
            {!ok ? <Lock className="h-3.5 w-3.5 opacity-60" /> : counts[it.id] ? <span className={cx('rounded-full px-1.5 text-[11px] font-bold', active ? 'bg-white text-brand-700' : 'bg-brand-50 text-brand-700')}>{counts[it.id]}</span> : null}
          </button>
        )
      })}
    </nav>
  )

  return (
    <div className="min-h-screen bg-app">
      <aside className="fixed inset-y-0 left-0 z-30 hidden w-64 flex-col border-r border-silver-200 bg-white lg:flex">
        <div className="border-b border-silver-200 px-4 py-4">
          <div className="text-[15px] font-black tracking-tight">Superior <span className="text-brand-600">Command AI</span></div>
          <div className="mt-1 text-[10px] font-semibold uppercase leading-tight tracking-wide text-ink-400">Independent concept demo — not an official Superior Auto Mall system</div>
        </div>
        <div className="scroll-thin flex-1 overflow-y-auto">{side}</div>
        <div className="space-y-2 border-t border-silver-200 p-3">
          <Btn data-tour="to-website" variant="dark" size="sm" className="w-full" icon={<Globe className="h-4 w-4" />} onClick={() => go('/')}>See Customer Website</Btn>
          <Btn variant="ghost" size="sm" className="w-full" icon={<RotateCcw className="h-4 w-4" />} onClick={reset}>Reset demo data</Btn>
        </div>
      </aside>

      {ui.mobileMenu && (
        <div className="fixed inset-0 z-50 bg-ink-900/40 lg:hidden" onClick={() => setUi({ mobileMenu: false })}>
          <div className="h-full w-72 overflow-y-auto bg-white" onClick={(e) => e.stopPropagation()}>
            <div className="flex items-center justify-between border-b border-silver-200 p-4">
              <div className="text-[15px] font-black">Superior <span className="text-brand-600">Command AI</span></div>
              <button onClick={() => setUi({ mobileMenu: false })} aria-label="Close menu"><X /></button>
            </div>
            {side}
            <div className="space-y-2 p-3">
              <Btn variant="dark" size="sm" className="w-full" onClick={() => go('/')}>See Customer Website</Btn>
              <Btn variant="ghost" size="sm" className="w-full" onClick={reset}>Reset demo data</Btn>
            </div>
          </div>
        </div>
      )}

      <div className="lg:pl-64">
        <header className="sticky top-0 z-20 border-b border-silver-200 bg-white/90 backdrop-blur">
          <div className="flex h-14 items-center gap-3 px-4">
            <button className="rounded-lg p-1.5 lg:hidden" onClick={() => setUi({ mobileMenu: true })} aria-label="Open menu"><Menu /></button>
            <div className="lg:hidden"><div className="text-sm font-black">Superior <span className="text-brand-600">Command AI</span></div></div>
            <GlobalSearch />
            <div className="ml-auto flex items-center gap-2">
              <div className="hidden text-right text-[11px] leading-tight text-ink-500 sm:block">
                <div className="font-semibold text-ink-800">{fmtDayLong(s.now)} · {fmtTime(s.now)} ET</div>
                <div>Demo clock · {off ? <span className="font-semibold text-amber-700">After hours</span> : <span className="font-semibold text-emerald-700">Open</span>}</div>
              </div>
              <label className="flex items-center gap-1.5" data-tour="role">
                <span className="hidden text-[11px] font-semibold text-ink-500 md:inline">Viewing as</span>
                <Select aria-label="Switch role" className="h-9 w-auto py-0 text-[13px] font-semibold" value={s.role} onChange={(e) => act((st, c) => { st.role = e.target.value as Role; c.toast(`Now viewing as ${ROLE_LABEL[st.role]}. Some screens and approvals are limited.`, 'info') })}>
                  {(Object.keys(ROLE_LABEL) as Role[]).map((r) => <option key={r} value={r}>{ROLE_LABEL[r]}</option>)}
                </Select>
              </label>
              <Btn size="sm" variant="primary" className="hidden sm:inline-flex xl:hidden" icon={<PlayCircle className="h-4 w-4" />} onClick={() => setUi({ scenarioPicker: true })}>Demo</Btn>
              <Btn size="sm" variant="dark" className="sm:hidden" icon={<Globe className="h-4 w-4" />} onClick={() => go('/')} aria-label="Customer website" />
            </div>
          </div>
          <DemoControls />
        </header>
        <main className="mx-auto max-w-[1400px] px-4 py-6 pb-28 lg:px-8 lg:pb-10">
          {allowed(s.role, ui.screen) ? children : <Locked />}
        </main>
      </div>

      <nav className="fixed inset-x-0 bottom-0 z-30 grid grid-cols-5 border-t border-silver-200 bg-white lg:hidden" aria-label="Quick">
        {SCREENS.slice(0, 4).map((it) => {
          const I = it.icon
          return (
            <button key={it.id} onClick={() => nav(it.id)} className={cx('relative flex flex-col items-center gap-0.5 py-2 text-[10px] font-semibold', ui.screen === it.id ? 'text-brand-600' : 'text-ink-500')}>
              <I className="h-5 w-5" />
              {it.label.split(' ')[0]}
              {counts[it.id] ? <span className="absolute right-[22%] top-1 h-2 w-2 rounded-full bg-brand-600" /> : null}
            </button>
          )
        })}
        <button onClick={() => setUi({ mobileMenu: true })} className="flex flex-col items-center gap-0.5 py-2 text-[10px] font-semibold text-ink-500"><Menu className="h-5 w-5" />More</button>
      </nav>
    </div>
  )
}

function Locked() {
  const { s, act } = useStore()
  return (
    <div className="mx-auto mt-16 max-w-md rounded-2xl border border-silver-200 bg-white p-8 text-center">
      <Lock className="mx-auto h-10 w-10 text-silver-400" />
      <h2 className="mt-3 text-lg font-bold">Not available for {ROLE_LABEL[s.role]}</h2>
      <p className="mt-1 text-sm text-ink-500">Each role only sees what they need. This screen is limited to the Owner (and Admin for some areas).</p>
      <Btn variant="primary" className="mt-4" onClick={() => act((st) => (st.role = 'owner'))}>Switch to Owner</Btn>
      <div className="mt-3"><Badge tone="gray">Role-based access (demo)</Badge></div>
    </div>
  )
}

export { ConceptLogo }
