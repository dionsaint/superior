import React, { useEffect, useState } from 'react'
import { Info, X } from 'lucide-react'
import type { MemberId, Photo, Vehicle } from './types'
import { MEMBERS, PHOTO_SHOTS, unsplash } from './data'

export const cx = (...a: (string | false | null | undefined)[]) => a.filter(Boolean).join(' ')

type BtnProps = React.ButtonHTMLAttributes<HTMLButtonElement> & {
  variant?: 'primary' | 'secondary' | 'ghost' | 'dark' | 'success' | 'danger' | 'white'
  size?: 'xs' | 'sm' | 'md' | 'lg'
  icon?: React.ReactNode
}
export function Btn({ variant = 'secondary', size = 'md', icon, className, children, ...p }: BtnProps) {
  const v = {
    primary: 'bg-brand-600 text-white hover:bg-brand-700 shadow-sm shadow-brand-600/20',
    secondary: 'bg-white text-ink-900 border border-silver-300 hover:border-ink-400 hover:bg-silver-50',
    ghost: 'text-ink-700 hover:bg-silver-100',
    dark: 'bg-ink-900 text-white hover:bg-ink-800',
    success: 'bg-emerald-600 text-white hover:bg-emerald-700',
    danger: 'bg-white text-brand-700 border border-brand-200 hover:bg-brand-50',
    white: 'bg-white text-brand-700 hover:bg-brand-50 shadow-sm',
  }[variant]
  const s = { xs: 'h-7 px-2 text-xs gap-1', sm: 'h-8 px-3 text-[13px] gap-1.5', md: 'h-10 px-4 text-sm gap-2', lg: 'h-12 px-6 text-base gap-2' }[size]
  return (
    <button
      {...p}
      className={cx('inline-flex items-center justify-center rounded-lg font-semibold transition active:scale-[.98] disabled:opacity-45 disabled:cursor-not-allowed disabled:active:scale-100 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600 whitespace-nowrap', v, s, className)}
    >
      {icon}
      {children}
    </button>
  )
}

const TONES = {
  gray: 'bg-silver-100 text-ink-700 ring-silver-200',
  red: 'bg-brand-50 text-brand-700 ring-brand-100',
  green: 'bg-emerald-50 text-emerald-700 ring-emerald-100',
  amber: 'bg-amber-50 text-amber-800 ring-amber-100',
  blue: 'bg-sky-50 text-sky-800 ring-sky-100',
  dark: 'bg-ink-900 text-white ring-ink-900',
  violet: 'bg-violet-50 text-violet-700 ring-violet-100',
}
export type Tone = keyof typeof TONES
export function Badge({ tone = 'gray', children, className, title }: { tone?: Tone; children: React.ReactNode; className?: string; title?: string }) {
  return (
    <span title={title} className={cx('inline-flex items-center gap-1 rounded-full px-2 py-0.5 text-[11px] font-semibold ring-1 ring-inset whitespace-nowrap', TONES[tone], className)}>
      {children}
    </span>
  )
}

export const DemoTag = ({ children = 'Illustrative' }: { children?: React.ReactNode }) => (
  <span className="inline-flex items-center rounded border border-dashed border-silver-400 px-1.5 py-px text-[10px] font-semibold uppercase tracking-wide text-ink-500">{children}</span>
)

export function Card({ children, className, ...p }: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div {...p} className={cx('rounded-2xl border border-silver-200 bg-panel shadow-[0_1px_2px_rgba(23,27,35,.04)]', className)}>
      {children}
    </div>
  )
}

export function CardHead({ title, sub, right, icon }: { title: React.ReactNode; sub?: React.ReactNode; right?: React.ReactNode; icon?: React.ReactNode }) {
  return (
    <div className="flex items-start justify-between gap-3 border-b border-silver-100 px-5 py-4">
      <div className="flex min-w-0 items-start gap-3">
        {icon && <div className="mt-0.5 grid h-8 w-8 shrink-0 place-items-center rounded-lg bg-brand-50 text-brand-600">{icon}</div>}
        <div className="min-w-0">
          <h3 className="text-[15px] font-bold text-ink-900">{title}</h3>
          {sub && <p className="mt-0.5 text-[13px] leading-snug text-ink-500">{sub}</p>}
        </div>
      </div>
      {right && <div className="flex shrink-0 items-center gap-2">{right}</div>}
    </div>
  )
}

export function Help({ children, title = 'In plain English' }: { children: React.ReactNode; title?: string }) {
  return (
    <div className="flex gap-3 rounded-xl border border-sky-100 bg-sky-50/70 px-4 py-3 text-[13px] leading-relaxed text-sky-950">
      <Info className="mt-0.5 h-4 w-4 shrink-0 text-sky-700" />
      <div>
        <span className="font-semibold">{title}: </span>
        {children}
      </div>
    </div>
  )
}

export function PageTitle({ title, plain, right, kicker }: { title: string; plain: string; right?: React.ReactNode; kicker?: string }) {
  return (
    <div className="mb-5 flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
      <div>
        {kicker && <div className="mb-1 text-xs font-bold uppercase tracking-[.14em] text-brand-600">{kicker}</div>}
        <h1 className="text-2xl font-extrabold tracking-tight text-ink-900 md:text-[28px]">{title}</h1>
        <p className="mt-1 max-w-2xl text-[14px] leading-relaxed text-ink-500">{plain}</p>
      </div>
      {right && <div className="flex flex-wrap items-center gap-2">{right}</div>}
    </div>
  )
}

export function Modal({ open, onClose, title, children, wide, footer }: { open: boolean; onClose: () => void; title: React.ReactNode; children: React.ReactNode; wide?: boolean; footer?: React.ReactNode }) {
  useEffect(() => {
    if (!open) return
    const on = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', on)
    return () => window.removeEventListener('keydown', on)
  }, [open, onClose])
  if (!open) return null
  return (
    <div className="fixed inset-0 z-[70] flex items-end justify-center bg-ink-900/45 backdrop-blur-[2px] sm:items-center sm:p-4" onClick={onClose} role="dialog" aria-modal="true">
      <div onClick={(e) => e.stopPropagation()} className={cx('rise flex max-h-[92vh] w-full flex-col overflow-hidden rounded-t-2xl bg-white shadow-2xl sm:rounded-2xl', wide ? 'sm:max-w-4xl' : 'sm:max-w-lg')}>
        <div className="flex items-center justify-between border-b border-silver-200 px-5 py-4">
          <h2 className="text-base font-bold">{title}</h2>
          <button onClick={onClose} className="rounded-lg p-1.5 text-ink-500 hover:bg-silver-100" aria-label="Close">
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="scroll-thin overflow-y-auto px-5 py-4">{children}</div>
        {footer && <div className="flex flex-wrap justify-end gap-2 border-t border-silver-200 bg-silver-50 px-5 py-3">{footer}</div>}
      </div>
    </div>
  )
}

export function Drawer({ open, onClose, title, children, footer, width = 'max-w-2xl' }: { open: boolean; onClose: () => void; title: React.ReactNode; children: React.ReactNode; footer?: React.ReactNode; width?: string }) {
  useEffect(() => {
    if (!open) return
    const on = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', on)
    return () => window.removeEventListener('keydown', on)
  }, [open, onClose])
  if (!open) return null
  return (
    <div className="fixed inset-0 z-[60] flex justify-end bg-ink-900/35" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} className={cx('flex h-full w-full flex-col bg-white shadow-2xl', width)} style={{ animation: 'rise .2s ease-out' }}>
        <div className="flex items-center justify-between gap-3 border-b border-silver-200 px-5 py-4">
          <div className="min-w-0 text-base font-bold">{title}</div>
          <button onClick={onClose} className="rounded-lg p-1.5 text-ink-500 hover:bg-silver-100" aria-label="Close">
            <X className="h-5 w-5" />
          </button>
        </div>
        <div className="scroll-thin flex-1 overflow-y-auto">{children}</div>
        {footer && <div className="flex flex-wrap items-center justify-end gap-2 border-t border-silver-200 bg-silver-50 px-5 py-3">{footer}</div>}
      </div>
    </div>
  )
}

export function Field({ label, hint, children, className }: { label: string; hint?: React.ReactNode; children: React.ReactNode; className?: string }) {
  return (
    <label className={cx('block', className)}>
      <span className="mb-1 block text-[12px] font-semibold text-ink-700">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-[11.5px] leading-snug text-ink-500">{hint}</span>}
    </label>
  )
}
export const inputCls = 'w-full rounded-lg border border-silver-300 bg-white px-3 py-2 text-sm text-ink-900 placeholder:text-ink-400 focus:border-brand-600 focus:outline-none focus:ring-2 focus:ring-brand-600/15'
export const Input = React.forwardRef<HTMLInputElement, React.InputHTMLAttributes<HTMLInputElement>>((p, ref) => <input ref={ref} {...p} className={cx(inputCls, p.className)} />)
export const Select = (p: React.SelectHTMLAttributes<HTMLSelectElement>) => <select {...p} className={cx(inputCls, 'pr-8', p.className)} />
export const Textarea = (p: React.TextareaHTMLAttributes<HTMLTextAreaElement>) => <textarea {...p} className={cx(inputCls, 'min-h-[84px]', p.className)} />

export function Avatar({ id, size = 'sm' }: { id: MemberId | null; size?: 'sm' | 'md' }) {
  const m = MEMBERS.find((x) => x.id === id)
  const s = size === 'sm' ? 'h-6 w-6 text-[10px]' : 'h-8 w-8 text-xs'
  if (!m) return <span className={cx('grid place-items-center rounded-full border border-dashed border-silver-400 text-ink-400', s)}>?</span>
  return (
    <span title={m.label} className={cx('grid shrink-0 place-items-center rounded-full font-bold text-white', m.color, s)}>
      {m.initials}
    </span>
  )
}

export function Toggle({ on, onChange, label, disabled }: { on: boolean; onChange: (v: boolean) => void; label?: string; disabled?: boolean }) {
  return (
    <button type="button" role="switch" aria-checked={on} aria-label={label} disabled={disabled} onClick={() => onChange(!on)} className={cx('relative inline-flex h-6 w-11 shrink-0 items-center rounded-full transition disabled:opacity-40', on ? 'bg-emerald-600' : 'bg-silver-300')}>
      <span className={cx('inline-block h-5 w-5 transform rounded-full bg-white shadow transition', on ? 'translate-x-5' : 'translate-x-0.5')} />
    </button>
  )
}

export function ScoreRing({ score, size = 44 }: { score: number; size?: number }) {
  const r = size / 2 - 4
  const c = 2 * Math.PI * r
  const col = score >= 85 ? '#059669' : score >= 65 ? '#d97706' : '#c8102e'
  return (
    <div className="relative shrink-0" style={{ width: size, height: size }} title={`Listing health ${score}/100`}>
      <svg width={size} height={size} className="-rotate-90">
        <circle cx={size / 2} cy={size / 2} r={r} stroke="#eceef1" strokeWidth="4" fill="none" />
        <circle cx={size / 2} cy={size / 2} r={r} stroke={col} strokeWidth="4" fill="none" strokeDasharray={c} strokeDashoffset={c * (1 - score / 100)} strokeLinecap="round" style={{ transition: 'stroke-dashoffset .6s' }} />
      </svg>
      <div className="absolute inset-0 grid place-items-center text-[12px] font-bold" style={{ color: col }}>
        {score}
      </div>
    </div>
  )
}

// ---------------- Synthetic vehicle imagery (no real photos are used) ----------------
const BODY_PATH: Record<string, string> = {
  Sedan: 'M22 128 Q18 116 30 108 L52 100 Q80 92 104 90 L136 66 Q148 58 170 58 L214 59 Q234 60 252 82 L286 90 Q302 94 304 110 L304 124 Q303 130 294 130 L30 130 Q22 130 22 128Z',
  SUV: 'M20 130 L20 100 Q22 86 46 82 L96 78 L120 52 Q126 46 142 46 L244 47 Q258 48 266 60 L284 82 Q302 86 304 102 L304 126 Q303 131 294 131 L28 131 Q20 131 20 130Z',
  Truck: 'M18 130 L18 98 Q20 86 44 84 L88 82 L110 54 Q116 48 128 48 L178 48 Q188 48 190 58 L192 84 L298 84 Q304 84 305 92 L305 126 Q304 131 296 131 L26 131 Q18 131 18 130Z',
  Hatchback: 'M24 130 L24 98 Q26 82 56 78 L94 56 Q102 48 118 48 L244 49 Q258 49 264 62 L282 96 Q296 100 298 114 L298 126 Q297 131 288 131 L32 131 Q24 131 24 130Z',
  Coupe: 'M22 128 Q18 116 30 108 L60 98 Q88 92 110 90 L146 68 Q156 62 176 62 L210 63 Q232 66 256 86 L290 92 Q304 96 304 112 L304 124 Q303 130 294 130 L30 130 Q22 130 22 128Z',
  Van: 'M20 130 L20 70 Q22 50 46 48 L250 48 Q266 48 274 62 L296 92 Q304 96 304 108 L304 126 Q303 131 294 131 L28 131 Q20 131 20 130Z',
}
const WIN_PATH: Record<string, string> = {
  Sedan: 'M140 70 Q150 63 168 63 L176 63 L176 88 L118 89Z M182 63 L212 64 Q228 66 242 86 L182 88Z',
  SUV: 'M126 56 Q132 51 146 51 L178 51 L178 79 L104 80Z M184 51 L240 52 Q252 53 258 62 L272 80 L184 79Z',
  Truck: 'M116 58 Q120 53 130 53 L150 53 L150 81 L96 82Z M156 53 L176 53 Q182 53 183 60 L184 81 L156 81Z',
  Hatchback: 'M100 60 Q107 53 120 53 L168 53 L168 78 L66 79Z M174 53 L242 54 Q252 54 256 64 L268 84 L174 80Z',
  Coupe: 'M150 72 Q158 67 176 67 L190 67 L190 88 L124 89Z M196 67 L210 68 Q228 70 244 87 L196 88Z',
  Van: 'M52 56 L118 56 L118 84 L40 84Z M126 56 L198 56 L198 84 L126 84Z M206 56 L248 56 Q262 56 268 66 L284 88 L206 86Z',
}

const isExterior = (shot: string) => /front|side|rear|profile/i.test(shot) && !/seat/i.test(shot)

// A real example photo of a similar vehicle. Always labeled so shoppers never mistake it for the actual car.
export function ExamplePhoto({ id, by, alt, className, label = true, w = 1200, fallback, caption }: { id: string; by: string; alt: string; className?: string; label?: boolean; w?: number; fallback?: React.ReactNode; caption?: string }) {
  const [failed, setFailed] = useState(false)
  if (failed && fallback) return <>{fallback}</>
  return (
    <div className="relative h-full w-full overflow-hidden bg-silver-100">
      <img src={unsplash(id, w)} alt={`Example photo of a similar ${alt} — not the actual vehicle`} loading="lazy" onError={() => setFailed(true)} className={cx('h-full w-full object-cover', className)} />
      <div className="absolute bottom-1.5 left-1.5 rounded bg-black/60 px-1.5 py-0.5 text-[9.5px] font-semibold tracking-wide text-white">
        {caption ?? `Example photo${label ? ` · not this exact car · Photo: ${by} / Unsplash` : ''}`}
      </div>
    </div>
  )
}

export function CarArt(props: { v: Pick<Vehicle, 'body' | 'colorHex' | 'year' | 'make' | 'model'> & { examplePhoto?: Vehicle['examplePhoto'] }; shot?: string; className?: string; label?: boolean; src?: string }) {
  const { v, shot, src, label = true } = props
  if (!src && v.examplePhoto && (!shot || shot === PHOTO_SHOTS[0])) {
    return <ExamplePhoto id={v.examplePhoto.id} by={v.examplePhoto.by} alt={`${v.year} ${v.make} ${v.model}`} className={props.className} label={label} w={label ? 1400 : 800} fallback={<CarIllustration {...props} />} />
  }
  return <CarIllustration {...props} />
}

function CarIllustration({ v, shot = 'Side profile (driver)', className, label = true, src }: { v: Pick<Vehicle, 'body' | 'colorHex' | 'year' | 'make' | 'model'>; shot?: string; className?: string; label?: boolean; src?: string }) {
  if (src) return <img src={src} alt={`${v.year} ${v.make} ${v.model} — ${shot}`} className={cx('h-full w-full object-cover', className)} />
  const flip = /rear/i.test(shot) && !/seat/i.test(shot)
  const ext = isExterior(shot)
  const light = parseInt(v.colorHex.slice(1, 3), 16) > 200
  return (
    <div className={cx('relative h-full w-full overflow-hidden', className)} role="img" aria-label={`Demo illustration placeholder: ${v.year} ${v.make} ${v.model}, ${shot}. Not a photo of the actual vehicle.`}>
      <svg viewBox="0 0 320 180" preserveAspectRatio="xMidYMid slice" className="h-full w-full">
        <defs>
          <linearGradient id="bgG" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor="#f7f8fa" />
            <stop offset="1" stopColor="#dfe3e8" />
          </linearGradient>
          <linearGradient id={`bodyG${v.colorHex.slice(1)}`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0" stopColor={v.colorHex} stopOpacity="1" />
            <stop offset="1" stopColor={light ? '#c5cad1' : '#0c0e12'} stopOpacity={light ? 0.9 : 0.55} />
          </linearGradient>
        </defs>
        <rect width="320" height="180" fill="url(#bgG)" />
        <rect y="138" width="320" height="42" fill="#d4d9df" />
        <path d="M0 138 L320 138" stroke="#c8102e" strokeWidth="2" opacity=".55" />
        {ext ? (
          <g transform={flip ? 'translate(320 0) scale(-1 1)' : undefined}>
            <ellipse cx="163" cy="138" rx="140" ry="8" fill="#000" opacity=".14" />
            <path d={BODY_PATH[v.body] ?? BODY_PATH.Sedan} fill={`url(#bodyG${v.colorHex.slice(1)})`} stroke={light ? '#aeb5be' : '#0b0d10'} strokeWidth="1.2" />
            <path d={WIN_PATH[v.body] ?? WIN_PATH.Sedan} fill="#2b3340" opacity=".88" />
            <path d="M40 112 L290 112" stroke="#fff" strokeOpacity=".22" strokeWidth="2" />
            <rect x="286" y="100" width="14" height="6" rx="2" fill="#ffe8a3" />
            <rect x="24" y="104" width="10" height="6" rx="2" fill="#c8102e" />
            {[v.body === 'Truck' ? 74 : 82, v.body === 'Truck' ? 252 : 246].map((cxv) => (
              <g key={cxv}>
                <circle cx={cxv} cy="130" r="21" fill="#1b1e24" />
                <circle cx={cxv} cy="130" r="12" fill="#bec5ce" />
                <circle cx={cxv} cy="130" r="4" fill="#5f6776" />
              </g>
            ))}
          </g>
        ) : (
          <g>
            <rect x="60" y="34" width="200" height="104" rx="14" fill="#fff" stroke="#bec5ce" />
            {/dash|odometer/i.test(shot) ? (
              <g>
                <circle cx="160" cy="92" r="30" fill="none" stroke="#3a4150" strokeWidth="7" />
                <circle cx="160" cy="92" r="6" fill="#3a4150" />
                <path d="M130 92 L190 92 M160 92 L160 122" stroke="#3a4150" strokeWidth="5" />
                <rect x="96" y="44" width="128" height="14" rx="4" fill="#eceef1" />
              </g>
            ) : (
              <g fill="#bec5ce">
                <rect x="132" y="62" width="56" height="40" rx="8" />
                <circle cx="160" cy="82" r="11" fill="#fff" />
                <circle cx="160" cy="82" r="6" fill="#bec5ce" />
              </g>
            )}
          </g>
        )}
      </svg>
      {label && (
        <div className="absolute bottom-1.5 left-1.5 rounded bg-white/85 px-1.5 py-0.5 text-[9px] font-semibold uppercase tracking-wide text-ink-500">
          Demo image · {shot}
        </div>
      )}
    </div>
  )
}

export function PhotoImg({ v, p, className, label }: { v: Vehicle; p?: Photo; className?: string; label?: boolean }) {
  return <CarArt v={v} shot={p?.shot} src={p?.src} className={className} label={label} />
}

export function Empty({ icon, title, body, action }: { icon?: React.ReactNode; title: string; body?: string; action?: React.ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 rounded-xl border border-dashed border-silver-300 px-6 py-10 text-center">
      {icon && <div className="text-silver-400">{icon}</div>}
      <div className="font-semibold text-ink-800">{title}</div>
      {body && <p className="max-w-sm text-sm text-ink-500">{body}</p>}
      {action}
    </div>
  )
}

export function Tabs<T extends string>({ value, onChange, items }: { value: T; onChange: (v: T) => void; items: { id: T; label: React.ReactNode }[] }) {
  return (
    <div className="scroll-thin flex gap-1 overflow-x-auto rounded-xl bg-silver-100 p-1">
      {items.map((it) => (
        <button key={it.id} onClick={() => onChange(it.id)} className={cx('whitespace-nowrap rounded-lg px-3 py-1.5 text-[13px] font-semibold transition', value === it.id ? 'bg-white text-ink-900 shadow-sm' : 'text-ink-500 hover:text-ink-900')}>
          {it.label}
        </button>
      ))}
    </div>
  )
}

// Plain-English tooltip for jargon
export const GLOSSARY: Record<string, string> = {
  DMS: 'Dealer Management System — the main back-office software (for example Frazer or DealerCenter) that holds deals, accounting and official records.',
  Lead: 'A customer who has asked about a car — by website, phone, text, email, Marketplace or walking in.',
  Sync: 'Copying a change from one system to another so they match. In this demo, changes are only lined up (“staged”), never actually sent.',
  'Audit trail': 'A diary of who did what and when — every AI suggestion, approval and change is written down.',
  API: 'A secure, official way for two pieces of software to talk. Only used if the vendor offers one and the dealer authorizes it.',
  CSV: 'A simple spreadsheet file. Most dealership systems can export and import it — the easiest first step.',
  Consent: 'The customer’s permission to be texted, emailed or called. No automated messages go out without it.',
  MFA: 'Multi-factor authentication — logging in with a password plus a code from your phone.',
  'Structured data': 'Hidden labels on a web page that help Google understand a car listing (price, mileage, etc.).',
}
export function Term({ k, children }: { k: keyof typeof GLOSSARY | string; children?: React.ReactNode }) {
  return (
    <span className="group relative inline cursor-help border-b border-dotted border-ink-400" tabIndex={0}>
      {children ?? k}
      <span role="tooltip" className="pointer-events-none absolute bottom-full left-1/2 z-50 mb-2 hidden w-64 -translate-x-1/2 rounded-lg bg-ink-900 px-3 py-2 text-left text-[12px] font-normal leading-snug text-white shadow-xl group-hover:block group-focus:block">
        {GLOSSARY[k] ?? ''}
      </span>
    </span>
  )
}
