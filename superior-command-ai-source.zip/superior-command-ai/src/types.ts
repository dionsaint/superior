export type Wall = string // 'YYYY-MM-DDTHH:mm' — Eastern Time wall clock (St. Petersburg, FL)

export type StaffPage = 'dashboard' | 'leads' | 'listings' | 'deals' | 'calendar' | 'frontdesk' | 'roi' | 'settings'
export type PublicPage = 'home' | 'inventory' | 'vehicle' | 'trade-in' | 'financing' | 'about' | 'contact' | 'faq' | 'privacy'
export type ScreenId = StaffPage

export type Role = 'owner' | 'sales' | 'admin' | 'inventory'
export type MemberId = 'owner' | 's1' | 's2' | 'admin'

export interface Member {
  id: MemberId
  label: string
  role: string
  initials: string
  color: string
}

export type VehicleStatus = 'available' | 'pending' | 'sold' | 'unclear'
export type ListingState = 'published' | 'draft' | 'unpublished'

export interface Photo {
  id: string
  shot: string
  src?: string // local preview only (data URL)
}

export type SyncState = 'synced' | 'staged' | 'conflict' | 'failed' | 'never'

export interface Vehicle {
  id: string
  stock: string
  year: number
  make: string
  model: string
  trim: string
  body: 'Sedan' | 'SUV' | 'Truck' | 'Coupe' | 'Hatchback' | 'Van'
  vin: string
  price: number | null // displayed asking price; null = "Please Call"
  cost: number // owner-only
  prepCost: number // owner-only
  acquired: string // YYYY-MM-DD
  mileage: number | null
  photos: Photo[]
  description: string
  features: string[]
  conditionNotes: string
  disclosure: string
  titleStatus: string
  daysOnLot: number
  status: VehicleStatus
  listing: ListingState
  color: string
  colorHex: string
  engine: string
  transmission: string
  drivetrain: string
  fuel: string
  mpg?: string
  assignedTo: MemberId
  updatedAt: Wall
  syncState: SyncState
  // discrepancy markers (synthetic)
  dmsVin?: string
  dmsTrim?: string
  dmsStatus?: VehicleStatus
  duplicateOf?: string
  reviewTask?: boolean
  archived?: boolean
  examplePhoto?: { id: string; by: string } // stock example photo (Unsplash) — NOT the actual vehicle
}

export type IssueCode =
  | 'price'
  | 'mileage'
  | 'vin'
  | 'availability'
  | 'duplicate'
  | 'photos'
  | 'description'
  | 'trim'
  | 'stale'
  | 'soldNotRemoved'

export interface Issue {
  code: IssueCode
  label: string
  detail: string
  severity: 'high' | 'med' | 'low'
  points: number
  plain: string
}

export type LeadSource = 'website' | 'phone' | 'email' | 'facebook' | 'offerup' | 'walkin'
export type Stage = 'new' | 'contacted' | 'appointment' | 'negotiating' | 'sold' | 'lost'

export interface Msg {
  id: string
  from: 'customer' | 'ai' | 'staff' | 'system'
  text: string
  at: Wall
  status?: 'draft' | 'sent-demo'
}

export interface Consent {
  sms: boolean
  email: boolean
  call: boolean
  source: string
  at: Wall | null
  stopped: boolean
}

export interface Lead {
  id: string
  name: string
  phone: string
  email: string
  source: LeadSource
  vehicleId: string | null
  budget: string | null
  tradeIn: string | null
  channel: 'sms' | 'email' | 'phone'
  assignedTo: MemberId | null
  stage: Stage
  consent: Consent
  urgency: 'high' | 'med' | 'low'
  nextAction: string
  createdAt: Wall
  messages: Msg[]
  automationPaused: boolean
  humanTakeover: boolean
  missed: boolean
  callbackRequested: boolean
  autoSentToday: number
  draft: string | null
  kind: LeadKind
  trade?: TradeInfo
}

export type LeadKind = 'inquiry' | 'test-drive' | 'trade-in' | 'financing' | 'contact' | 'availability'

export interface TradeInfo {
  year: string
  make: string
  model: string
  mileage: string
  condition: string
  appraisal: 'Awaiting review' | 'Inspection booked' | 'Offer prepared by staff' | 'Declined'
}

export type DealStage = 'deposit' | 'financing' | 'signature' | 'id' | 'title' | 'stips' | 'delivery'
export type DocStatus = 'complete' | 'pending' | 'missing' | 'na'

export interface DealDoc {
  key: string
  label: string
  status: DocStatus
  owner: MemberId
  applicable: boolean
  note?: string
}

export interface Deal {
  id: string
  number: string
  customer: string
  vehicleLabel: string
  stage: DealStage
  salesperson: MemberId
  docs: DealDoc[]
  events: { at: Wall; text: string; who: string }[]
  waitingDays: number
  waitingFor: string
  depositFlag: boolean
  sampleDocText: string
  aiChecked: boolean
  pendingRequest: { text: string; doc: string } | null
  summary: string | null
}

export interface PromiseItem {
  id: string
  dealNumber: string
  customer: string
  vehicle: string
  item: string
  owner: MemberId
  due: string
  status: 'open' | 'scheduled' | 'done'
  sample?: boolean
}

export interface Appointment {
  id: string
  leadId: string | null
  customer: string
  vehicleId: string | null
  start: Wall
  duration: number
  salesperson: MemberId
  notes: string
  reminder: 'queued' | 'none'
  status: 'booked' | 'attended' | 'no-show' | 'hold'
  kind: 'Test drive' | 'Callback' | 'Delivery' | 'Appraisal'
}

export interface Rule {
  id: string
  name: string
  trigger: string
  conditions: string
  action: string
  review: 'auto-safe' | 'staff-confirm'
  enabled: boolean
}

export interface Task {
  id: string
  title: string
  owner: MemberId
  due: Wall
  status: 'todo' | 'in-progress' | 'awaiting-approval' | 'done'
  link: { screen: ScreenId; id?: string }
  createdBy: 'ai' | 'staff'
}

export interface AuditEntry {
  id: string
  at: Wall
  actor: string
  kind: 'suggestion' | 'approval' | 'change' | 'message' | 'automation' | 'system'
  text: string
  done: boolean // true = simulated completed, false = recommended human action
  link?: { screen: ScreenId; id?: string }
}

export interface SyncItem {
  id: string
  vehicleId: string
  label: string
  before: string
  after: string
  target: string
  at: Wall
  state: 'staged' | 'conflict' | 'failed' | 'resolved' | 'exported'
  note?: string
}

export interface Hours {
  [dow: number]: { open: string; close: string } | null
}

export interface RoiState {
  employees: number
  hourly: number
  burden: number
  hLeads: number
  hScheduling: number
  hListings: number
  hPaperwork: number
  adoption: number
  fee: number
  pLeads: number
  pScheduling: number
  pListings: number
  pPaperwork: number
}

export interface Dealer {
  name: string
  street: string
  city: string
  zip: string
  phone: string
  dealerFee: number | null
}

export interface DataState {
  version: number
  now: Wall
  role: Role
  theme: 'white' | 'silver'
  dealer: Dealer
  members: Member[]
  vehicles: Vehicle[]
  leads: Lead[]
  deals: Deal[]
  promises: PromiseItem[]
  appointments: Appointment[]
  rules: Rule[]
  tasks: Task[]
  audit: AuditEntry[]
  sync: SyncItem[]
  hours: Hours
  roi: RoiState
  quietStart: string
  quietEnd: string
  freqCap: number
  offHoursOverride: 'auto' | 'on' | 'off'
  rrIndex: number
  seq: number
  favorites: string[]
  compare: string[]
}
