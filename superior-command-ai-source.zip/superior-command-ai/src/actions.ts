import type { AuditEntry, DataState, DealStage, Lead, LeadKind, LeadSource, ListingState, MemberId, Photo, ScreenId, Stage, TradeInfo, Vehicle, VehicleStatus, Wall } from './types'
import type { Ctx } from './store'
import { addMin, fmtDay, fmtTime, nextSlots } from './time'
import { PHOTO_SHOTS, COLOR_HEX } from './data'
import { canAutoMessage, checkDocText, conciergeReply, isOffHours, vName } from './logic'

export const uid = (s: DataState, p: string) => `${p}${++s.seq}`
export const memberLabel = (s: DataState, id: MemberId | null) => s.members.find((m) => m.id === id)?.label ?? 'Unassigned'
const actorLabel = (s: DataState) => ({ owner: 'Owner', sales: 'Salesperson', admin: 'Admin / Title', inventory: 'Inventory' })[s.role]

export function log(s: DataState, kind: AuditEntry['kind'], text: string, done: boolean, link?: { screen: ScreenId; id?: string }, actor?: string) {
  s.audit.unshift({ id: uid(s, 'au'), at: s.now, actor: actor ?? (kind === 'approval' || kind === 'change' ? actorLabel(s) : 'AI (demo)'), kind, text, done, link })
  if (s.audit.length > 80) s.audit.length = 80
}

const SALES: MemberId[] = ['s1', 's2']
export function roundRobin(s: DataState): MemberId {
  const m = SALES[s.rrIndex % SALES.length]
  s.rrIndex++
  return m
}

const TEMPLATES: { name: string; source: LeadSource; vehicleId: string; text: string; channel: Lead['channel']; sms: boolean; budget?: string; trade?: string }[] = [
  { name: 'Priya S.', source: 'website', vehicleId: 'v01', text: 'Is the Camry still available? What are the miles?', channel: 'sms', sms: true },
  { name: 'Derrick J.', source: 'facebook', vehicleId: 'v04', text: 'Silverado still for sale? Does it have the tow package?', channel: 'sms', sms: false, trade: '2011 Ram 1500 (customer-stated)' },
  { name: 'Nina V.', source: 'email', vehicleId: 'v15', text: 'Can I get financing on the Altima? What would my payment be?', channel: 'email', sms: false, budget: '$15k–$17k' },
  { name: 'Carlos M.', source: 'offerup', vehicleId: 'v13', text: 'Any accidents on the Tacoma? Is it still available?', channel: 'sms', sms: true },
  { name: 'Grace H.', source: 'website', vehicleId: 'v10', text: 'Could I test drive the Kia Soul this week?', channel: 'sms', sms: true, budget: 'Under $16k' },
  { name: 'Andre W.', source: 'walkin', vehicleId: 'v06', text: 'Walk-in: looked at the Escape, wants to come back with spouse.', channel: 'phone', sms: false },
  { name: 'Sofia R.', source: 'website', vehicleId: 'v03', text: 'How much is the Rogue and how many miles?', channel: 'email', sms: false },
]

export function simulateLead(s: DataState, ctx: Ctx, idx?: number, opts?: { text?: string; vehicleId?: string; name?: string; source?: LeadSource; sms?: boolean }) {
  const tpl = TEMPLATES[(idx ?? s.seq) % TEMPLATES.length]
  const id = uid(s, 'l')
  const sms = opts?.sms ?? tpl.sms
  const src = opts?.source ?? tpl.source
  const lead: Lead = {
    id,
    name: opts?.name ?? tpl.name,
    phone: `(727) 555-01${String(s.seq % 100).padStart(2, '0')}`,
    email: (opts?.name ?? tpl.name).split(' ')[0].toLowerCase() + '@example.com',
    source: src,
    kind: 'inquiry',
    vehicleId: opts?.vehicleId ?? tpl.vehicleId,
    budget: tpl.budget ?? null,
    tradeIn: tpl.trade ?? null,
    channel: tpl.channel,
    assignedTo: null,
    stage: 'new',
    consent: { sms, email: true, call: true, source: sms ? (src === 'website' ? 'Website chat — SMS opt-in checkbox (demo)' : 'Customer texted first — staff to verify') : src === 'facebook' || src === 'offerup' ? 'Platform message — no SMS opt-in' : 'Web/email inquiry — email reply permitted', at: s.now, stopped: false },
    urgency: 'high',
    nextAction: 'Respond',
    createdAt: s.now,
    messages: [{ id: uid(s, 'm'), from: src === 'walkin' ? 'system' : 'customer', text: opts?.text ?? tpl.text, at: s.now }],
    automationPaused: false,
    humanTakeover: false,
    missed: false,
    callbackRequested: false,
    autoSentToday: 0,
    draft: null,
  }
  if (src === 'facebook' || src === 'offerup') lead.consent.email = false
  s.leads.unshift(lead)
  log(s, 'automation', `New ${srcLabel(src)} lead captured: ${lead.name} — ${vName(s.vehicles.find((v) => v.id === lead.vehicleId))}`, true, { screen: 'leads', id })
  ctx.toast(`New lead from ${srcLabel(src)}: ${lead.name} (simulated)`, 'info')
  return id
}

export function simulateMissedCall(s: DataState, ctx: Ctx) {
  const id = uid(s, 'l')
  const lead: Lead = {
    id,
    name: 'Caller (727) 555-0188',
    phone: '(727) 555-0188',
    email: '',
    source: 'phone',
    kind: 'inquiry',
    vehicleId: 'v02',
    budget: null,
    tradeIn: null,
    channel: 'sms',
    assignedTo: null,
    stage: 'new',
    consent: { sms: true, email: false, call: true, source: 'Voicemail: caller asked for a text back (staff to verify)', at: s.now, stopped: false },
    urgency: 'high',
    nextAction: 'Approve callback text',
    createdAt: s.now,
    messages: [
      { id: uid(s, 'm'), from: 'system', text: `Missed call at ${fmtTime(s.now)} — 0:38 voicemail.`, at: s.now },
      { id: uid(s, 'm'), from: 'system', text: 'Voicemail (synthetic transcript): "Hi, calling about the gray Honda CR-V. Can you text me back? Thanks."', at: s.now },
    ],
    automationPaused: false,
    humanTakeover: false,
    missed: true,
    callbackRequested: true,
    autoSentToday: 0,
    draft: 'Hi, this is Superior Auto Mall returning your call about the 2018 Honda CR-V EX. Our record shows it listed at $19,750 with 74,810 miles. When’s a good time to talk or stop by? Reply STOP to opt out.',
  }
  s.leads.unshift(lead)
  s.tasks.unshift({ id: uid(s, 'tk'), title: 'Approve callback text — missed call (727) 555-0188', owner: 'owner', due: addMin(s.now, 30), status: 'awaiting-approval', link: { screen: 'leads', id }, createdBy: 'ai' })
  log(s, 'automation', 'Missed call captured; callback text drafted for manager approval', true, { screen: 'leads', id })
  log(s, 'suggestion', 'Recommended: approve callback text to (727) 555-0188', false, { screen: 'leads', id })
  ctx.toast('Missed call captured — callback draft awaiting approval (simulated)', 'warn')
  return id
}

export const srcLabel = (src: LeadSource) => ({ website: 'Website', phone: 'Phone', email: 'Email', facebook: 'FB Marketplace', offerup: 'OfferUp', walkin: 'Walk-in' })[src]

export function assignLead(s: DataState, ctx: Ctx, id: string, m?: MemberId) {
  const l = s.leads.find((x) => x.id === id)
  if (!l) return
  l.assignedTo = m ?? roundRobin(s)
  log(s, m ? 'change' : 'automation', `${l.name} assigned to ${memberLabel(s, l.assignedTo)}${m ? '' : ' (round-robin)'}`, true, { screen: 'leads', id })
  ctx.toast(`Assigned to ${memberLabel(s, l.assignedTo)}`, 'ok')
}

export function draftReply(s: DataState, ctx: Ctx, id: string) {
  const l = s.leads.find((x) => x.id === id)
  if (!l) return
  const last = [...l.messages].reverse().find((m) => m.from === 'customer' || m.from === 'system')
  const first = !l.messages.some((m) => m.from === 'ai' || m.from === 'staff')
  const out = conciergeReply(last?.text ?? 'Hello', {
    vehicles: s.vehicles,
    offHours: isOffHours(s),
    slots: nextSlots(s.now, s.hours, s.appointments),
    first,
    vehicleId: l.vehicleId,
    hours: s.hours,
    sms: l.channel === 'sms',
  })
  l.draft = out.text
  log(s, 'suggestion', `Drafted reply for ${l.name} — awaiting approval`, false, { screen: 'leads', id })
  ctx.toast('Draft created from demo inventory fields only. Review before approving.', 'info')
}

export function approveDraft(s: DataState, ctx: Ctx, id: string, text?: string) {
  const l = s.leads.find((x) => x.id === id)
  if (!l || !(text ?? l.draft)) return
  const body = (text ?? l.draft)!
  l.messages.push({ id: uid(s, 'm'), from: 'staff', text: body, at: s.now, status: 'sent-demo' })
  l.draft = null
  l.missed = false
  l.callbackRequested = false
  if (l.stage === 'new') l.stage = 'contacted'
  l.nextAction = 'Await customer reply'
  s.tasks.forEach((t) => {
    if (t.link.id === id && t.status === 'awaiting-approval') t.status = 'done'
  })
  log(s, 'approval', `Approved reply to ${l.name} via ${l.channel.toUpperCase()} — DEMO, not sent`, true, { screen: 'leads', id })
  ctx.toast('DEMO — no real message sent. Approval logged to audit trail.', 'demo')
}

export function autoReply(s: DataState, ctx: Ctx, id: string) {
  const l = s.leads.find((x) => x.id === id)
  if (!l) return
  const gate = canAutoMessage(s, l)
  const last = [...l.messages].reverse().find((m) => m.from === 'customer')
  const out = conciergeReply(last?.text ?? 'Hello', { vehicles: s.vehicles, offHours: isOffHours(s), slots: nextSlots(s.now, s.hours, s.appointments), first: true, vehicleId: l.vehicleId, hours: s.hours, sms: l.channel === 'sms' })
  if (gate.ok) {
    l.messages.push({ id: uid(s, 'm'), from: 'ai', text: out.text, at: addMin(s.now, 1), status: 'sent-demo' })
    l.autoSentToday++
    l.stage = 'contacted'
    l.missed = false
    l.nextAction = out.offeredSlots.length ? 'Customer choosing a slot' : 'Staff follow-up when open'
    log(s, 'automation', `After-hours rule: AI acknowledgment to ${l.name} (${gate.reason}) — DEMO, not sent`, true, { screen: 'leads', id })
    ctx.toast('DEMO — AI reply simulated, no real message sent.', 'demo')
  } else {
    l.draft = out.text
    log(s, 'suggestion', `Auto-reply blocked (${gate.reason}); draft queued for staff approval`, false, { screen: 'leads', id })
    ctx.toast(`Automation held: ${gate.reason}. Draft queued for approval.`, 'warn')
  }
  return out.offeredSlots
}

export function bookTestDrive(s: DataState, ctx: Ctx, leadId: string, slot?: Wall, by?: MemberId) {
  const l = s.leads.find((x) => x.id === leadId)
  if (!l) return
  const start = slot ?? nextSlots(s.now, s.hours, s.appointments)[0]
  if (!start) return
  if (!l.assignedTo) l.assignedTo = by ?? roundRobin(s)
  const reminder = l.consent.sms && !l.consent.stopped ? 'queued' : 'none'
  s.appointments.push({ id: uid(s, 'a'), leadId, customer: l.name, vehicleId: l.vehicleId, start, duration: 60, salesperson: l.assignedTo, notes: `Booked from ${srcLabel(l.source)} conversation.`, reminder, status: 'booked', kind: 'Test drive' })
  l.stage = 'appointment'
  l.missed = false
  l.nextAction = `Test drive ${fmtDay(start)} ${fmtTime(start)}`
  l.messages.push({ id: uid(s, 'm'), from: 'system', text: `Test drive booked: ${fmtDay(start)} ${fmtTime(start)} with ${memberLabel(s, l.assignedTo)}. Reminder ${reminder === 'queued' ? 'queued (demo — will not send)' : 'not queued — no SMS consent'}.`, at: s.now })
  log(s, 'automation', `Test drive booked for ${l.name} — ${fmtDay(start)} ${fmtTime(start)} with ${memberLabel(s, l.assignedTo)}`, true, { screen: 'calendar' })
  ctx.toast(`Appointment created ${fmtDay(start)} ${fmtTime(start)} — calendar & inbox updated`, 'ok')
}

export function setStage(s: DataState, ctx: Ctx, id: string, stage: Stage) {
  const l = s.leads.find((x) => x.id === id)
  if (!l || l.stage === stage) return
  const from = l.stage
  l.stage = stage
  if (stage !== 'new') l.missed = false
  log(s, 'change', `${l.name}: ${from} → ${stage}`, true, { screen: 'leads', id })
  ctx.toast(`${l.name} moved to ${stage[0].toUpperCase() + stage.slice(1)}`, 'ok')
}

export function applyVehicle(s: DataState, ctx: Ctx, id: string, patch: Partial<Vehicle>, changes: { label: string; before: string; after: string }[]) {
  const v = s.vehicles.find((x) => x.id === id)
  if (!v) return
  Object.assign(v, patch)
  v.updatedAt = s.now
  if (changes.length) v.syncState = 'staged'
  for (const c of changes) s.sync.unshift({ id: uid(s, 'sy'), vehicleId: id, label: c.label, before: c.before, after: c.after, target: 'Dealer Car Search / DMS', at: s.now, state: 'staged' })
  log(s, 'approval', `Approved ${changes.length} listing change${changes.length > 1 ? 's' : ''} on ${v.stock} (${changes.map((c) => c.label).join(', ')}) — staged for sync, not pushed`, true, { screen: 'listings', id })
  s.tasks.forEach((t) => {
    if (t.link.id === id && t.status !== 'done') t.status = 'done'
  })
  ctx.toast('Saved. The public website updated right away. A copy is queued for Dealer Car Search / DMS — nothing was actually sent (demo).', 'demo')
}

export function moveDeal(s: DataState, ctx: Ctx, id: string, stage: DealStage) {
  const d = s.deals.find((x) => x.id === id)
  if (!d || d.stage === stage) return
  d.stage = stage
  d.events.push({ at: s.now, text: `Moved to ${DEAL_COLS.find((c) => c.id === stage)?.label}`, who: actorLabel(s) })
  log(s, 'change', `Deal ${d.number} moved to ${DEAL_COLS.find((c) => c.id === stage)?.label}`, true, { screen: 'deals', id })
  ctx.toast(`Deal ${d.number} moved`, 'ok')
}

export function runDocCheck(s: DataState, ctx: Ctx, id: string) {
  const d = s.deals.find((x) => x.id === id)
  if (!d) return []
  const f = checkDocText(d.sampleDocText)
  d.aiChecked = true
  const high = f.filter((x) => x.severity === 'high')
  for (const h of high) {
    const doc = d.docs.find((x) => x.key === h.doc)
    if (doc) {
      doc.status = 'missing'
      doc.note = h.text
    }
  }
  d.events.push({ at: s.now, text: `AI review of sample document text: ${f.length} potential omission${f.length === 1 ? '' : 's'} flagged`, who: 'AI (demo)' })
  if (high.some((h) => h.doc === 'buyers_order')) {
    if (d.stage === 'delivery') d.events.push({ at: s.now, text: 'Moved back from Delivery ready → Missing buyer signature', who: 'AI suggestion, auto-applied (internal status only)' })
    d.stage = 'signature'
    d.waitingFor = 'Buyer signature on buyer’s order'
    s.tasks.unshift({ id: uid(s, 'tk'), title: `Obtain buyer signature — Deal ${d.number}`, owner: 'admin', due: addMin(s.now, 24 * 60), status: 'todo', link: { screen: 'deals', id }, createdBy: 'ai' })
    d.pendingRequest = { doc: 'buyers_order', text: `Hi ${d.customer.split(' ')[0]}, this is Superior Auto Mall. One signature is still needed on your buyer’s order before we finalize your paperwork. Could you stop by, or tell us a good time? A team member will walk you through it. — Admin team` }
    log(s, 'suggestion', `Deal ${d.number}: buyer signature appears blank — task created for Admin / Title, customer request drafted (needs approval)`, false, { screen: 'deals', id })
  }
  ctx.toast(f.length ? `${f.length} potential omission${f.length > 1 ? 's' : ''} flagged — human review required` : 'No omissions flagged in sample text', f.length ? 'warn' : 'ok')
  return f
}

export function approveDocRequest(s: DataState, ctx: Ctx, id: string) {
  const d = s.deals.find((x) => x.id === id)
  if (!d || !d.pendingRequest) return
  d.events.push({ at: s.now, text: `Customer request approved: "${d.pendingRequest.text.slice(0, 60)}…" — DEMO, not sent`, who: actorLabel(s) })
  d.pendingRequest = null
  const doc = d.docs.find((x) => x.status === 'missing')
  if (doc) doc.note = (doc.note ?? '') + ' · Customer request approved (demo)'
  log(s, 'approval', `Approved document request to ${d.customer} (Deal ${d.number}) — DEMO, not sent`, true, { screen: 'deals', id })
  ctx.toast('DEMO — no real message sent. Human approval recorded.', 'demo')
}

export function draftDocRequest(s: DataState, ctx: Ctx, id: string, docKey: string) {
  const d = s.deals.find((x) => x.id === id)
  const doc = d?.docs.find((x) => x.key === docKey)
  if (!d || !doc) return
  d.pendingRequest = { doc: docKey, text: `Hi ${d.customer.split(' ')[0]}, this is Superior Auto Mall. To keep your paperwork moving we still need: ${doc.label.toLowerCase()}. You can bring it by or reply to arrange a time. — Admin team` }
  log(s, 'suggestion', `Drafted request for ${doc.label} — Deal ${d.number} (needs approval)`, false, { screen: 'deals', id })
  ctx.toast('Customer request drafted — a human must approve it.', 'info')
}

export function managerSummary(s: DataState, ctx: Ctx, id: string) {
  const d = s.deals.find((x) => x.id === id)
  if (!d) return
  const missing = d.docs.filter((x) => x.applicable && x.status === 'missing').map((x) => x.label)
  const pending = d.docs.filter((x) => x.applicable && x.status === 'pending').map((x) => x.label)
  d.summary = `Deal ${d.number} · ${d.customer} · ${d.vehicleLabel}. Stage: ${DEAL_COLS.find((c) => c.id === d.stage)?.label}. Waiting ${d.waitingDays} day(s) on: ${d.waitingFor}. Missing: ${missing.join(', ') || 'none'}. Pending: ${pending.join(', ') || 'none'}. Salesperson: ${memberLabel(s, d.salesperson)}. No legal determination made — items need staff review.`
  log(s, 'suggestion', `Manager summary generated for Deal ${d.number}`, true, { screen: 'deals', id })
  ctx.toast('Manager summary generated (demo)', 'ok')
}

export const DEAL_COLS: { id: DealStage; label: string }[] = [
  { id: 'deposit', label: 'Deposit received' },
  { id: 'financing', label: 'Financing pending' },
  { id: 'signature', label: 'Missing buyer signature' },
  { id: 'id', label: 'ID verification pending' },
  { id: 'title', label: 'Title follow-up' },
  { id: 'stips', label: 'Lender stipulations' },
  { id: 'delivery', label: 'Delivery ready' },
]

export const STAGES: { id: Stage; label: string }[] = [
  { id: 'new', label: 'New' },
  { id: 'contacted', label: 'Contacted' },
  { id: 'appointment', label: 'Appointment' },
  { id: 'negotiating', label: 'Negotiating' },
  { id: 'sold', label: 'Sold' },
  { id: 'lost', label: 'Lost' },
]

// ---------------- Public website → staff inbox ----------------
export interface PublicForm {
  kind: LeadKind
  name: string
  phone: string
  email: string
  channel: Lead['channel']
  smsOptIn: boolean
  vehicleId: string | null
  message: string
  slot?: Wall | null
  trade?: Omit<TradeInfo, 'appraisal'>
  budget?: string
}

const KIND_LABEL: Record<LeadKind, string> = { inquiry: 'Question', 'test-drive': 'Test-drive request', 'trade-in': 'Trade-in inquiry', financing: 'Financing info request', contact: 'Contact form', availability: 'Availability check' }
export const kindLabel = (k: LeadKind) => KIND_LABEL[k]

export function publicLead(s: DataState, ctx: Ctx, f: PublicForm) {
  const id = uid(s, 'l')
  const v = s.vehicles.find((x) => x.id === f.vehicleId)
  const lead: Lead = {
    id,
    name: f.name || 'Website visitor',
    phone: f.phone,
    email: f.email,
    source: 'website',
    kind: f.kind,
    vehicleId: f.vehicleId,
    budget: f.budget || null,
    tradeIn: f.trade ? `${f.trade.year} ${f.trade.make} ${f.trade.model}`.trim() : null,
    trade: f.trade ? { ...f.trade, appraisal: 'Awaiting review' } : undefined,
    channel: f.channel,
    assignedTo: roundRobin(s),
    stage: 'new',
    consent: { sms: f.smsOptIn, email: !!f.email, call: !!f.phone, source: f.smsOptIn ? 'Website form — SMS opt-in checkbox (demo)' : 'Website form — no SMS opt-in', at: s.now, stopped: false },
    urgency: f.kind === 'test-drive' || f.kind === 'trade-in' ? 'high' : 'med',
    nextAction: f.kind === 'trade-in' ? 'Appraisal review (staff)' : f.kind === 'test-drive' ? 'Confirm test-drive time' : 'Reply',
    createdAt: s.now,
    messages: [{ id: uid(s, 'm'), from: 'customer', text: `[${KIND_LABEL[f.kind]}] ${f.message || (v ? 'About the ' + vName(v) : '')}`.trim(), at: s.now }],
    automationPaused: false,
    humanTakeover: false,
    missed: false,
    callbackRequested: false,
    autoSentToday: 0,
    draft: null,
  }
  s.leads.unshift(lead)
  if (f.slot) {
    s.appointments.push({ id: uid(s, 'a'), leadId: id, customer: lead.name, vehicleId: f.vehicleId, start: f.slot, duration: 60, salesperson: lead.assignedTo!, notes: 'Requested on the website — staff to confirm.', reminder: f.smsOptIn ? 'queued' : 'none', status: 'hold', kind: f.kind === 'trade-in' ? 'Appraisal' : 'Test drive' })
    lead.stage = 'appointment'
    lead.nextAction = `Confirm ${fmtDay(f.slot)} ${fmtTime(f.slot)} request`
  }
  // AI proposes a factual follow-up for staff approval
  const out = conciergeReply(f.message || `Is the ${vName(v)} available?`, { vehicles: s.vehicles, offHours: isOffHours(s), slots: nextSlots(s.now, s.hours, s.appointments), first: true, vehicleId: f.vehicleId, hours: s.hours, sms: f.channel === 'sms' })
  if (f.kind !== 'trade-in' && f.kind !== 'financing') lead.draft = out.text
  else lead.draft = f.kind === 'trade-in'
    ? `Hi ${lead.name.split(' ')[0]}, thanks for sending your ${lead.tradeIn} details. A team member needs to see the vehicle in person before giving any number — would you like to book a quick appraisal visit? (Superior Auto Mall assistant, AI)`
    : `Hi ${lead.name.split(' ')[0]}, thanks for asking about financing. A team member will explain the options in person — approval and terms depend on the lender's review. Would a call or a visit work better? (Superior Auto Mall assistant, AI)`
  log(s, 'automation', `Website ${KIND_LABEL[f.kind].toLowerCase()} from ${lead.name} → staff inbox, assigned to ${memberLabel(s, lead.assignedTo)}`, true, { screen: 'leads', id })
  log(s, 'suggestion', `AI drafted a factual reply for ${lead.name} — waiting for staff approval`, false, { screen: 'leads', id })
  ctx.toast(`Sent to the staff inbox (demo). ${f.slot ? 'Time held for staff to confirm.' : ''}`, 'ok')
  return id
}

export function setAppraisal(s: DataState, ctx: Ctx, id: string, a: TradeInfo['appraisal']) {
  const l = s.leads.find((x) => x.id === id)
  if (!l?.trade) return
  l.trade.appraisal = a
  log(s, 'change', `Trade-in for ${l.name}: ${a}`, true, { screen: 'leads', id })
  ctx.toast(`Appraisal status: ${a}`, 'ok')
}

// ---------------- Listing management ----------------
export function setListing(s: DataState, ctx: Ctx, id: string, listing: ListingState) {
  const v = s.vehicles.find((x) => x.id === id)
  if (!v) return
  v.listing = listing
  v.updatedAt = s.now
  v.syncState = 'staged'
  s.sync.unshift({ id: uid(s, 'sy'), vehicleId: id, label: 'Listing status', before: '', after: listing, target: 'Dealer Car Search / DMS', at: s.now, state: 'staged' })
  log(s, 'change', `${v.stock} ${listing === 'published' ? 'published to' : 'removed from'} the public website`, true, { screen: 'listings', id })
  ctx.toast(listing === 'published' ? `${v.stock} is now live on the demo website.` : `${v.stock} is hidden from the demo website.`, 'ok')
}

export function setVStatus(s: DataState, ctx: Ctx, id: string, status: VehicleStatus) {
  const v = s.vehicles.find((x) => x.id === id)
  if (!v) return
  const before = v.status
  v.status = status
  if (status === 'sold' && v.dmsStatus === 'sold') v.dmsStatus = undefined
  if (v.dmsStatus && v.dmsStatus === status) v.dmsStatus = undefined
  v.updatedAt = s.now
  v.syncState = 'staged'
  s.sync.unshift({ id: uid(s, 'sy'), vehicleId: id, label: 'Availability', before, after: status, target: 'Dealer Car Search / DMS', at: s.now, state: 'staged' })
  log(s, 'change', `${v.stock} marked ${status}${status === 'sold' ? ' — removed from public inventory' : ''}`, true, { screen: 'listings', id })
  ctx.toast(status === 'sold' ? `${v.stock} marked sold and removed from the public site.` : `${v.stock} marked ${status}.`, 'ok')
}

export function archiveVehicle(s: DataState, ctx: Ctx, id: string, archived: boolean) {
  const v = s.vehicles.find((x) => x.id === id)
  if (!v) return
  v.archived = archived
  v.updatedAt = s.now
  log(s, 'change', `${v.stock} ${archived ? 'archived (reversible — not deleted)' : 'restored from archive'}`, true, { screen: 'listings', id })
  ctx.toast(archived ? `${v.stock} archived. You can restore it anytime.` : `${v.stock} restored.`, 'ok')
}

export function blankVehicle(s: DataState): Vehicle {
  const n = 2417 + s.vehicles.length - 16
  return {
    id: uid(s, 'v'), stock: `D${n}`, year: 2020, make: '', model: '', trim: '', body: 'Sedan', vin: `DEMO0NEW${String(n).padStart(9, '0')}`,
    price: null, mileage: null, photos: [], description: '', features: [], conditionNotes: '', disclosure: 'Warranty / As-Is status: shown on the FTC Buyers Guide on the vehicle — confirm with dealer.',
    titleStatus: 'Not entered', fuel: 'Gasoline', daysOnLot: 0, acquired: s.now.slice(0, 10), cost: 0, prepCost: 0, status: 'available', listing: 'draft',
    color: 'Not entered', colorHex: '#9aa1aa', engine: '', transmission: '', drivetrain: '', assignedTo: 'admin', updatedAt: s.now, syncState: 'never',
  }
}

export function addCar(s: DataState, ctx: Ctx) {
  const v = blankVehicle(s)
  s.vehicles.unshift(v)
  log(s, 'change', `New draft listing ${v.stock} created`, true, { screen: 'listings', id: v.id })
  ctx.toast(`Draft ${v.stock} created — it stays hidden until you publish.`, 'ok')
  return v.id
}

export function duplicateDraft(s: DataState, ctx: Ctx, id: string) {
  const v = s.vehicles.find((x) => x.id === id)
  if (!v) return
  const copy: Vehicle = { ...structuredClone(v), id: uid(s, 'v'), stock: v.stock + '-COPY', vin: 'DEMO0COPY' + String(s.seq).padStart(8, '0'), listing: 'draft', mileage: null, photos: [], examplePhoto: undefined, syncState: 'never', updatedAt: s.now, duplicateOf: undefined, dmsVin: undefined, dmsStatus: undefined, dmsTrim: undefined, archived: false }
  s.vehicles.unshift(copy)
  log(s, 'change', `Draft ${copy.stock} duplicated from ${v.stock} (mileage, VIN & photos cleared on purpose)`, true, { screen: 'listings', id: copy.id })
  ctx.toast('Draft copy created. Mileage, VIN and photos were cleared so they must be entered for the real car.', 'ok')
  return copy.id
}

export function addPhotos(s: DataState, ctx: Ctx, id: string, srcs: (string | undefined)[]) {
  const v = s.vehicles.find((x) => x.id === id)
  if (!v) return
  for (const src of srcs) {
    const shot = PHOTO_SHOTS.find((p) => !v.photos.some((x) => x.shot === p)) ?? 'Extra photo'
    v.photos.push({ id: uid(s, 'p'), shot, src })
  }
  v.updatedAt = s.now
  log(s, 'change', `${srcs.length} photo${srcs.length > 1 ? 's' : ''} added to ${v.stock} (stored only in this browser)`, true, { screen: 'listings', id })
  ctx.toast(`${srcs.length} photo${srcs.length > 1 ? 's' : ''} added (demo — stays in this browser).`, 'ok')
}

export function reorderPhoto(s: DataState, id: string, from: number, to: number) {
  const v = s.vehicles.find((x) => x.id === id)
  if (!v || to < 0 || to >= v.photos.length) return
  const [p] = v.photos.splice(from, 1)
  v.photos.splice(to, 0, p)
  v.updatedAt = s.now
}

export function applyPhotoOrder(s: DataState, ctx: Ctx, id: string) {
  const v = s.vehicles.find((x) => x.id === id)
  if (!v) return
  const rank = (p: Photo) => {
    const i = PHOTO_SHOTS.indexOf(p.shot)
    return i < 0 ? 99 : i
  }
  v.photos.sort((a, b) => rank(a) - rank(b))
  v.updatedAt = s.now
  log(s, 'approval', `Suggested photo order approved for ${v.stock}`, true, { screen: 'listings', id })
  ctx.toast('Photo order updated on the public listing.', 'ok')
}

export function bulkApply(s: DataState, ctx: Ctx, ids: string[], op: 'publish' | 'unpublish' | 'pending' | 'assign-admin' | 'assign-owner') {
  for (const id of ids) {
    const v = s.vehicles.find((x) => x.id === id)
    if (!v) continue
    if (op === 'publish') v.listing = 'published'
    if (op === 'unpublish') v.listing = 'unpublished'
    if (op === 'pending') v.status = 'pending'
    if (op === 'assign-admin') v.assignedTo = 'admin'
    if (op === 'assign-owner') v.assignedTo = 'owner'
    v.updatedAt = s.now
  }
  log(s, 'change', `Bulk edit (${op}) applied to ${ids.length} listing${ids.length > 1 ? 's' : ''}`, true, { screen: 'listings' })
  ctx.toast(`Bulk edit applied to ${ids.length} car${ids.length > 1 ? 's' : ''}.`, 'ok')
}

export const SAMPLE_CSV = `stock,year,make,model,trim,body,mileage,price,color
D2490,2019,Honda,Accord,Sport,Sedan,58200,19990,Platinum White
D2491,2017,Toyota,RAV4,XLE,SUV,88410,,Magnetic Gray
D2492,2020,Ford,Ranger,XLT,Truck,,26500,Oxford White`

export function importCsv(s: DataState, ctx: Ctx, text: string) {
  const lines = text.trim().split(/\r?\n/)
  const head = lines.shift()?.split(',').map((h) => h.trim().toLowerCase()) ?? []
  let n = 0
  for (const ln of lines) {
    const cells = ln.split(',')
    const row: Record<string, string> = {}
    head.forEach((h, i) => (row[h] = (cells[i] ?? '').trim()))
    if (!row.make) continue
    const v = blankVehicle(s)
    Object.assign(v, {
      stock: row.stock || v.stock,
      year: Number(row.year) || v.year,
      make: row.make,
      model: row.model,
      trim: row.trim,
      body: (['Sedan', 'SUV', 'Truck', 'Coupe', 'Hatchback', 'Van'].includes(row.body) ? row.body : 'Sedan') as Vehicle['body'],
      mileage: row.mileage ? Number(row.mileage) : null,
      price: row.price ? Number(row.price) : null,
      color: row.color || 'Not entered',
      colorHex: COLOR_HEX[row.color] ?? '#c9ced5',
    })
    s.vehicles.unshift(v)
    n++
  }
  log(s, 'change', `CSV import: ${n} draft listing${n === 1 ? '' : 's'} created (not published)`, true, { screen: 'listings' })
  ctx.toast(n ? `Imported ${n} draft${n > 1 ? 's' : ''}. Review and publish when ready.` : 'No rows found — check the header row.', n ? 'ok' : 'warn')
}

export function exportCsv(s: DataState) {
  const rows = s.vehicles.filter((v) => !v.archived).map((v) => [v.stock, v.year, v.make, v.model, v.trim, v.body, v.mileage ?? '', v.price ?? '', v.color, v.status, v.listing].join(','))
  return ['stock,year,make,model,trim,body,mileage,price,color,status,listing', ...rows].join('\n')
}

export function resolveSync(s: DataState, ctx: Ctx, id: string, how: 'exported' | 'retry' | 'keep-ours' | 'keep-theirs') {
  const it = s.sync.find((x) => x.id === id)
  if (!it) return
  const v = s.vehicles.find((x) => x.id === it.vehicleId)
  if (how === 'exported') it.state = 'exported'
  if (how === 'retry') it.state = 'staged'
  if (how === 'keep-ours' || how === 'keep-theirs') {
    it.state = 'resolved'
    if (v && it.label === 'VIN') {
      if (how === 'keep-theirs' && v.dmsVin) v.vin = v.dmsVin
      v.dmsVin = undefined
    }
  }
  if (v && !s.sync.some((x) => x.vehicleId === v.id && (x.state === 'conflict' || x.state === 'failed' || x.state === 'staged'))) v.syncState = 'synced'
  log(s, 'approval', `Sync item "${it.label}" for ${v?.stock}: ${how.replace('-', ' ')}`, true, { screen: 'listings', id: it.vehicleId })
  ctx.toast(how === 'exported' ? 'Marked as exported manually (CSV). Nothing was sent automatically.' : how === 'retry' ? 'Re-queued (simulated). No external system was contacted.' : 'Conflict resolved — your choice is logged.', 'demo')
}

export const MOCK_VIN: Record<string, Partial<Vehicle>> = {
  TOY: { make: 'Toyota' }, HON: { make: 'Honda' }, NIS: { make: 'Nissan' }, CHV: { make: 'Chevrolet' }, FRD: { make: 'Ford' },
  HYN: { make: 'Hyundai' }, KIA: { make: 'Kia' }, BMW: { make: 'BMW' }, JEP: { make: 'Jeep' }, MB: { make: 'Mercedes-Benz' }, NEW: { make: 'Toyota', model: 'Corolla', year: 2020, body: 'Sedan', engine: '1.8L I4', transmission: 'CVT', drivetrain: 'FWD' },
}
export function mockDecode(vin: string): Partial<Vehicle> | null {
  const key = Object.keys(MOCK_VIN).find((k) => vin.toUpperCase().startsWith('DEMO0' + k))
  return key ? MOCK_VIN[key] : null
}
