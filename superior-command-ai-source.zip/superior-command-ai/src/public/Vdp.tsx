import { useEffect, useState } from 'react'
import { Bot, Calendar, CheckCircle2, ChevronLeft, ChevronRight, CircleDollarSign, Eye, FileText, Heart, Phone, Repeat, Scale } from 'lucide-react'
import { useStore } from '../store'
import { advertised, isPublic, milesLabel, money, publicVehicles, slugOf, statusLabel } from '../logic'
import { Badge, Btn, CarArt, Field, Input, cx } from '../ui'
import { PriceTag, RequestModal, VehicleCard, useSeo } from './common'

export function Vdp() {
  const { s, ui, go, act, setUi, nav } = useStore()
  const [slug, query] = ui.route.split('/')[2]?.split('?') ?? []
  const preview = new URLSearchParams(query ?? '').get('preview') === '1'
  const v = s.vehicles.find((x) => slugOf(x) === slug)
  const [idx, setIdx] = useState(0)
  const [modal, setModal] = useState<null | 'test-drive' | 'availability' | 'contact'>(null)
  const [calc, setCalc] = useState({ down: 2000, term: 60, apr: 9.9 })
  useEffect(() => setIdx(0), [slug])

  const a = v ? advertised(v, s.dealer) : null
  useSeo(
    v ? `${v.year} ${v.make} ${v.model} ${v.trim} — Stock ${v.stock} | Superior Auto Mall (Demo)` : 'Vehicle not found',
    v ? `${v.year} ${v.make} ${v.model} ${v.trim} in ${v.color}${v.mileage != null ? `, ${v.mileage.toLocaleString()} miles` : ''}. ${a?.amount != null ? money(a.amount) : 'Call for price'}. Stock ${v.stock}, St. Petersburg FL.` : '',
    v ? {
      '@context': 'https://schema.org', '@type': 'Car', name: `${v.year} ${v.make} ${v.model} ${v.trim}`, brand: v.make, model: v.model, vehicleModelDate: String(v.year), color: v.color, bodyType: v.body,
      ...(v.mileage != null ? { mileageFromOdometer: { '@type': 'QuantitativeValue', value: v.mileage, unitCode: 'SMI' } } : {}),
      ...(a?.amount != null && v.status === 'available' ? { offers: { '@type': 'Offer', price: a.amount, priceCurrency: 'USD', availability: 'https://schema.org/InStock' } } : {}),
    } : null,
    v ? `/inventory/${slugOf(v)}` : undefined,
  )

  if (!v || (!isPublic(v) && !preview)) {
    return (
      <div className="mx-auto max-w-3xl px-4 py-16 text-center">
        <h1 className="text-2xl font-black">This vehicle is no longer listed</h1>
        <p className="mt-2 text-ink-500">It may have sold or been taken down. Here are some similar cars.</p>
        <div className="mt-8 grid gap-4 text-left sm:grid-cols-3">{publicVehicles(s).slice(0, 3).map((x) => <VehicleCard key={x.id} v={x} />)}</div>
      </div>
    )
  }

  const photos = v.photos
  const p = photos[idx]
  const similar = publicVehicles(s).filter((x) => x.id !== v.id && (x.body === v.body || Math.abs((x.price ?? 0) - (v.price ?? 0)) < 4000)).slice(0, 3)
  const fav = s.favorites.includes(v.id)
  const principal = Math.max(0, (a?.amount ?? 0) - calc.down)
  const r = calc.apr / 100 / 12
  const pay = principal && r ? (principal * r) / (1 - Math.pow(1 + r, -calc.term)) : principal / calc.term

  const specs: [string, string][] = [
    ['Year', String(v.year)], ['Make', v.make], ['Model', v.model], ['Trim', v.trim || 'Confirm with dealer'], ['Body', v.body],
    ['Mileage', v.mileage == null ? 'Confirm with dealer' : milesLabel(v)], ['Engine', v.engine || 'Confirm with dealer'], ['Transmission', v.transmission || 'Confirm with dealer'],
    ['Drive', v.drivetrain || 'Confirm with dealer'], ['Fuel', v.fuel], ['Fuel economy', v.mpg ?? 'Not listed'], ['Exterior color', v.color], ['Stock #', v.stock], ['VIN (demo)', v.vin],
  ]

  return (
    <div className="mx-auto max-w-6xl px-4 py-6">
      {preview && !isPublic(v) && (
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2 rounded-xl border border-amber-200 bg-amber-50 px-4 py-2 text-sm text-amber-900">
          <span className="flex items-center gap-2"><Eye className="h-4 w-4" /> <b>Staff preview</b> — this listing is <b>{v.archived ? 'archived' : v.status === 'sold' ? 'sold' : v.listing}</b> and is not visible to shoppers.</span>
          <Btn size="xs" variant="dark" onClick={() => nav('listings', v.id)}>Back to editor</Btn>
        </div>
      )}
      <nav className="mb-4 text-[13px] text-ink-500" aria-label="Breadcrumb">
        <button onClick={() => go('/')} className="hover:text-brand-700">Home</button> / <button onClick={() => go('/inventory')} className="hover:text-brand-700">Inventory</button> / <span className="text-ink-800">{v.year} {v.make} {v.model}</span>
      </nav>

      <div className="grid gap-8 lg:grid-cols-[minmax(0,1.45fr)_minmax(0,1fr)]">
        <div>
          <div data-tour="vdp-gallery" className="relative aspect-[16/10] overflow-hidden rounded-2xl bg-silver-100 ring-1 ring-silver-200">
            {p ? <CarArt v={v} shot={p.shot} src={p.src} /> : <div className="grid h-full place-items-center text-sm text-ink-500">No photos yet — confirm with dealer</div>}
            {photos.length > 1 && (
              <>
                <button aria-label="Previous photo" onClick={() => setIdx((idx - 1 + photos.length) % photos.length)} className="absolute left-3 top-1/2 -translate-y-1/2 rounded-full bg-white/90 p-2 shadow hover:bg-white"><ChevronLeft className="h-5 w-5" /></button>
                <button aria-label="Next photo" onClick={() => setIdx((idx + 1) % photos.length)} className="absolute right-3 top-1/2 -translate-y-1/2 rounded-full bg-white/90 p-2 shadow hover:bg-white"><ChevronRight className="h-5 w-5" /></button>
              </>
            )}
            <div className="absolute right-3 top-3 rounded-md bg-ink-900/75 px-2 py-0.5 text-xs font-semibold text-white">{photos.length ? idx + 1 : 0} / {photos.length}</div>
          </div>
          <div className="scroll-thin mt-3 flex gap-2 overflow-x-auto pb-1">
            {photos.map((ph, i) => (
              <button key={ph.id} onClick={() => setIdx(i)} className={cx('h-14 w-20 shrink-0 overflow-hidden rounded-lg ring-2', i === idx ? 'ring-brand-600' : 'ring-transparent opacity-80 hover:opacity-100')} aria-label={`Photo ${i + 1}: ${ph.shot}`}>
                <CarArt v={v} shot={ph.shot} src={ph.src} label={false} />
              </button>
            ))}
            {Array.from({ length: Math.max(0, 15 - photos.length) }).map((_, i) => (
              <div key={i} className="grid h-14 w-20 shrink-0 place-items-center rounded-lg border border-dashed border-silver-300 text-[9px] text-ink-400">Photo slot</div>
            ))}
          </div>
          <p className="mt-1 text-[11px] text-ink-400">Photo 1 is a real <b>example photo</b> of a similar car (Unsplash, free license) — not this exact vehicle. The other slots are labeled placeholders. In production, every photo must show the actual car for sale, including any visible wear.</p>

          <section className="mt-8">
            <h2 className="mb-3 text-lg font-bold">Vehicle details</h2>
            <dl className="grid grid-cols-1 overflow-hidden rounded-xl border border-silver-200 sm:grid-cols-2">
              {specs.map(([k, val], i) => (
                <div key={k} className={cx('flex justify-between gap-4 px-4 py-2.5 text-sm', i % 4 < 2 ? 'bg-silver-50' : 'bg-white')}>
                  <dt className="text-ink-500">{k}</dt>
                  <dd className={cx('text-right font-semibold', val.startsWith('Confirm') && 'font-normal italic text-amber-700')}>{val}</dd>
                </div>
              ))}
            </dl>
          </section>

          <section className="mt-8 grid gap-6 md:grid-cols-2">
            <div>
              <h2 className="mb-2 text-lg font-bold">Features listed by the dealer</h2>
              {v.features.length ? (
                <ul className="space-y-1.5 text-sm">{v.features.map((x) => <li key={x} className="flex gap-2"><CheckCircle2 className="h-4 w-4 shrink-0 text-emerald-600" />{x[0].toUpperCase() + x.slice(1)}</li>)}</ul>
              ) : <p className="text-sm italic text-ink-500">No features entered yet — confirm with dealer.</p>}
            </div>
            <div>
              <h2 className="mb-2 text-lg font-bold">From the dealer</h2>
              <p className="text-sm leading-relaxed text-ink-700">{v.description || 'Description coming soon.'}</p>
              {v.conditionNotes && <p className="mt-2 rounded-lg bg-silver-50 px-3 py-2 text-sm text-ink-700">{v.conditionNotes}</p>}
            </div>
          </section>

          <section className="mt-8 rounded-2xl border border-silver-200 p-5">
            <h2 className="mb-2 flex items-center gap-2 text-lg font-bold"><FileText className="h-5 w-5 text-brand-600" /> Disclosures</h2>
            <ul className="space-y-1.5 text-sm text-ink-700">
              <li>{v.disclosure}</li>
              <li>Vehicle history report: not linked in this demo — ask the dealer if one is available.</li>
              <li>Title: {v.titleStatus}.</li>
              <li>Independent inspections are welcome — ask us to arrange a time.</li>
            </ul>
          </section>
        </div>

        <aside className="lg:sticky lg:top-20 lg:self-start">
          <div className="rounded-2xl border border-silver-200 bg-white p-5 shadow-sm">
            <div className="flex items-start justify-between">
              <Badge tone={v.status === 'available' ? 'green' : v.status === 'pending' ? 'amber' : 'gray'}>{statusLabel(v)}</Badge>
              <button onClick={() => act((st) => (st.favorites = fav ? st.favorites.filter((x) => x !== v.id) : [...st.favorites, v.id]))} aria-label="Save vehicle" className={cx('rounded-full p-1.5', fav ? 'text-brand-600' : 'text-silver-400 hover:text-brand-600')}><Heart className={cx('h-5 w-5', fav && 'fill-current')} /></button>
            </div>
            <h1 data-tour="vdp-title" className="mt-2 text-2xl font-black leading-tight tracking-tight">{v.year} {v.make} {v.model}</h1>
            <div className="text-ink-500">{v.trim} · {v.color}</div>
            <div data-tour="vdp-price" className="mt-4 border-y border-silver-100 py-4"><PriceTag v={v} size="lg" /></div>
            <div className="mt-3 grid grid-cols-2 gap-2 text-sm">
              <div className="rounded-lg bg-silver-50 p-2"><div className="text-[11px] text-ink-500">Mileage</div><div data-tour="vdp-miles" className={cx('font-bold', v.mileage == null && 'font-normal italic text-amber-700')}>{v.mileage == null ? 'Confirm with dealer' : milesLabel(v)}</div></div>
              <div className="rounded-lg bg-silver-50 p-2"><div className="text-[11px] text-ink-500">Stock #</div><div className="font-bold">{v.stock}</div></div>
            </div>
            <div className="mt-4 space-y-2">
              <Btn data-tour="vdp-testdrive" variant="primary" className="w-full" size="lg" icon={<Calendar className="h-5 w-5" />} onClick={() => setModal('test-drive')}>Schedule Test Drive</Btn>
              <Btn className="w-full" onClick={() => setModal('availability')}>Request Availability Confirmation</Btn>
              <Btn data-tour="vdp-ask" variant="dark" className="w-full" icon={<Bot className="h-4 w-4" />} onClick={() => setUi({ chatOpen: true })}>Ask AI About This Car</Btn>
              <div className="grid grid-cols-2 gap-2">
                <a href={`tel:${s.dealer.phone}`} className="inline-flex h-10 items-center justify-center gap-1.5 rounded-lg border border-silver-300 text-sm font-semibold hover:bg-silver-50"><Phone className="h-4 w-4" /> Call</a>
                <Btn icon={<Scale className="h-4 w-4" />} onClick={() => act((st, c) => {
                  if (st.compare.includes(v.id)) return
                  if (st.compare.length >= 3) c.toast('You can compare up to 3 cars.', 'warn')
                  else { st.compare.push(v.id); c.toast('Added to compare.', 'ok') }
                })}>Compare</Btn>
              </div>
            </div>
            <div className="mt-4 grid grid-cols-2 gap-2 text-[13px]">
              <button onClick={() => go('/trade-in')} className="flex items-center gap-1.5 rounded-lg bg-silver-50 p-2 font-semibold hover:bg-silver-100"><Repeat className="h-4 w-4 text-brand-600" /> Have a trade-in?</button>
              <button onClick={() => go('/financing')} className="flex items-center gap-1.5 rounded-lg bg-silver-50 p-2 font-semibold hover:bg-silver-100"><CircleDollarSign className="h-4 w-4 text-brand-600" /> Financing info</button>
            </div>
          </div>

          <div className="mt-4 rounded-2xl border border-silver-200 bg-white p-5">
            <h2 className="font-bold">Payment math (illustration only)</h2>
            <p className="mb-3 text-[12px] text-ink-500">This is simple arithmetic, not a loan offer or approval. Real rates and terms depend on a lender's review.</p>
            {a?.amount == null ? <p className="text-sm italic text-ink-500">Price not posted yet — ask the dealer.</p> : (
              <>
                <div className="grid grid-cols-3 gap-2">
                  <Field label="Down ($)"><Input type="number" min={0} value={calc.down} onChange={(e) => setCalc({ ...calc, down: Number(e.target.value) })} /></Field>
                  <Field label="Months"><Input type="number" min={12} max={84} value={calc.term} onChange={(e) => setCalc({ ...calc, term: Math.max(1, Number(e.target.value)) })} /></Field>
                  <Field label="Rate %"><Input type="number" step="0.1" min={0} value={calc.apr} onChange={(e) => setCalc({ ...calc, apr: Number(e.target.value) })} /></Field>
                </div>
                <div className="mt-3 rounded-lg bg-silver-50 p-3 text-center">
                  <div className="text-[11px] text-ink-500">Example monthly amount (before tax, tag & title)</div>
                  <div className="text-2xl font-black">{money(pay)}<span className="text-sm font-semibold text-ink-500">/mo</span></div>
                </div>
              </>
            )}
          </div>
        </aside>
      </div>

      {similar.length > 0 && (
        <section className="mt-12">
          <h2 className="mb-4 text-xl font-bold">Similar cars</h2>
          <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">{similar.map((x) => <VehicleCard key={x.id} v={x} />)}</div>
        </section>
      )}

      <RequestModal open={modal !== null} onClose={() => setModal(null)} kind={modal ?? 'test-drive'} vehicle={v} defaultMessage={modal === 'availability' ? `Is the ${v.year} ${v.make} ${v.model} (${v.stock}) still available?` : ''} />
    </div>
  )
}
