import React, { useState } from 'react'
import { CheckCircle2, Clock, Handshake, MapPin, Phone, ShieldCheck, Users } from 'lucide-react'
import { useStore } from '../store'
import { publicLead } from '../actions'
import { hoursText } from '../logic'
import { Btn, Field, Input, Select, Textarea, cx } from '../ui'
import { SectionTitle, useSeo } from './common'
import { FAQS } from './Home'

const Shell = ({ children, narrow }: { children: React.ReactNode; narrow?: boolean }) => <div className={cx('mx-auto px-4 py-10', narrow ? 'max-w-3xl' : 'max-w-6xl')}>{children}</div>

function Success({ text, id }: { text: string; id: string }) {
  const { nav, go } = useStore()
  return (
    <div className="rise rounded-2xl border border-silver-200 p-8 text-center">
      <CheckCircle2 className="mx-auto h-12 w-12 text-emerald-600" />
      <h2 className="mt-3 text-xl font-bold">Thanks — we got it!</h2>
      <p className="mt-1 text-ink-500">{text}</p>
      <div className="mx-auto mt-4 max-w-md rounded-xl border border-dashed border-silver-400 bg-silver-50 p-3 text-left text-[13px] text-ink-700">
        <b>DEMO:</b> nothing went to a real dealership. This just created a new entry in the demo <b>staff inbox</b>.
      </div>
      <div className="mt-4 flex justify-center gap-2">
        <Btn onClick={() => go('/inventory')}>Keep browsing</Btn>
        <Btn variant="dark" onClick={() => nav('leads', id)}>See it in the Staff Portal →</Btn>
      </div>
    </div>
  )
}

function ContactBits({ f, setF }: { f: { name: string; phone: string; email: string; channel: string; sms: boolean }; setF: (x: typeof f) => void }) {
  return (
    <>
      <div className="grid gap-3 sm:grid-cols-2">
        <Field label="Your name"><Input required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></Field>
        <Field label="Best way to reach you">
          <Select value={f.channel} onChange={(e) => setF({ ...f, channel: e.target.value })}>
            <option value="sms">Text message</option><option value="email">Email</option><option value="phone">Phone call</option>
          </Select>
        </Field>
        <Field label="Phone"><Input value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} inputMode="tel" /></Field>
        <Field label="Email"><Input type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></Field>
      </div>
      <label className="flex items-start gap-2 text-[12px] text-ink-500">
        <input type="checkbox" className="mt-0.5 accent-brand-600" checked={f.sms} onChange={(e) => setF({ ...f, sms: e.target.checked })} />
        You may text me about this request. Reply STOP to opt out. Consent isn't required to buy. (Demo — no texts are sent.)
      </label>
    </>
  )
}

const blank = { name: '', phone: '', email: '', channel: 'sms', sms: false }

export function TradeIn() {
  const { act } = useStore()
  useSeo('Sell or Trade Your Car | Superior Auto Mall (Concept Demo)', 'Tell us about your car in three quick steps. We review every vehicle in person — no automated valuations.', null, '/trade-in')
  const [step, setStep] = useState(1)
  const [car, setCar] = useState({ year: '', make: '', model: '', mileage: '', condition: 'Good — normal wear' })
  const [notes, setNotes] = useState('')
  const [f, setF] = useState(blank)
  const [done, setDone] = useState<string | null>(null)
  const submit = () => {
    let id = ''
    act((s, c) => {
      id = publicLead(s, c, { kind: 'trade-in', name: f.name, phone: f.phone, email: f.email, channel: f.channel as 'sms', smsOptIn: f.sms, vehicleId: null, message: `Trade-in: ${car.year} ${car.make} ${car.model}, ${car.mileage} miles, ${car.condition}. ${notes}`, trade: car })
    })
    setDone(id)
  }
  return (
    <Shell narrow>
      <SectionTitle kicker="Sell / Trade" title="Tell us about your car" sub="Three quick steps. We'll look at your car in person before giving any number — this form does not produce a valuation." />
      {done ? <Success id={done} text="A team member will reach out to set up a quick in-person look at your car." /> : (
        <div className="rounded-2xl border border-silver-200 p-6">
          <ol className="mb-6 flex gap-2">
            {['Your car', 'Miles & condition', 'How to reach you'].map((t, i) => (
              <li key={t} className={cx('flex-1 rounded-lg px-3 py-2 text-center text-[12px] font-bold', step === i + 1 ? 'bg-brand-600 text-white' : step > i + 1 ? 'bg-emerald-50 text-emerald-700' : 'bg-silver-100 text-ink-500')}>
                {i + 1}. {t}
              </li>
            ))}
          </ol>
          {step === 1 && (
            <div className="grid gap-3 sm:grid-cols-3">
              <Field label="Year"><Input value={car.year} onChange={(e) => setCar({ ...car, year: e.target.value })} placeholder="2015" inputMode="numeric" /></Field>
              <Field label="Make"><Input value={car.make} onChange={(e) => setCar({ ...car, make: e.target.value })} placeholder="Honda" /></Field>
              <Field label="Model"><Input value={car.model} onChange={(e) => setCar({ ...car, model: e.target.value })} placeholder="Civic" /></Field>
            </div>
          )}
          {step === 2 && (
            <div className="grid gap-3 sm:grid-cols-2">
              <Field label="Approximate miles"><Input value={car.mileage} onChange={(e) => setCar({ ...car, mileage: e.target.value })} placeholder="98,000" /></Field>
              <Field label="Overall condition (your view)">
                <Select value={car.condition} onChange={(e) => setCar({ ...car, condition: e.target.value })}>
                  {['Excellent — like new', 'Good — normal wear', 'Fair — some issues', 'Needs work'].map((c) => <option key={c}>{c}</option>)}
                </Select>
              </Field>
              <Field label="Anything we should know? (optional)" className="sm:col-span-2"><Textarea value={notes} onChange={(e) => setNotes(e.target.value)} placeholder="Warning lights, accidents you know about, still making payments, etc." /></Field>
              <p className="text-[12px] text-ink-500 sm:col-span-2">Photos are optional and not needed for this demo.</p>
            </div>
          )}
          {step === 3 && <div className="space-y-3"><ContactBits f={f} setF={setF} /></div>}
          <div className="mt-6 flex justify-between">
            <Btn variant="ghost" disabled={step === 1} onClick={() => setStep(step - 1)}>Back</Btn>
            {step < 3 ? (
              <Btn variant="primary" disabled={step === 1 ? !car.make || !car.model : false} onClick={() => setStep(step + 1)}>Next</Btn>
            ) : (
              <Btn variant="primary" disabled={!f.name || (!f.phone && !f.email)} onClick={submit}>Send trade-in details</Btn>
            )}
          </div>
        </div>
      )}
    </Shell>
  )
}

export function Financing() {
  const { act } = useStore()
  useSeo('Car Financing Information | Superior Auto Mall (Concept Demo)', 'Plain-language explanation of used-car financing. Approval and terms depend on lender review.', null, '/financing')
  const [f, setF] = useState(blank)
  const [extra, setExtra] = useState({ budget: '', note: '' })
  const [done, setDone] = useState<string | null>(null)
  return (
    <Shell>
      <div className="grid gap-10 lg:grid-cols-2">
        <div>
          <SectionTitle kicker="Financing" title="Financing, explained simply" sub="Most people finance a used car through a bank, credit union, or a lender the dealer works with. Here's how it usually goes." />
          <ol className="space-y-4">
            {[
              ['Pick a car and a budget', 'Think about the total price and a monthly amount you’re comfortable with.'],
              ['Apply through a secure lender process', 'When you’re ready, the dealer helps you apply through a secure lender or finance system. This website never asks for your Social Security number or bank details.'],
              ['The lender reviews it', 'The lender decides whether to approve and sets the rate and term. Nobody can promise approval ahead of time.'],
              ['Review the paperwork', 'Before signing, you’ll see the full price, rate, term and any fees in writing. Ask about anything that isn’t clear.'],
            ].map(([t, d], i) => (
              <li key={t} className="flex gap-4">
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-brand-600 text-sm font-bold text-white">{i + 1}</span>
                <div><div className="font-bold">{t}</div><p className="text-sm text-ink-500">{d}</p></div>
              </li>
            ))}
          </ol>
          <div className="mt-6 flex gap-3 rounded-xl bg-silver-50 p-4 text-sm text-ink-700">
            <ShieldCheck className="h-5 w-5 shrink-0 text-emerald-600" />
            We never ask for sensitive information like your SSN, date of birth, driver's license or bank account through this form.
          </div>
        </div>
        <div>
          {done ? <Success id={done} text="A team member will reach out to explain your options." /> : (
            <form onSubmit={(e) => { e.preventDefault(); let id = ''; act((s, c) => { id = publicLead(s, c, { kind: 'financing', name: f.name, phone: f.phone, email: f.email, channel: f.channel as 'sms', smsOptIn: f.sms, vehicleId: null, message: `Financing info request. ${extra.note}`, budget: extra.budget }) }); setDone(id) }} className="space-y-3 rounded-2xl border border-silver-200 p-6">
              <h2 className="text-lg font-bold">Request financing information</h2>
              <p className="text-[13px] text-ink-500">Basic contact details only — this is not a credit application.</p>
              <ContactBits f={f} setF={setF} />
              <Field label="Rough monthly budget (optional)"><Input value={extra.budget} onChange={(e) => setExtra({ ...extra, budget: e.target.value })} placeholder="e.g. around $300/month" /></Field>
              <Field label="Questions (optional)"><Textarea value={extra.note} onChange={(e) => setExtra({ ...extra, note: e.target.value })} /></Field>
              <Btn type="submit" variant="primary" className="w-full" disabled={!f.name || (!f.phone && !f.email)}>Request information</Btn>
            </form>
          )}
        </div>
      </div>
    </Shell>
  )
}

export function About() {
  useSeo('About Us | Superior Auto Mall (Concept Demo)', 'An independent used-car dealership in St. Petersburg, Florida.', null, '/about')
  return (
    <Shell>
      <SectionTitle kicker="About" title="A local, independent dealership" sub="This page is a placeholder for the owner's own story — we haven't invented any history, awards or credentials." />
      <div className="grid gap-6 md:grid-cols-3">
        {[
          [Handshake, 'Straight answers', 'If we don’t know something about a car yet, we’ll tell you and find out.'],
          [Clock, 'Easy to reach', 'Call, text, email, or use the website. After hours, you’ll get an answer and a time to talk.'],
          [ShieldCheck, 'Clear paperwork', 'Pricing, fees and disclosures in writing before you sign.'],
        ].map(([I, t, d]) => {
          const Icon = I as typeof Clock
          return (
            <div key={t as string} className="rounded-2xl border border-silver-200 p-6">
              <Icon className="h-7 w-7 text-brand-600" />
              <div className="mt-3 text-lg font-bold">{t as string}</div>
              <p className="mt-1 text-sm text-ink-500">{d as string}</p>
            </div>
          )
        })}
      </div>
      <div className="mt-10 rounded-2xl border border-dashed border-silver-400 p-8">
        <div className="mb-4 flex items-center gap-2 font-bold"><Users className="h-5 w-5 text-brand-600" /> Meet the team</div>
        <div className="grid gap-4 sm:grid-cols-4">
          {['Owner', 'Sales', 'Sales', 'Office & Title'].map((r, i) => (
            <div key={i} className="rounded-xl bg-silver-50 p-4 text-center">
              <div className="mx-auto mb-2 h-16 w-16 rounded-full bg-silver-200" />
              <div className="text-sm font-semibold">{r}</div>
              <div className="text-[11px] text-ink-500">Name & photo with owner approval</div>
            </div>
          ))}
        </div>
      </div>
    </Shell>
  )
}

export function Contact() {
  const { s, act } = useStore()
  useSeo('Contact Us | Superior Auto Mall (Concept Demo)', `Call ${s.dealer.phone} or send a message. Hours: Mon–Fri 10–5, Sat 10–4.`, null, '/contact')
  const [f, setF] = useState(blank)
  const [msg, setMsg] = useState('')
  const [done, setDone] = useState<string | null>(null)
  return (
    <Shell>
      <SectionTitle kicker="Contact" title="Talk to a real person" sub="Call, text or send a message. Prefer the phone? Tap the number." />
      <div className="grid gap-8 lg:grid-cols-2">
        <div className="space-y-4">
          <a href={`tel:${s.dealer.phone}`} className="flex items-center gap-3 rounded-2xl bg-brand-600 p-5 text-white shadow-lg shadow-brand-600/20">
            <Phone className="h-7 w-7" />
            <div><div className="text-sm text-white/80">Tap to call</div><div className="text-2xl font-black">{s.dealer.phone}</div></div>
          </a>
          <div className="rounded-2xl border border-silver-200 p-5 text-sm">
            <div className="flex gap-3"><MapPin className="h-5 w-5 text-brand-600" /><div><b>{s.dealer.street}, {s.dealer.city} {s.dealer.zip}</b><div className="text-xs text-ink-500">Demo address from the current website footer. Public records disagree, so the owner must confirm it (editable in Staff → Settings).</div></div></div>
            <div className="mt-3 flex gap-3"><Clock className="h-5 w-5 text-brand-600" /><div>{hoursText(s.hours)} (Eastern)</div></div>
            <a className="mt-3 inline-block font-semibold text-brand-700 underline" target="_blank" rel="noreferrer" href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${s.dealer.street} ${s.dealer.city}`)}`}>Get directions ↗</a>
          </div>
        </div>
        {done ? <Success id={done} text="A team member will get back to you." /> : (
          <form onSubmit={(e) => { e.preventDefault(); let id = ''; act((st, c) => { id = publicLead(st, c, { kind: 'contact', name: f.name, phone: f.phone, email: f.email, channel: f.channel as 'sms', smsOptIn: f.sms, vehicleId: null, message: msg }) }); setDone(id) }} className="space-y-3 rounded-2xl border border-silver-200 p-6">
            <ContactBits f={f} setF={setF} />
            <Field label="Message"><Textarea required value={msg} onChange={(e) => setMsg(e.target.value)} /></Field>
            <Btn type="submit" variant="primary" className="w-full" disabled={!f.name || (!f.phone && !f.email) || !msg}>Send message</Btn>
          </form>
        )}
      </div>
    </Shell>
  )
}

export function Faq() {
  useSeo('FAQ | Superior Auto Mall (Concept Demo)', 'Answers about pricing, financing, trade-ins and inspections.', null, '/faq')
  return (
    <Shell narrow>
      <SectionTitle kicker="FAQ" title="Frequently asked questions" />
      <div className="divide-y divide-silver-200 rounded-2xl border border-silver-200">
        {FAQS.map(([q, a]) => (
          <details key={q} className="group px-5 py-4" open>
            <summary className="cursor-pointer list-none font-semibold">{q}</summary>
            <p className="mt-2 text-sm leading-relaxed text-ink-500">{a}</p>
          </details>
        ))}
      </div>
      <p className="mt-6 text-sm text-ink-500">Reviews: we only show reviews from a verified, licensed source — none are connected in this demo. Happy or not, customers will be able to leave a review through a public link.</p>
    </Shell>
  )
}

export function Privacy() {
  useSeo('Privacy | Superior Auto Mall (Concept Demo)', 'How this demo handles information.', null, '/privacy')
  return (
    <Shell narrow>
      <SectionTitle title="Privacy (demo)" />
      <div className="space-y-3 text-sm leading-relaxed text-ink-700">
        <p>This is a concept demo. Anything you type stays in your own browser's storage and is never sent anywhere.</p>
        <p>A real version would need a reviewed privacy policy covering what's collected, why, how long it's kept, who it's shared with, and how to request deletion — plus FTC Safeguards Rule compliance where it applies.</p>
        <p>This website never asks for Social Security numbers, driver's licenses, dates of birth, bank details or credit applications.</p>
      </div>
    </Shell>
  )
}

export function Accessibility() {
  useSeo('Accessibility | Superior Auto Mall (Concept Demo)', 'Accessibility commitment.', null, '/accessibility')
  return (
    <Shell narrow>
      <SectionTitle title="Accessibility" />
      <div className="space-y-3 text-sm leading-relaxed text-ink-700">
        <p>We aim for a site everyone can use: readable text, keyboard navigation, labeled buttons and form fields, and descriptive image text.</p>
        <p>If anything is hard to use, please call us at the number above and we'll help directly.</p>
      </div>
    </Shell>
  )
}
