import { useMemo, useState } from 'react'
import { ArrowRight, Car, CircleDollarSign, Clock, MapPin, MessageSquare, Phone, Repeat, Search } from 'lucide-react'
import { useStore } from '../store'
import { hoursText, publicVehicles } from '../logic'
import { Btn, CarArt, ExamplePhoto, Select } from '../ui'
import { HERO_PHOTO } from '../data'
import { SectionTitle, VehicleCard, useSeo } from './common'

export const FAQS = [
  ['Is the price on the website the price I pay?', 'Listed prices are set by the dealer. Government tax, tag and title are extra. Any dealer-required fees should be included or clearly shown — ask us for an itemized total before you visit.'],
  ['Can I get financing?', 'We can explain the options. Approval and terms depend on a lender’s review, so we can’t promise approval or a specific payment ahead of time.'],
  ['Do you take trade-ins?', 'Yes. Send us your car’s details and we’ll set up a time to look at it. We give a number only after seeing the vehicle in person.'],
  ['Can I have my own mechanic inspect a car?', 'Ask us — we’ll work out a time. The FTC Buyers Guide on each car shows whether it’s sold as-is or with a warranty.'],
  ['Why do some cars say “confirm with dealer”?', 'It means that detail hasn’t been verified in our records yet. We’d rather tell you that than guess.'],
]

export function Home({ onTestDrive }: { onTestDrive: () => void }) {
  const { s, go } = useStore()
  const cars = publicVehicles(s)
  const makes = useMemo(() => [...new Set(cars.map((v) => v.make))].sort(), [cars])
  const [q, setQ] = useState({ make: '', model: '', price: '', body: '', year: '' })
  const models = [...new Set(cars.filter((v) => !q.make || v.make === q.make).map((v) => v.model))].sort()
  const hero = cars.find((v) => v.id === 'v04') ?? cars[0]
  useSeo(
    'Used Cars in St. Petersburg, FL | Superior Auto Mall (Concept Demo)',
    'Browse used cars, trucks and SUVs at an independent St. Petersburg dealership. Schedule a test drive, ask questions, or start a trade-in. Unofficial concept demo.',
    { '@context': 'https://schema.org', '@type': 'AutoDealer', name: `${s.dealer.name} (concept demo)`, telephone: s.dealer.phone, address: { '@type': 'PostalAddress', streetAddress: s.dealer.street, addressLocality: 'St. Petersburg', addressRegion: 'FL', ...(s.dealer.zip ? { postalCode: s.dealer.zip } : {}) }, openingHours: ['Mo-Fr 10:00-17:00', 'Sa 10:00-16:00'] },
    '/',
  )
  const search = () => {
    const p = new URLSearchParams(Object.entries(q).filter(([, v]) => v))
    go(`/inventory${p.toString() ? '?' + p : ''}`)
  }
  return (
    <>
      <section className="relative overflow-hidden bg-white">
        <div className="absolute inset-y-0 right-0 hidden w-[58%] metal md:block" style={{ clipPath: 'polygon(14% 0, 100% 0, 100% 100%, 0 100%)' }} />
        <div className="absolute right-0 top-0 hidden h-full w-[58%] md:block" style={{ clipPath: 'polygon(14% 0, 17% 0, 3% 100%, 0 100%)', background: '#c8102e' }} />
        <div className="relative mx-auto grid max-w-6xl items-center gap-8 px-4 pb-10 pt-10 md:grid-cols-2 md:pb-16 md:pt-16">
          <div>
            <div className="mb-3 inline-flex items-center gap-2 rounded-full bg-brand-50 px-3 py-1 text-xs font-bold text-brand-700">
              <MapPin className="h-3.5 w-3.5" /> Independent dealer · St. Petersburg, FL
            </div>
            <h1 className="text-4xl font-black leading-[1.05] tracking-tight text-ink-900 md:text-[56px]">
              Find Your Next Ride <span className="text-brand-600">in St. Petersburg</span>
            </h1>
            <p className="mt-4 max-w-md text-lg leading-relaxed text-ink-500">
              Clear listings, straight answers, and a small local team that's easy to reach. Browse online, ask anything, then come see the car.
            </p>
            <div className="mt-6 flex flex-wrap gap-3">
              <Btn data-tour="shop-cars" size="lg" variant="primary" onClick={() => go('/inventory')} icon={<Car className="h-5 w-5" />}>Shop Cars</Btn>
              <Btn size="lg" onClick={onTestDrive}>Schedule a Test Drive</Btn>
            </div>
          </div>
          <div className="relative">
            {hero && (
              <button onClick={() => go('/inventory')} className="block w-full overflow-hidden rounded-3xl shadow-2xl shadow-ink-900/15 ring-1 ring-silver-200">
                <div className="aspect-[16/10]"><ExamplePhoto id={HERO_PHOTO.id} by={HERO_PHOTO.by} alt="used-car lot" w={1600} caption={`Stock photo · Photo: ${HERO_PHOTO.by} / Unsplash`} fallback={<CarArt v={{ ...hero, examplePhoto: undefined }} shot="Front 3/4 (driver side)" />} /></div>
              </button>
            )}
            <div className="absolute -bottom-4 left-4 rounded-xl bg-white px-4 py-2 text-sm shadow-lg ring-1 ring-silver-200">
              <b className="text-brand-600">{cars.length}</b> cars in the demo inventory
            </div>
          </div>
        </div>
      </section>

      <section className="relative z-10 mx-auto -mt-2 max-w-6xl px-4" aria-label="Search inventory">
        <div className="rounded-2xl border border-silver-200 bg-white p-4 shadow-xl shadow-ink-900/5 md:p-5">
          <div className="grid gap-3 sm:grid-cols-2 md:grid-cols-6">
            <Select aria-label="Make" value={q.make} onChange={(e) => setQ({ ...q, make: e.target.value, model: '' })}>
              <option value="">Any make</option>
              {makes.map((m) => <option key={m}>{m}</option>)}
            </Select>
            <Select aria-label="Model" value={q.model} onChange={(e) => setQ({ ...q, model: e.target.value })}>
              <option value="">Any model</option>
              {models.map((m) => <option key={m}>{m}</option>)}
            </Select>
            <Select aria-label="Price" value={q.price} onChange={(e) => setQ({ ...q, price: e.target.value })}>
              <option value="">Any price</option>
              <option value="12000">Under $12k</option>
              <option value="16000">Under $16k</option>
              <option value="20000">Under $20k</option>
              <option value="30000">Under $30k</option>
            </Select>
            <Select aria-label="Body type" value={q.body} onChange={(e) => setQ({ ...q, body: e.target.value })}>
              <option value="">Any body type</option>
              {['Sedan', 'SUV', 'Truck', 'Hatchback'].map((b) => <option key={b}>{b}</option>)}
            </Select>
            <Select aria-label="Year" value={q.year} onChange={(e) => setQ({ ...q, year: e.target.value })}>
              <option value="">Any year</option>
              <option value="2015">2015 & newer</option>
              <option value="2018">2018 & newer</option>
              <option value="2020">2020 & newer</option>
            </Select>
            <Btn variant="primary" onClick={search} icon={<Search className="h-4 w-4" />}>Search</Btn>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pt-14">
        <div className="flex items-end justify-between">
          <SectionTitle kicker="Featured" title="Recently listed" sub="Sample vehicles from the demo inventory. Every detail comes from the dealer's own records." />
          <Btn variant="ghost" className="hidden sm:inline-flex" onClick={() => go('/inventory')}>See all cars <ArrowRight className="h-4 w-4" /></Btn>
        </div>
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {[...cars].sort((a, b) => a.daysOnLot - b.daysOnLot).slice(0, 6).map((v) => <VehicleCard key={v.id} v={v} />)}
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-4 pt-16">
        <SectionTitle kicker="How it works" title="Simple, no-pressure car shopping" />
        <div className="grid gap-4 md:grid-cols-3">
          {[
            [Search, 'Browse', 'See photos, miles, price and stock number for each car. If something isn’t confirmed yet, we say so.'],
            [MessageSquare, 'Ask questions', 'Text, call, email, or ask our AI assistant — it only answers from our listing info and hands you to a person anytime.'],
            [Car, 'Visit & drive', 'Pick a test-drive time that works for you. We’ll have the car ready.'],
          ].map(([Icon, t, d], i) => {
            const I = Icon as typeof Search
            return (
              <div key={i} className="rounded-2xl border border-silver-200 bg-white p-6">
                <div className="mb-4 flex items-center gap-3">
                  <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand-600 text-white"><I className="h-5 w-5" /></span>
                  <span className="text-sm font-bold text-silver-400">STEP {i + 1}</span>
                </div>
                <div className="text-lg font-bold">{t as string}</div>
                <p className="mt-1 text-sm leading-relaxed text-ink-500">{d as string}</p>
              </div>
            )
          })}
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-4 px-4 pt-12 md:grid-cols-2">
        <div className="flex flex-col justify-between rounded-2xl bg-ink-900 p-7 text-white">
          <div>
            <Repeat className="h-7 w-7 text-brand-500" />
            <h3 className="mt-3 text-xl font-bold">Thinking about trading in?</h3>
            <p className="mt-1 text-sm text-silver-300">Tell us about your car in three quick steps. We'll look at it in person before giving any number.</p>
          </div>
          <Btn variant="white" className="mt-5 self-start" onClick={() => go('/trade-in')}>Start a trade-in</Btn>
        </div>
        <div className="flex flex-col justify-between rounded-2xl border border-silver-200 metal p-7">
          <div>
            <CircleDollarSign className="h-7 w-7 text-brand-600" />
            <h3 className="mt-3 text-xl font-bold">Financing options, explained simply</h3>
            <p className="mt-1 text-sm text-ink-500">Learn how financing works and ask for information. Approval always depends on a lender's review.</p>
          </div>
          <Btn className="mt-5 self-start" onClick={() => go('/financing')}>Learn about financing</Btn>
        </div>
      </section>

      <section className="mx-auto grid max-w-6xl gap-8 px-4 pt-16 md:grid-cols-2">
        <div>
          <SectionTitle kicker="Visit us" title="Come see the car" />
          <div className="space-y-3 text-sm">
            <div className="flex gap-3"><MapPin className="h-5 w-5 text-brand-600" /><div><b>{s.dealer.street}, {s.dealer.city} {s.dealer.zip}</b><div className="text-xs text-ink-500">Demo address — to be confirmed with the owner</div></div></div>
            <div className="flex gap-3"><Clock className="h-5 w-5 text-brand-600" /><div>{hoursText(s.hours)}</div></div>
            <div className="flex gap-3"><Phone className="h-5 w-5 text-brand-600" /><a className="font-bold" href={`tel:${s.dealer.phone}`}>{s.dealer.phone}</a></div>
            <a className="inline-block font-semibold text-brand-700 underline" target="_blank" rel="noreferrer" href={`https://www.google.com/maps/search/?api=1&query=${encodeURIComponent(`${s.dealer.street} ${s.dealer.city}`)}`}>Open in Google Maps ↗</a>
          </div>
        </div>
        <div>
          <SectionTitle kicker="FAQ" title="Straight answers" />
          <div className="divide-y divide-silver-200 rounded-2xl border border-silver-200">
            {FAQS.slice(0, 4).map(([qq, a]) => (
              <details key={qq} className="group px-5 py-4">
                <summary className="cursor-pointer list-none font-semibold marker:hidden">{qq}<span className="float-right text-brand-600 group-open:rotate-45">+</span></summary>
                <p className="mt-2 text-sm leading-relaxed text-ink-500">{a}</p>
              </details>
            ))}
          </div>
        </div>
      </section>
    </>
  )
}
