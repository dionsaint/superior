import { useState } from 'react'
import { Heart, LayoutDashboard, MapPin, Menu, Phone, PlayCircle, X } from 'lucide-react'
import { useStore } from '../store'
import { ChatWidget, CompareBar, RequestModal } from './common'
import { Home } from './Home'
import { Inventory } from './Inventory'
import { Vdp } from './Vdp'
import { About, Accessibility, Contact, Faq, Financing, Privacy, TradeIn } from './Pages'
import { hoursText } from '../logic'
import { Btn, cx } from '../ui'

export function ConceptLogo({ small, light }: { small?: boolean; light?: boolean }) {
  return (
    <div className="flex items-center gap-2 select-none" aria-label="Superior Auto Mall concept logo">
      <div className={cx('relative grid place-items-center rounded-lg bg-brand-600 font-black text-white', small ? 'h-8 w-8 text-sm' : 'h-10 w-10 text-lg')}>
        S<span className="absolute -right-1 top-1 h-[60%] w-1 skew-x-[-20deg] bg-silver-300" />
      </div>
      <div className="leading-none">
        <div className={cx('font-black tracking-tight', small ? 'text-[15px]' : 'text-lg', light ? 'text-white' : 'text-ink-900')}>
          SUPERIOR <span className="text-brand-600">AUTO MALL</span>
        </div>
        <div className={cx('mt-0.5 text-[9px] font-semibold uppercase tracking-[.18em]', light ? 'text-silver-300' : 'text-ink-400')}>Concept text logo · not official</div>
      </div>
    </div>
  )
}

export const NAV = [
  { path: '/inventory', label: 'Shop Cars' },
  { path: '/trade-in', label: 'Sell / Trade' },
  { path: '/financing', label: 'Financing' },
  { path: '/about', label: 'About' },
  { path: '/contact', label: 'Contact' },
]

export function PublicSite() {
  const { s, ui, go, setUi } = useStore()
  const [menu, setMenu] = useState(false)
  const [td, setTd] = useState(false)
  const path = ui.route.split('?')[0]
  const page = path === '/' || path === '' ? <Home onTestDrive={() => setTd(true)} />
    : path === '/inventory' ? <Inventory />
    : path.startsWith('/inventory/') ? <Vdp />
    : path === '/trade-in' ? <TradeIn />
    : path === '/financing' ? <Financing />
    : path === '/about' ? <About />
    : path === '/contact' ? <Contact />
    : path === '/faq' ? <Faq />
    : path === '/privacy' ? <Privacy />
    : path === '/accessibility' ? <Accessibility />
    : <Home onTestDrive={() => setTd(true)} />

  return (
    <div className="min-h-screen bg-white text-ink-900">
      <div className="bg-ink-900 text-[12px] text-silver-200">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-2 px-4 py-1.5">
          <span>
            <b className="text-white">Unofficial demo</b> — a concept redesign, not the official Superior Auto Mall website. Cars and prices are sample data.
          </span>
          <span className="flex items-center gap-3">
            <button onClick={() => setUi({ scenarioPicker: true })} className="inline-flex items-center gap-1 font-semibold text-white hover:underline"><PlayCircle className="h-3.5 w-3.5" /> Try a scenario</button>
            <button data-tour="to-staff" onClick={() => go('/staff/dashboard')} className="inline-flex items-center gap-1 rounded bg-brand-600 px-2 py-0.5 font-semibold text-white hover:bg-brand-700"><LayoutDashboard className="h-3.5 w-3.5" /> Staff Portal</button>
          </span>
        </div>
      </div>

      <header className="sticky top-0 z-30 border-b border-silver-200 bg-white/95 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-6xl items-center justify-between gap-4 px-4">
          <button onClick={() => go('/')} aria-label="Home"><ConceptLogo small /></button>
          <nav className="hidden items-center gap-1 lg:flex" aria-label="Main">
            {NAV.map((n) => (
              <button key={n.path} onClick={() => go(n.path)} className={cx('rounded-lg px-3 py-2 text-sm font-semibold transition', path.startsWith(n.path) ? 'text-brand-700' : 'text-ink-700 hover:text-brand-700')}>
                {n.label}
              </button>
            ))}
          </nav>
          <div className="flex items-center gap-2">
            <a href={`tel:${s.dealer.phone}`} className="hidden items-center gap-1.5 text-sm font-bold text-ink-900 md:inline-flex"><Phone className="h-4 w-4 text-brand-600" />{s.dealer.phone}</a>
            <button onClick={() => go('/inventory?saved=1')} className="relative rounded-lg p-2 text-ink-700 hover:bg-silver-100" aria-label="Saved cars">
              <Heart className="h-5 w-5" />
              {s.favorites.length > 0 && <span className="absolute -right-0.5 -top-0.5 grid h-4 min-w-4 place-items-center rounded-full bg-brand-600 px-1 text-[10px] font-bold text-white">{s.favorites.length}</span>}
            </button>
            <Btn variant="primary" size="sm" className="hidden sm:inline-flex" onClick={() => setTd(true)}>Schedule a Test Drive</Btn>
            <button className="rounded-lg p-2 lg:hidden" onClick={() => setMenu(!menu)} aria-label="Menu">{menu ? <X /> : <Menu />}</button>
          </div>
        </div>
        {menu && (
          <div className="border-t border-silver-200 bg-white px-4 py-3 lg:hidden">
            {NAV.map((n) => (
              <button key={n.path} onClick={() => { go(n.path); setMenu(false) }} className="block w-full rounded-lg px-3 py-3 text-left text-base font-semibold hover:bg-silver-50">{n.label}</button>
            ))}
            <a href={`tel:${s.dealer.phone}`} className="mt-2 flex items-center gap-2 rounded-lg bg-brand-600 px-3 py-3 font-bold text-white"><Phone className="h-4 w-4" /> Call {s.dealer.phone}</a>
          </div>
        )}
      </header>

      <main key={path}>{page}</main>

      <footer className="mt-16 border-t-4 border-brand-600 bg-ink-900 text-silver-300">
        <div className="mx-auto grid max-w-6xl gap-8 px-4 py-10 md:grid-cols-4">
          <div className="md:col-span-2">
            <ConceptLogo light />
            <p className="mt-4 max-w-sm text-sm leading-relaxed text-silver-400">An independent used-car dealership in St. Petersburg, Florida. This page is an unofficial concept demo built for a sales presentation.</p>
          </div>
          <div className="text-sm">
            <div className="mb-2 font-bold text-white">Visit</div>
            <div className="flex gap-2"><MapPin className="mt-0.5 h-4 w-4 shrink-0 text-brand-500" /><span>{s.dealer.street}<br />{s.dealer.city} {s.dealer.zip}<br /><span className="text-[11px] text-silver-400">Demo address from current site footer — confirm with owner</span></span></div>
            <a href={`tel:${s.dealer.phone}`} className="mt-2 flex items-center gap-2 font-semibold text-white"><Phone className="h-4 w-4 text-brand-500" />{s.dealer.phone}</a>
            <p className="mt-2 text-[12px] leading-relaxed">{hoursText(s.hours)}</p>
          </div>
          <div className="text-sm">
            <div className="mb-2 font-bold text-white">Explore</div>
            {[...NAV, { path: '/faq', label: 'FAQ' }, { path: '/privacy', label: 'Privacy' }, { path: '/accessibility', label: 'Accessibility' }].map((n) => (
              <button key={n.path} onClick={() => go(n.path)} className="block py-1 hover:text-white">{n.label}</button>
            ))}
          </div>
        </div>
        <div className="border-t border-white/10 px-4 py-4 text-center text-[11px] text-silver-400">
          Concept demo · All vehicles, prices, customers and staff are synthetic · No reviews or ratings are shown because none have been verified · Inventory updated {s.now.replace('T', ' ')} ET (demo clock)
        </div>
      </footer>

      <ChatWidget />
      <CompareBar />
      <RequestModal open={td} onClose={() => setTd(false)} kind="test-drive" />
    </div>
  )
}
