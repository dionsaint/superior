import { useEffect, useMemo, useState } from 'react'
import { Grid3x3, List, Search, SlidersHorizontal, X } from 'lucide-react'
import { useStore } from '../store'
import { publicVehicles } from '../logic'
import { Btn, Empty, Input, Select, cx } from '../ui'
import { VehicleCard, useSeo } from './common'

const PAGE = 9

export function Inventory() {
  const { s, ui, go } = useStore()
  const params = new URLSearchParams(ui.route.split('?')[1] ?? '')
  const [f, setF] = useState({
    q: params.get('q') ?? '',
    make: params.get('make') ?? '',
    model: params.get('model') ?? '',
    year: params.get('year') ?? '',
    price: params.get('price') ?? '',
    miles: params.get('miles') ?? '',
    body: params.get('body') ?? '',
    saved: params.get('saved') === '1',
  })
  const [sort, setSort] = useState('newest')
  const [view, setView] = useState<'grid' | 'list'>('grid')
  const [shown, setShown] = useState(PAGE)
  const [filtersOpen, setFiltersOpen] = useState(false)
  useEffect(() => setShown(PAGE), [f, sort])
  useSeo('Used Car Inventory | Superior Auto Mall (Concept Demo)', 'Search used cars, trucks and SUVs by make, model, year, price, mileage and body style.', null, '/inventory')

  const all = publicVehicles(s)
  const makes = [...new Set(all.map((v) => v.make))].sort()
  const models = [...new Set(all.filter((v) => !f.make || v.make === f.make).map((v) => v.model))].sort()

  const list = useMemo(() => {
    let r = all.filter((v) => {
      if (f.saved && !s.favorites.includes(v.id)) return false
      if (f.q && !`${v.year} ${v.make} ${v.model} ${v.trim} ${v.stock} ${v.color}`.toLowerCase().includes(f.q.toLowerCase())) return false
      if (f.make && v.make !== f.make) return false
      if (f.model && v.model !== f.model) return false
      if (f.year && v.year < Number(f.year)) return false
      if (f.price && (v.price == null || v.price > Number(f.price))) return false
      if (f.miles && (v.mileage == null || v.mileage > Number(f.miles))) return false
      if (f.body && v.body !== f.body) return false
      return true
    })
    const nullLast = (a: number | null, b: number | null, dir: 1 | -1) => (a == null ? 1 : b == null ? -1 : (a - b) * dir)
    r = [...r].sort((a, b) =>
      sort === 'price-asc' ? nullLast(a.price, b.price, 1)
        : sort === 'price-desc' ? nullLast(a.price, b.price, -1)
        : sort === 'year' ? b.year - a.year
        : sort === 'miles' ? nullLast(a.mileage, b.mileage, 1)
        : a.daysOnLot - b.daysOnLot,
    )
    return r
  }, [all, f, sort, s.favorites])

  const chips = Object.entries(f).filter(([k, v]) => v && k !== 'q') as [keyof typeof f, string | boolean][]
  const clear = () => {
    setF({ q: '', make: '', model: '', year: '', price: '', miles: '', body: '', saved: false })
    go('/inventory')
  }
  const chipLabel = (k: string, v: string | boolean) =>
    k === 'price' ? `Under $${Number(v) / 1000}k` : k === 'miles' ? `Under ${Number(v) / 1000}k mi` : k === 'year' ? `${v}+` : k === 'saved' ? 'Saved cars' : String(v)
  const updated = s.vehicles.reduce((m, v) => (v.updatedAt > m ? v.updatedAt : m), '')

  const filters = (
    <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-1">
      <Select aria-label="Make" value={f.make} onChange={(e) => setF({ ...f, make: e.target.value, model: '' })}><option value="">Any make</option>{makes.map((m) => <option key={m}>{m}</option>)}</Select>
      <Select aria-label="Model" value={f.model} onChange={(e) => setF({ ...f, model: e.target.value })}><option value="">Any model</option>{models.map((m) => <option key={m}>{m}</option>)}</Select>
      <Select aria-label="Year" value={f.year} onChange={(e) => setF({ ...f, year: e.target.value })}><option value="">Any year</option>{[2014, 2016, 2018, 2020].map((y) => <option key={y} value={y}>{y} & newer</option>)}</Select>
      <Select aria-label="Max price" value={f.price} onChange={(e) => setF({ ...f, price: e.target.value })}><option value="">Any price</option>{[12000, 16000, 20000, 30000].map((p) => <option key={p} value={p}>Under ${p / 1000}k</option>)}</Select>
      <Select aria-label="Max mileage" value={f.miles} onChange={(e) => setF({ ...f, miles: e.target.value })}><option value="">Any mileage</option>{[50000, 75000, 100000].map((m) => <option key={m} value={m}>Under {m / 1000}k miles</option>)}</Select>
      <Select aria-label="Body style" value={f.body} onChange={(e) => setF({ ...f, body: e.target.value })}><option value="">Any body style</option>{['Sedan', 'SUV', 'Truck', 'Hatchback'].map((b) => <option key={b}>{b}</option>)}</Select>
      <label className="flex items-center gap-2 text-sm font-medium"><input type="checkbox" className="accent-brand-600" checked={f.saved} onChange={(e) => setF({ ...f, saved: e.target.checked })} /> Only my saved cars ({s.favorites.length})</label>
    </div>
  )

  return (
    <div className="mx-auto max-w-6xl px-4 py-8">
      <div className="mb-5 flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <div>
          <h1 className="text-3xl font-black tracking-tight">Shop used cars</h1>
          <p className="text-sm text-ink-500">{list.length} of {all.length} cars · Updated {updated.replace('T', ' ')} ET (demo)</p>
        </div>
        <div className="relative w-full md:w-80">
          <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-ink-400" />
          <Input data-tour="inv-search" aria-label="Search inventory" className="pl-9" placeholder="Search make, model, stock #" value={f.q} onChange={(e) => setF({ ...f, q: e.target.value })} />
        </div>
      </div>
      <div className="grid gap-6 lg:grid-cols-[230px_minmax(0,1fr)]">
        <aside className="hidden lg:block">
          <div className="sticky top-24 space-y-3 rounded-2xl border border-silver-200 p-4">
            <div className="flex items-center justify-between text-sm font-bold"><span>Filters</span>{chips.length > 0 && <button onClick={clear} className="text-xs font-semibold text-brand-700">Clear all</button>}</div>
            {filters}
          </div>
        </aside>
        <div>
          <div className="mb-4 flex flex-wrap items-center gap-2">
            <Btn size="sm" className="lg:hidden" onClick={() => setFiltersOpen(!filtersOpen)} icon={<SlidersHorizontal className="h-4 w-4" />}>Filters</Btn>
            {chips.map(([k, v]) => (
              <button key={k} onClick={() => setF({ ...f, [k]: k === 'saved' ? false : '' })} className="inline-flex items-center gap-1 rounded-full bg-brand-50 px-3 py-1 text-[12px] font-semibold text-brand-700 ring-1 ring-brand-100">
                {chipLabel(k, v)} <X className="h-3 w-3" />
              </button>
            ))}
            <div className="ml-auto flex items-center gap-2">
              <Select aria-label="Sort" className="h-8 py-0 text-[13px]" value={sort} onChange={(e) => setSort(e.target.value)}>
                <option value="newest">Newest listed</option>
                <option value="price-asc">Price: low to high</option>
                <option value="price-desc">Price: high to low</option>
                <option value="year">Year: newest</option>
                <option value="miles">Mileage: lowest</option>
              </Select>
              <div className="flex rounded-lg border border-silver-300 p-0.5">
                <button aria-label="Grid view" onClick={() => setView('grid')} className={cx('rounded-md p-1.5', view === 'grid' && 'bg-ink-900 text-white')}><Grid3x3 className="h-4 w-4" /></button>
                <button aria-label="List view" onClick={() => setView('list')} className={cx('rounded-md p-1.5', view === 'list' && 'bg-ink-900 text-white')}><List className="h-4 w-4" /></button>
              </div>
            </div>
          </div>
          {filtersOpen && <div className="mb-4 rounded-2xl border border-silver-200 p-4 lg:hidden">{filters}</div>}
          {list.length === 0 ? (
            <Empty icon={<Search className="h-8 w-8" />} title="No cars match those filters" body="Try removing a filter, or ask us — inventory changes often." action={<Btn variant="primary" size="sm" onClick={clear}>Clear filters</Btn>} />
          ) : (
            <>
              <div className={cx('grid gap-5', view === 'grid' ? 'sm:grid-cols-2 xl:grid-cols-3' : 'grid-cols-1')}>
                {list.slice(0, shown).map((v) => <VehicleCard key={v.id} v={v} list={view === 'list'} />)}
              </div>
              {shown < list.length && (
                <div className="mt-6 text-center">
                  <Btn onClick={() => setShown(shown + PAGE)}>Load more ({list.length - shown} left)</Btn>
                </div>
              )}
            </>
          )}
          <p className="mt-6 text-xs text-ink-500">Sold cars are removed automatically. Prices shown are set by the dealer; government tax, tag and title are extra. "Call for price" means the price hasn't been posted yet.</p>
        </div>
      </div>
    </div>
  )
}
