import React, { useEffect, useMemo, useRef, useState } from 'react'
import { Bot, Calendar, CheckCircle2, Heart, Images, Phone, Send, Scale, UserRound, X } from 'lucide-react'
import { useStore } from '../store'
import type { LeadKind, Vehicle, Wall } from '../types'
import { advertised, conciergeReply, isOffHours, isPublic, milesLabel, money, slugOf, statusLabel } from '../logic'
import { fmtDay, fmtTime, nextSlots } from '../time'
import { publicLead } from '../actions'
import { Badge, Btn, CarArt, Field, Input, Modal, Select, Textarea, cx } from '../ui'

export function useSeo(title: string, description: string, jsonld?: object | null, canonical?: string) {
  useEffect(() => {
    document.title = title
    const set = (sel: string, make: () => HTMLElement, attr: string, val: string) => {
      let el = document.head.querySelector(sel) as HTMLElement | null
      if (!el) {
        el = make()
        document.head.appendChild(el)
      }
      el.setAttribute(attr, val)
    }
    set('meta[name="description"]', () => Object.assign(document.createElement('meta'), { name: 'description' }), 'content', description)
    set('link[rel="canonical"]', () => Object.assign(document.createElement('link'), { rel: 'canonical' }), 'href', `https://demo.example.com${canonical ?? '/'}`)
    let s = document.getElementById('jsonld')
    if (jsonld) {
      if (!s) {
        s = document.createElement('script')
        s.id = 'jsonld'
        s.setAttribute('type', 'application/ld+json')
        document.head.appendChild(s)
      }
      s.textContent = JSON.stringify(jsonld)
    } else s?.remove()
  }, [title, description, canonical, JSON.stringify(jsonld)])
}

export function PriceTag({ v, size = 'md' }: { v: Vehicle; size?: 'md' | 'lg' }) {
  const { s } = useStore()
  const a = advertised(v, s.dealer)
  if (a.amount == null)
    return (
      <div>
        <div className={cx('font-extrabold text-ink-900', size === 'lg' ? 'text-2xl' : 'text-lg')}>Call for price</div>
        {size === 'lg' && <div className="text-xs text-ink-500">{a.note}</div>}
      </div>
    )
  return (
    <div>
      <div className={cx('font-extrabold tracking-tight text-ink-900', size === 'lg' ? 'text-3xl' : 'text-xl')}>{money(a.amount)}</div>
      {size === 'lg' && <div className="max-w-xs text-xs leading-snug text-ink-500">{a.note}</div>}
    </div>
  )
}

export function VehicleCard({ v, list }: { v: Vehicle; list?: boolean }) {
  const { s, act, go } = useStore()
  const fav = s.favorites.includes(v.id)
  const cmp = s.compare.includes(v.id)
  const open = () => go(`/inventory/${slugOf(v)}`)
  return (
    <article className={cx('group overflow-hidden rounded-2xl border border-silver-200 bg-white transition hover:-translate-y-0.5 hover:shadow-lg hover:shadow-ink-900/5', list && 'sm:flex')}>
      <button onClick={open} className={cx('relative block aspect-[16/10] w-full overflow-hidden bg-silver-100 text-left', list && 'sm:w-72 sm:shrink-0')} aria-label={`View ${v.year} ${v.make} ${v.model}`}>
        <CarArt v={v} shot={v.photos[0]?.shot} src={v.photos[0]?.src} label={false} className="transition duration-500 group-hover:scale-[1.03]" />
        <span className="absolute bottom-2 left-2 inline-flex items-center gap-1 rounded-md bg-ink-900/75 px-1.5 py-0.5 text-[11px] font-semibold text-white">
          <Images className="h-3 w-3" /> {v.photos.length}
        </span>
        <span className="absolute left-2 top-2">
          <Badge tone={v.status === 'available' ? 'green' : v.status === 'pending' ? 'amber' : 'gray'}>{statusLabel(v)}</Badge>
        </span>
      </button>
      <div className="flex flex-1 flex-col p-4">
        <div className="flex items-start justify-between gap-2">
          <button onClick={open} className="text-left">
            <h3 className="text-[15px] font-bold leading-tight text-ink-900 group-hover:text-brand-700">
              {v.year} {v.make} {v.model}
            </h3>
            <div className="text-[13px] text-ink-500">{v.trim}</div>
          </button>
          <button
            onClick={() => act((st) => (st.favorites = fav ? st.favorites.filter((x) => x !== v.id) : [...st.favorites, v.id]))}
            className={cx('rounded-full p-1.5 transition', fav ? 'text-brand-600' : 'text-silver-400 hover:text-brand-600')}
            aria-label={fav ? 'Remove from saved' : 'Save vehicle'}
            aria-pressed={fav}
          >
            <Heart className={cx('h-5 w-5', fav && 'fill-current')} />
          </button>
        </div>
        <div className="mt-3 flex items-end justify-between gap-2">
          <PriceTag v={v} />
          <div className="text-right text-[12px] text-ink-500">
            <div>{v.mileage == null ? 'Mileage: confirm with dealer' : milesLabel(v)}</div>
            <div>Stock {v.stock}</div>
          </div>
        </div>
        <div className="mt-3 flex items-center justify-between border-t border-silver-100 pt-3">
          <label className="flex cursor-pointer items-center gap-1.5 text-[12px] font-medium text-ink-700">
            <input
              type="checkbox"
              className="accent-brand-600"
              checked={cmp}
              onChange={() => act((st, c) => {
                if (cmp) st.compare = st.compare.filter((x) => x !== v.id)
                else if (st.compare.length >= 3) c.toast('You can compare up to 3 cars.', 'warn')
                else st.compare = [...st.compare, v.id]
              })}
            />
            Compare
          </label>
          <button onClick={open} className="text-[13px] font-semibold text-brand-700 hover:underline">
            View details →
          </button>
        </div>
      </div>
    </article>
  )
}

export function CompareBar() {
  const { s, act } = useStore()
  const [open, setOpen] = useState(false)
  const cars = s.compare.map((id) => s.vehicles.find((v) => v.id === id)).filter(Boolean) as Vehicle[]
  if (!cars.length) return null
  const rows: [string, (v: Vehicle) => React.ReactNode][] = [
    ['Price', (v) => <PriceTag v={v} />],
    ['Mileage', (v) => (v.mileage == null ? 'Confirm with dealer' : milesLabel(v))],
    ['Body', (v) => v.body],
    ['Engine', (v) => v.engine || '—'],
    ['Transmission', (v) => v.transmission || '—'],
    ['Drive', (v) => v.drivetrain || '—'],
    ['Fuel economy', (v) => v.mpg ?? 'Not listed'],
    ['Color', (v) => v.color],
    ['Photos', (v) => v.photos.length],
    ['Status', (v) => statusLabel(v)],
  ]
  return (
    <>
      <div className="fixed inset-x-0 bottom-0 z-40 border-t border-silver-200 bg-white/95 px-4 py-2.5 shadow-[0_-6px_20px_rgba(0,0,0,.06)] backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center gap-3">
          <Scale className="h-5 w-5 text-brand-600" />
          <div className="flex-1 truncate text-sm font-semibold">
            Comparing {cars.length}: <span className="font-normal text-ink-500">{cars.map((c) => `${c.year} ${c.model}`).join(' · ')}</span>
          </div>
          <Btn size="sm" variant="ghost" onClick={() => act((st) => (st.compare = []))}>Clear</Btn>
          <Btn size="sm" variant="primary" disabled={cars.length < 2} onClick={() => setOpen(true)}>Compare now</Btn>
        </div>
      </div>
      <Modal open={open} onClose={() => setOpen(false)} title="Side-by-side comparison" wide>
        <div className="scroll-thin overflow-x-auto">
          <table className="w-full min-w-[520px] text-sm">
            <thead>
              <tr>
                <th className="w-32" />
                {cars.map((c) => (
                  <th key={c.id} className="p-2 text-left align-top">
                    <div className="mb-2 aspect-[16/10] overflow-hidden rounded-lg"><CarArt v={c} label={false} /></div>
                    <div className="font-bold">{c.year} {c.make} {c.model}</div>
                    <div className="text-xs font-normal text-ink-500">{c.trim} · {c.stock}</div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.map(([k, f]) => (
                <tr key={k} className="border-t border-silver-100">
                  <td className="p-2 text-xs font-semibold text-ink-500">{k}</td>
                  {cars.map((c) => <td key={c.id} className="p-2">{f(c)}</td>)}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <p className="mt-3 text-xs text-ink-500">All details come from the dealer's demo records. Anything marked "confirm" hasn't been verified yet.</p>
      </Modal>
    </>
  )
}

// ------------- Lead request modal (test drive / availability / contact) -------------
export function RequestModal({ open, onClose, kind, vehicle, defaultMessage }: { open: boolean; onClose: () => void; kind: LeadKind; vehicle?: Vehicle | null; defaultMessage?: string }) {
  const { s, act, get, nav } = useStore()
  const slots = useMemo(() => nextSlots(s.now, s.hours, s.appointments, 5), [s.now, s.hours, s.appointments])
  const [f, setF] = useState({ name: '', phone: '', email: '', channel: 'sms' as 'sms' | 'email' | 'phone', sms: false, msg: defaultMessage ?? '', slot: '' as Wall | '' })
  const [done, setDone] = useState<string | null>(null)
  useEffect(() => {
    if (open) {
      setDone(null)
      setF((x) => ({ ...x, msg: defaultMessage ?? '', slot: '' }))
    }
  }, [open, defaultMessage])
  const title = kind === 'test-drive' ? 'Schedule a test drive' : kind === 'availability' ? 'Ask us to confirm availability' : 'Send us a message'
  const submit = (e: React.FormEvent) => {
    e.preventDefault()
    let id = ''
    act((st, c) => {
      id = publicLead(st, c, { kind, name: f.name, phone: f.phone, email: f.email, channel: f.channel, smsOptIn: f.sms, vehicleId: vehicle?.id ?? null, message: f.msg, slot: f.slot || null })
    })
    setDone(id || get().leads[0]?.id)
  }
  return (
    <Modal open={open} onClose={onClose} title={done ? 'Request received' : title}>
      {done ? (
        <div className="space-y-4 py-2 text-center">
          <CheckCircle2 className="mx-auto h-12 w-12 text-emerald-600" />
          <div className="text-lg font-bold">Thanks{f.name ? `, ${f.name.split(' ')[0]}` : ''}!</div>
          <p className="text-sm text-ink-500">
            {f.slot ? `We've held ${fmtDay(f.slot)} at ${fmtTime(f.slot)} for you. A team member will confirm it.` : 'A team member will get back to you.'}
          </p>
          <div className="rounded-xl border border-dashed border-silver-400 bg-silver-50 p-3 text-left text-[13px] text-ink-700">
            <b>DEMO:</b> nothing was sent to a real dealership. This request just appeared in the <b>staff inbox</b> of this demo, assigned to a salesperson, with an AI-drafted reply waiting for approval.
          </div>
          <div className="flex justify-center gap-2">
            <Btn onClick={onClose}>Back to the website</Btn>
            <Btn variant="dark" onClick={() => { onClose(); nav('leads', done) }}>See it in the Staff Portal →</Btn>
          </div>
        </div>
      ) : (
        <form onSubmit={submit} className="space-y-3">
          {vehicle && (
            <div className="flex items-center gap-3 rounded-xl bg-silver-50 p-2">
              <div className="h-12 w-20 overflow-hidden rounded-lg"><CarArt v={vehicle} label={false} /></div>
              <div className="text-sm">
                <div className="font-bold">{vehicle.year} {vehicle.make} {vehicle.model}</div>
                <div className="text-xs text-ink-500">Stock {vehicle.stock}</div>
              </div>
            </div>
          )}
          <div className="grid gap-3 sm:grid-cols-2">
            <Field label="Your name"><Input required value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} placeholder="First name & last initial" /></Field>
            <Field label="Phone"><Input value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} placeholder="(727) 555-0100" inputMode="tel" /></Field>
            <Field label="Email"><Input type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} placeholder="you@example.com" /></Field>
            <Field label="Best way to reach you">
              <Select value={f.channel} onChange={(e) => setF({ ...f, channel: e.target.value as 'sms' })}>
                <option value="sms">Text message</option>
                <option value="email">Email</option>
                <option value="phone">Phone call</option>
              </Select>
            </Field>
          </div>
          {kind === 'test-drive' && (
            <Field label="Pick a time (Eastern Time)" hint="These are open times from the dealership's demo calendar. A team member will confirm.">
              <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">
                {slots.map((w) => (
                  <button type="button" key={w} onClick={() => setF({ ...f, slot: w })} className={cx('rounded-lg border px-2 py-2 text-[13px] font-semibold', f.slot === w ? 'border-brand-600 bg-brand-50 text-brand-700' : 'border-silver-300 hover:border-ink-400')}>
                    {fmtDay(w)}<br /><span className="font-normal">{fmtTime(w)}</span>
                  </button>
                ))}
              </div>
            </Field>
          )}
          <Field label="Message (optional)"><Textarea value={f.msg} onChange={(e) => setF({ ...f, msg: e.target.value })} placeholder="Anything we should know?" /></Field>
          <label className="flex items-start gap-2 text-[12px] leading-snug text-ink-500">
            <input type="checkbox" className="mt-0.5 accent-brand-600" checked={f.sms} onChange={(e) => setF({ ...f, sms: e.target.checked })} />
            <span>Yes, you may text me about this request. Message frequency varies; reply STOP to opt out. Consent isn't required to buy. (Demo — no texts are sent.)</span>
          </label>
          <div className="flex justify-end gap-2 pt-1">
            <Btn type="button" variant="ghost" onClick={onClose}>Cancel</Btn>
            <Btn type="submit" variant="primary" disabled={!f.name || (!f.phone && !f.email) || (kind === 'test-drive' && !f.slot)}>
              {kind === 'test-drive' ? 'Request this time' : 'Send'}
            </Btn>
          </div>
        </form>
      )}
    </Modal>
  )
}

// ------------- AI chat (opens only when invited) -------------
interface ChatMsg { from: 'me' | 'ai'; text: string; slots?: Wall[] }

export function ChatWidget() {
  const { s, ui, setUi, act, nav } = useStore()
  const slug = ui.route.startsWith('/inventory/') ? ui.route.split('/')[2]?.split('?')[0] : null
  const ctxVehicle = slug ? s.vehicles.find((v) => slugOf(v) === slug) ?? null : null
  const [msgs, setMsgs] = useState<ChatMsg[]>([])
  const [text, setText] = useState('')
  const [vid, setVid] = useState<string | null>(null)
  const [pick, setPick] = useState<Wall | null>(null)
  const [contact, setContact] = useState({ name: '', phone: '', sms: false })
  const [handoff, setHandoff] = useState(false)
  const [sentId, setSentId] = useState<string | null>(null)
  const end = useRef<HTMLDivElement>(null)
  const off = isOffHours(s)

  useEffect(() => { end.current?.scrollIntoView({ behavior: 'smooth' }) }, [msgs, pick, handoff, sentId])
  useEffect(() => {
    if (ctxVehicle) setVid(ctxVehicle.id)
  }, [ctxVehicle?.id])

  // Allow the guided tour to type a question
  useEffect(() => {
    const on = (e: Event) => {
      const q = (e as CustomEvent<string>).detail
      setUi({ chatOpen: true })
      setTimeout(() => ask(q), 250)
    }
    window.addEventListener('demo-chat-ask', on)
    return () => window.removeEventListener('demo-chat-ask', on)
  })
  useEffect(() => {
    const on = () => {
      const last = [...msgs].reverse().find((m) => m.slots?.length)
      if (last?.slots) setPick(last.slots[0])
      setContact({ name: 'Jordan P. (demo shopper)', phone: '(727) 555-0142', sms: true })
    }
    window.addEventListener('demo-chat-pick', on)
    return () => window.removeEventListener('demo-chat-pick', on)
  })

  const ask = (q: string) => {
    if (!q.trim()) return
    const out = conciergeReply(q, { vehicles: s.vehicles.filter(isPublic), offHours: off, slots: nextSlots(s.now, s.hours, s.appointments), first: msgs.length === 0, vehicleId: vid, hours: s.hours })
    setVid(out.vehicleId)
    setMsgs((m) => [...m, { from: 'me', text: q }, { from: 'ai', text: out.text, slots: out.offeredSlots }])
    if (out.handoff) setHandoff(true)
    setText('')
  }

  const transcript = () => msgs.map((m) => `${m.from === 'me' ? 'Customer' : 'AI'}: ${m.text}`).join('\n')
  const submitLead = (kind: 'test-drive' | 'contact') => {
    let id = ''
    act((st, c) => {
      id = publicLead(st, c, { kind, name: contact.name, phone: contact.phone, email: '', channel: contact.sms ? 'sms' : 'phone', smsOptIn: contact.sms, vehicleId: vid, message: transcript().split('\n').filter((l) => l.startsWith('Customer')).map((l) => l.replace('Customer: ', '')).join(' / '), slot: kind === 'test-drive' ? pick : null })
      const l = st.leads.find((x) => x.id === id)
      if (l) {
        l.messages = [
          ...msgs.map((m, i) => ({ id: `${id}-c${i}`, from: (m.from === 'me' ? 'customer' : 'ai') as 'customer' | 'ai', text: m.text, at: st.now, status: m.from === 'ai' ? ('sent-demo' as const) : undefined })),
          ...l.messages.slice(1),
        ]
      }
    })
    setSentId(id)
    setMsgs((m) => [...m, { from: 'ai', text: kind === 'test-drive' && pick ? `Thanks! I've held ${fmtDay(pick)} at ${fmtTime(pick)}. A team member will confirm${off ? ' when we open' : ''}.` : `Thanks! A team member will reach out${off ? ' when we open' : ' shortly'}.` }])
    setPick(null)
    setHandoff(false)
  }

  if (!ui.chatOpen)
    return (
      <button data-tour="chat-button" onClick={() => setUi({ chatOpen: true })} className="fixed bottom-4 right-4 z-40 inline-flex items-center gap-2 rounded-full bg-white px-4 py-2.5 text-sm font-semibold text-ink-900 shadow-lg ring-1 ring-silver-200 hover:ring-brand-600">
        <Bot className="h-4 w-4 text-brand-600" /> Ask a question
      </button>
    )

  const v = s.vehicles.find((x) => x.id === vid)
  return (
    <div data-tour="chat" className="fixed inset-x-0 bottom-0 z-50 flex h-[78vh] flex-col overflow-hidden rounded-t-2xl bg-white shadow-2xl ring-1 ring-silver-200 sm:inset-x-auto sm:bottom-4 sm:right-4 sm:h-[560px] sm:w-[380px] sm:rounded-2xl">
      <div className="flex items-center gap-3 bg-brand-600 px-4 py-3 text-white">
        <div className="grid h-9 w-9 place-items-center rounded-full bg-white/15"><Bot className="h-5 w-5" /></div>
        <div className="flex-1">
          <div className="text-sm font-bold">Virtual assistant (AI)</div>
          <div className="text-[11px] text-white/80">{off ? 'After hours — staff will follow up when we open' : 'Staff available now'} · Demo</div>
        </div>
        <button onClick={() => setUi({ chatOpen: false })} aria-label="Close chat" className="rounded-lg p-1 hover:bg-white/15"><X className="h-5 w-5" /></button>
      </div>
      {v && <div className="border-b border-silver-100 bg-silver-50 px-4 py-1.5 text-[12px] text-ink-500">Talking about: <b className="text-ink-800">{v.year} {v.make} {v.model}</b> · {v.stock}</div>}
      <div className="scroll-thin flex-1 space-y-3 overflow-y-auto px-4 py-3">
        {msgs.length === 0 && (
          <div className="space-y-3 text-[13px] text-ink-700">
            <p>Hi! I'm an AI assistant. I can answer questions using the dealership's listing information only. If I don't know something, I'll say so and a person will follow up.</p>
            <div className="flex flex-wrap gap-1.5">
              {(v ? ['Is it still available?', 'How many miles?', 'Can I test drive it?', 'Does it have a warranty?'] : ['Do you have any trucks?', 'What are your hours?', 'Can I trade in my car?']).map((q) => (
                <button key={q} onClick={() => ask(q)} className="rounded-full border border-silver-300 px-3 py-1 text-[12px] font-medium hover:border-brand-600 hover:text-brand-700">{q}</button>
              ))}
            </div>
          </div>
        )}
        {msgs.map((m, i) => (
          <div key={i} className={cx('flex', m.from === 'me' && 'justify-end')}>
            <div className={cx('max-w-[85%] rounded-2xl px-3 py-2 text-[13px] leading-relaxed', m.from === 'me' ? 'rounded-br-sm bg-ink-900 text-white' : 'rounded-bl-sm bg-silver-100 text-ink-900')}>
              {m.text}
              {m.slots && m.slots.length > 0 && !sentId && (
                <div className="mt-2 flex flex-wrap gap-1.5">
                  {m.slots.map((w) => (
                    <button key={w} onClick={() => setPick(w)} className={cx('rounded-lg border px-2 py-1 text-[12px] font-semibold', pick === w ? 'border-brand-600 bg-brand-600 text-white' : 'border-silver-300 bg-white hover:border-brand-600')}>
                      {fmtDay(w)} {fmtTime(w)}
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        ))}
        {(pick || handoff) && !sentId && (
          <div className="rise space-y-2 rounded-xl border border-silver-200 p-3">
            <div className="text-[13px] font-semibold">{pick ? `Hold ${fmtDay(pick)} at ${fmtTime(pick)}?` : 'Leave your info for a person to contact you'}</div>
            <Input placeholder="Your name" value={contact.name} onChange={(e) => setContact({ ...contact, name: e.target.value })} />
            <Input placeholder="Phone" value={contact.phone} onChange={(e) => setContact({ ...contact, phone: e.target.value })} />
            <label className="flex items-start gap-2 text-[11.5px] text-ink-500">
              <input type="checkbox" className="mt-0.5 accent-brand-600" checked={contact.sms} onChange={(e) => setContact({ ...contact, sms: e.target.checked })} />
              You may text me about this. Reply STOP to opt out. (Demo — no texts are sent.)
            </label>
            <Btn data-tour="chat-confirm" size="sm" variant="primary" className="w-full" disabled={!contact.name || !contact.phone} onClick={() => submitLead(pick ? 'test-drive' : 'contact')}>
              {pick ? 'Request this time' : 'Have someone contact me'}
            </Btn>
          </div>
        )}
        {sentId && (
          <div className="rounded-xl border border-dashed border-silver-400 bg-silver-50 p-3 text-[12px] text-ink-700">
            <b>DEMO:</b> sent to the staff inbox only.{' '}
            <button className="font-semibold text-brand-700 underline" onClick={() => nav('leads', sentId)}>Open it in the Staff Portal</button>
          </div>
        )}
        <div ref={end} />
      </div>
      <div className="border-t border-silver-200 p-3">
        <form onSubmit={(e) => { e.preventDefault(); ask(text) }} className="flex gap-2">
          <Input value={text} onChange={(e) => setText(e.target.value)} placeholder="Type your question…" aria-label="Your question" />
          <Btn type="submit" variant="primary" aria-label="Send"><Send className="h-4 w-4" /></Btn>
        </form>
        <div className="mt-2 flex items-center justify-between text-[11px] text-ink-500">
          <button onClick={() => { setHandoff(true); setMsgs((m) => [...m, { from: 'ai', text: 'Sure — leave your name and number and a person will contact you.' }]) }} className="inline-flex items-center gap-1 font-semibold text-ink-700 hover:text-brand-700"><UserRound className="h-3.5 w-3.5" /> Speak to a person</button>
          <a href={`tel:${s.dealer.phone}`} className="inline-flex items-center gap-1 font-semibold text-ink-700 hover:text-brand-700"><Phone className="h-3.5 w-3.5" /> {s.dealer.phone}</a>
        </div>
      </div>
    </div>
  )
}

export const SectionTitle = ({ kicker, title, sub }: { kicker?: string; title: string; sub?: string }) => (
  <div className="mb-6">
    {kicker && <div className="mb-1 text-xs font-bold uppercase tracking-[.16em] text-brand-600">{kicker}</div>}
    <h2 className="text-2xl font-extrabold tracking-tight text-ink-900 md:text-3xl">{title}</h2>
    {sub && <p className="mt-1 max-w-2xl text-ink-500">{sub}</p>}
  </div>
)

export const CalIcon = Calendar
