import { useEffect } from 'react'
import { StoreProvider, useStore } from './store'
import { TourOverlay, TourProvider, ScenarioPicker, Toasts } from './tour'
import { PublicSite } from './public/PublicSite'
import { StaffLayout } from './staff/StaffLayout'
import { Dashboard } from './staff/Dashboard'
import { Leads } from './staff/Leads'
import { Listings } from './staff/Listings'
import { Deals } from './staff/Deals'
import { CalendarScreen } from './staff/Calendar'
import { FrontDesk } from './staff/FrontDesk'
import { Roi, ProposalModal } from './staff/Roi'
import { Settings } from './staff/Settings'

function Shell() {
  const { s, ui } = useStore()
  useEffect(() => {
    document.documentElement.dataset.theme = s.theme === 'silver' ? 'silver' : 'white'
  }, [s.theme])
  const staff = ui.route.startsWith('/staff')
  useEffect(() => {
    if (staff) document.title = 'Superior Command AI — Staff Portal (concept demo)'
  }, [staff, ui.screen])
  const page = {
    dashboard: <Dashboard />,
    leads: <Leads />,
    listings: <Listings />,
    deals: <Deals />,
    calendar: <CalendarScreen />,
    frontdesk: <FrontDesk />,
    roi: <Roi />,
    settings: <Settings />,
  }[ui.screen]
  return (
    <>
      {staff ? <StaffLayout>{page}</StaffLayout> : <PublicSite />}
      <ProposalModal />
      <ScenarioPicker />
      <TourOverlay />
      <Toasts />
    </>
  )
}

export function App() {
  return (
    <StoreProvider>
      <TourProvider>
        <Shell />
      </TourProvider>
    </StoreProvider>
  )
}
