import type { DataState, Deal, Dealer, Hours, Issue, Lead, Vehicle, Wall } from './types'
import { DOW_NAMES, fmtDay, fmtTime, inQuiet, isOpen, toMs } from './time'

export const vName = (v?: Vehicle | null) => (v ? `${v.year} ${v.make} ${v.model}` : 'No vehicle selected')
export const vFull = (v?: Vehicle | null) => (v ? `${v.year} ${v.make} ${v.model} ${v.trim}` : '—')
export const money = (n: number) => '$' + Math.round(n).toLocaleString('en-US')
export const priceLabel = (v: Vehicle) => (v.price == null ? 'Please Call' : money(v.price))
export const milesLabel = (v: Vehicle) => (v.mileage == null ? 'Not displayed' : v.mileage.toLocaleString('en-US') + ' mi')

export function vehicleIssues(v: Vehicle, all: Vehicle[]): Issue[] {
  if (v.archived) return []
  const out: Issue[] = []
  if (v.dmsStatus === 'sold' && v.status !== 'sold')
    out.push({ code: 'soldNotRemoved', label: 'Possible sold-not-removed', plain: 'This car may already be sold but is still on the website.', detail: 'DMS record (synthetic) shows SOLD but the website listing still shows it for sale.', severity: 'high', points: 25 })
  if (v.price == null)
    out.push({ code: 'price', label: 'Missing displayed price', plain: 'Shoppers see “Please Call” instead of a price.', detail: 'Website shows "Please Call". Confirm whether this is intentional; pricing-advertising rules should be reviewed with a qualified professional.', severity: 'high', points: 15 })
  if (v.mileage == null)
    out.push({ code: 'mileage', label: 'Missing mileage', plain: 'Shoppers can’t see how many miles it has.', detail: 'No odometer reading displayed. Staff should verify the reading on the vehicle itself.', severity: 'high', points: 15 })
  if (v.dmsVin && v.dmsVin !== v.vin)
    out.push({ code: 'vin', label: 'VIN mismatch', plain: 'The website and your dealer software show different VINs.', detail: `Website VIN ${v.vin} ≠ DMS VIN ${v.dmsVin} (demo identifiers). Verify against the vehicle and title.`, severity: 'high', points: 20 })
  if (v.duplicateOf && !all.find((x) => x.id === v.duplicateOf)?.archived)
    out.push({ code: 'duplicate', label: 'Possible duplicate record', plain: 'The same car seems to be listed twice.', detail: `Same VIN as stock ${all.find((x) => x.id === v.duplicateOf)?.stock}.`, severity: 'high', points: 20 })
  if (v.status === 'unclear' || (v.dmsStatus && v.dmsStatus !== 'sold' && v.dmsStatus !== v.status))
    out.push({ code: 'availability', label: 'Unclear availability', plain: 'It’s not clear if this car can still be bought.', detail: `Website: ${v.status}. DMS (synthetic): ${v.dmsStatus ?? 'unknown'}.`, severity: 'med', points: 15 })
  if (v.photos.length < 8)
    out.push({ code: 'photos', label: 'Too few photos', plain: 'Not enough pictures for shoppers to judge the car.', detail: `${v.photos.length} photo${v.photos.length === 1 ? '' : 's'} — suggested minimum is 8 in a standard order.`, severity: 'med', points: 15 })
  if (v.description.trim().length < 80)
    out.push({ code: 'description', label: 'Incomplete description', plain: 'The write-up is too short to be useful.', detail: 'Description is very short. A factual draft can be generated from verified fields.', severity: 'med', points: 10 })
  if (v.dmsTrim && v.dmsTrim !== v.trim)
    out.push({ code: 'trim', label: 'Inconsistent trim', plain: 'Two systems disagree on the exact version of the car.', detail: `Website: "${v.trim}". DMS (synthetic): "${v.dmsTrim}".`, severity: 'low', points: 10 })
  if (v.daysOnLot > 90 && !v.reviewTask)
    out.push({ code: 'stale', label: 'Stale days-on-lot', plain: 'This car has been on the lot a long time.', detail: `${v.daysOnLot} days on lot. Assign a review — no market-pricing data is connected.`, severity: 'low', points: 10 })
  return out
}

export const vehicleScore = (v: Vehicle, all: Vehicle[]) =>
  Math.max(0, 100 - vehicleIssues(v, all).reduce((s, i) => s + i.points, 0))

export const activeVehicles = (s: DataState) => s.vehicles.filter((v) => !v.archived)

export const isOffHours = (s: DataState) =>
  s.offHoursOverride === 'on' ? true : s.offHoursOverride === 'off' ? false : !isOpen(s.now, s.hours)

export const quietNow = (s: DataState) => inQuiet(s.now, s.quietStart, s.quietEnd)

export function canAutoMessage(s: DataState, l: Lead): { ok: boolean; reason: string } {
  if (l.consent.stopped) return { ok: false, reason: 'Contact opted out (STOP)' }
  if (l.automationPaused) return { ok: false, reason: 'Automation paused for this lead' }
  if (l.humanTakeover) return { ok: false, reason: 'Staff has taken over' }
  const ch = l.channel
  const has = ch === 'sms' ? l.consent.sms : ch === 'email' ? l.consent.email : false
  if (!has) return { ok: false, reason: `No ${ch.toUpperCase()} consent on file` }
  if (ch === 'sms' && quietNow(s)) return { ok: false, reason: `Quiet hours (${s.quietStart}–${s.quietEnd})` }
  if (l.autoSentToday >= s.freqCap) return { ok: false, reason: `Frequency cap reached (${s.freqCap}/day)` }
  return { ok: true, reason: 'Consent on file · within quiet-hour and frequency rules' }
}

export const dealMissing = (d: Deal) => d.docs.filter((x) => x.applicable && x.status === 'missing')
export const dealBlocked = (d: Deal) => dealMissing(d).length > 0 || d.waitingDays >= 3

export function attention(s: DataState) {
  const vs = activeVehicles(s)
  return {
    missed: s.leads.filter((l) => l.missed && !l.consent.stopped),
    missingDocs: s.deals.filter((d) => dealMissing(d).length > 0),
    listing: vs.filter((v) => vehicleIssues(v, s.vehicles).length > 0),
    approvals: s.leads.filter((l) => !!l.draft),
    callbacks: s.leads.filter((l) => l.callbackRequested),
  }
}

export function metrics(s: DataState) {
  const dayAgo = toMs(s.now) - 24 * 3600000
  const inbound = s.leads.filter((l) => toMs(l.createdAt) >= dayAgo && toMs(l.createdAt) <= toMs(s.now)).length
  const times: number[] = []
  for (const l of s.leads) {
    const c = l.messages.find((m) => m.from === 'customer')
    const r = l.messages.find((m) => (m.from === 'ai' || m.from === 'staff') && m.status === 'sent-demo')
    if (c && r) times.push(Math.max(1, (toMs(r.at) - toMs(c.at)) / 60000))
  }
  const avg = times.length ? times.reduce((a, b) => a + b, 0) / times.length : 0
  const appts = s.appointments.filter((a) => a.status !== 'no-show' && a.kind !== 'Delivery').length
  const blockers = s.deals.filter(dealBlocked).length
  return { inbound, avgResponse: avg, responded: times.length, appts, blockers }
}

export const fmtMinutes = (m: number) => (m < 60 ? `${Math.round(m)} min` : `${Math.floor(m / 60)}h ${Math.round(m % 60)}m`)

export const hoursText = (h: Hours) =>
  [1, 2, 3, 4, 5, 6, 0]
    .map((d) => `${DOW_NAMES[d].slice(0, 3)} ${h[d] ? `${to12(h[d]!.open)}–${to12(h[d]!.close)}` : 'Closed'}`)
    .join(' · ')

export const to12 = (hhmm: string) => {
  const [h, m] = hhmm.split(':').map(Number)
  const ap = h >= 12 ? 'PM' : 'AM'
  const hh = h % 12 || 12
  return m ? `${hh}:${String(m).padStart(2, '0')} ${ap}` : `${hh} ${ap}`
}

// ---------- Factual description generator (only verified fields) ----------
export function factualDescription(v: Vehicle) {
  const listed = v.description.match(/Dealer record lists ([^.]+)\./i)?.[1]
  const parts = [
    `${v.year} ${v.make} ${v.model} ${v.trim} in ${v.color}.`,
    `${v.engine} with ${v.transmission}, ${v.drivetrain}.`,
    v.mileage != null ? `${v.mileage.toLocaleString('en-US')} miles (staff-verified odometer entry).` : '',
    v.mpg ? `EPA-estimated ${v.mpg.replace(' (EPA est.)', '')} when new.` : '',
    listed ? `Equipment listed in dealer record: ${listed}.` : '',
    `Stock ${v.stock}. Contact us to confirm availability and schedule a test drive.`,
  ]
  return parts.filter(Boolean).join(' ')
}

export const EXCLUDED_CLAIMS = ['Accident / damage history', 'Number of owners', 'Mechanical condition', 'Inspection results', 'Warranty coverage', 'Financing terms']

// ---------- Deterministic "AI" document check ----------
export function checkDocText(text: string) {
  const findings: { severity: 'high' | 'med' | 'low'; text: string; doc: string }[] = []
  const lines = text.split('\n')
  for (const ln of lines) {
    if (/^Buyer signature:/i.test(ln) && /_{4,}/.test(ln)) findings.push({ severity: 'high', text: 'Buyer signature line appears blank on the buyer’s order.', doc: 'buyers_order' })
    if (/Odometer reading/i.test(ln) && /_{4,}/.test(ln)) findings.push({ severity: 'high', text: 'Odometer reading appears blank.', doc: 'odometer' })
    if (/Deal #:\s*_{3,}/.test(ln)) findings.push({ severity: 'low', text: 'Deal number field is blank on the sample text (cross-reference DMS).', doc: 'buyers_order' })
  }
  return findings
}

// ---------- AI Buyer Concierge: answers ONLY from demo inventory fields ----------
export interface ConciergeCtx {
  vehicles: Vehicle[]
  offHours: boolean
  slots: Wall[]
  first: boolean
  vehicleId: string | null
  hours: Hours
  sms?: boolean
}
export interface ConciergeOut {
  text: string
  vehicleId: string | null
  intents: string[]
  handoff: boolean
  optOut: boolean
  offeredSlots: Wall[]
}

const FEATURE_WORDS = ['sunroof', 'carplay', 'android auto', 'heated', 'camera', 'navigation', 'tow', 'remote start', 'leather', 'bluetooth', 'blind-spot', 'liftgate', 'hardtop']

export function matchVehicle(q: string, vehicles: Vehicle[]): Vehicle | null {
  const s = q.toLowerCase()
  const pool = vehicles.filter((v) => !v.archived && !v.duplicateOf)
  const stock = s.match(/d24\d\d/)
  if (stock) return pool.find((v) => v.stock.toLowerCase() === stock[0]) || null
  let best: Vehicle | null = null
  let bestScore = 0
  for (const v of pool) {
    let sc = 0
    const model = v.model.toLowerCase().replace('-', '')
    const sNorm = s.replace(/-/g, '')
    if (sNorm.includes(model.split(' ')[0])) sc += 3
    if (s.includes(v.make.toLowerCase().split('-')[0])) sc += 1
    if (s.includes(String(v.year))) sc += 1
    if (s.includes(v.color.toLowerCase().split(' ')[0])) sc += 1
    if (s.includes('white') && /white/i.test(v.color)) sc += 1
    if (sc > bestScore) {
      best = v
      bestScore = sc
    }
  }
  return bestScore >= 3 ? best : null
}

export function conciergeReply(q: string, ctx: ConciergeCtx): ConciergeOut {
  const s = q.toLowerCase()
  const out: string[] = []
  const intents: string[] = []
  let handoff = false
  let optOut = false
  let offered: Wall[] = []

  if (/\b(stop|unsubscribe|opt ?out)\b/.test(s)) {
    return { text: 'You’re opted out and won’t receive automated messages. Reply START anytime to opt back in.', vehicleId: ctx.vehicleId, intents: ['opt-out'], handoff: false, optOut: true, offeredSlots: [] }
  }

  const matched = matchVehicle(q, ctx.vehicles)
  const v = matched || ctx.vehicles.find((x) => x.id === ctx.vehicleId) || null

  if (ctx.first) out.push('Hi! I’m the Superior Auto Mall virtual assistant (AI).')
  if (ctx.offHours && ctx.first) out.push('We’re closed right now, but I can help and a team member will follow up when we open.')

  if (/(person|human|someone real|agent|representative|talk to|call me)/.test(s)) {
    handoff = true
    intents.push('handoff')
    out.push('Of course — I’ve asked a team member to reach out to you' + (ctx.offHours ? ' when we open.' : ' shortly.'))
  }

  const bodyAsk = s.match(/\b(trucks?|suvs?|sedans?|hatchbacks?)\b/)
  if (!v && bodyAsk) {
    const want = bodyAsk[1].replace(/s$/, '')
    const map: Record<string, string> = { truck: 'Truck', suv: 'SUV', sedan: 'Sedan', hatchback: 'Hatchback' }
    const list = ctx.vehicles.filter((x) => !x.archived && !x.duplicateOf && x.status === 'available' && x.body === map[want]).slice(0, 3)
    intents.push('browse')
    out.push(list.length ? `Our demo inventory lists: ${list.map((x) => `${x.year} ${x.make} ${x.model} (${priceLabel(x)})`).join('; ')}. Staff will confirm what’s on the lot.` : `I don’t see a listed ${want} right now.`)
  }

  if (v) {
    const name = `${v.year} ${v.make} ${v.model}`
    if (/(available|still there|in stock|have (the|that|it)|sold|still for sale)/.test(s)) {
      intents.push('availability')
      if (v.status === 'available') out.push(`Our record shows the ${name} as listed — staff will confirm it’s still on the lot before your visit.`)
      else if (v.status === 'pending') out.push(`Our record shows a pending sale on the ${name}. A team member can tell you if that changes.`)
      else if (v.status === 'sold') out.push(`Our record shows the ${name} as sold.`)
      else out.push(`I can’t confirm availability on the ${name} from our records — a team member will verify.`)
    }
    if (/(price|cost|how much|\$|out the door|otd|best deal)/.test(s)) {
      intents.push('price')
      out.push(v.price == null ? `The listing shows “Please Call” for price — a team member will confirm the current price.` : `The listed price is ${money(v.price)}, before tax, tag, title and any dealer fees — staff can confirm the full itemized total.`)
    }
    if (/(mile|odometer)/.test(s)) {
      intents.push('mileage')
      out.push(v.mileage == null ? `Mileage isn’t listed in our record yet — staff will verify the odometer.` : `Our record shows ${v.mileage.toLocaleString('en-US')} miles.`)
    }
    if (/(awd|4wd|all.wheel|4x4|four wheel|fwd|rwd|drivetrain)/.test(s)) { intents.push('drivetrain'); out.push(`The record lists ${v.drivetrain}${v.dmsTrim && v.dmsTrim !== v.trim ? ', but our systems disagree on trim — staff will verify before you visit' : ''}.`) }
    if (/(engine|motor|v6|v8|cylinder|transmission)/.test(s)) { intents.push('engine'); out.push(`It has a ${v.engine} with a ${v.transmission}.`) }
    if (/(mpg|gas|fuel|economy)/.test(s)) { intents.push('mpg'); out.push(v.mpg ? `EPA estimate when new: ${v.mpg.replace(' (EPA est.)', '')}.` : 'Fuel economy isn’t in our record — staff can check.') }
    if (/(colou?r)/.test(s)) { intents.push('color'); out.push(`It’s listed as ${v.color}.`) }
    const feat = FEATURE_WORDS.find((f) => s.includes(f))
    if (feat) {
      intents.push('feature')
      out.push(v.description.toLowerCase().includes(feat) ? `The dealer record lists ${feat}. Staff can show you in person.` : `${feat[0].toUpperCase() + feat.slice(1)} isn’t listed in our record — staff will verify.`)
    }
  }

  if (/(financ|credit|loan|apr|interest|monthly|payment|down payment|approved|approval)/.test(s)) {
    intents.push('financing')
    out.push('I can’t check financing eligibility or quote rates or payments. A team member can go over options with you.')
  }
  if (/(warrant|guarantee)/.test(s)) { intents.push('warranty'); out.push('I don’t have warranty details in our records — staff must verify what applies.') }
  if (/(accident|carfax|autocheck|history|condition|clean title|owners?\b|damage|flood|inspect|mechanic|problem|issues?)/.test(s)) {
    intents.push('history')
    out.push('I don’t have verified history or condition details. Staff can show available documentation, and you’re welcome to arrange an independent inspection.')
  }
  if (/\btrade/.test(s)) { intents.push('trade'); out.push('We can look at your trade in person — I can’t estimate its value here.') }
  if (/(hours|open|close|closing)/.test(s) && !/(open (to|for))/.test(s)) { intents.push('hours'); out.push(`Hours: ${hoursText(ctx.hours)} (Eastern).`) }

  const wantsVisit = /(test drive|see it|see the|come (by|in)|stop by|visit|appointment|look at|saturday|sunday|tomorrow|today|this week)/.test(s)
  if (wantsVisit || (ctx.offHours && ctx.first && !handoff)) {
    intents.push('visit')
    offered = ctx.slots.slice(0, 3)
    if (offered.length) out.push(`Next open test-drive times: ${offered.map((w) => `${fmtDay(w)} ${fmtTime(w)}`).join(', ')}. Want me to hold one?`)
  }

  if (out.length <= (ctx.first ? (ctx.offHours ? 2 : 1) : 0)) {
    if (v) out.push(`The ${v.year} ${v.make} ${v.model} ${v.trim}: ${priceLabel(v)}, ${milesLabel(v)}, ${v.drivetrain}. What would you like to know?`)
    else out.push('Which vehicle are you interested in? You can mention the make, model, or stock number.')
  }
  if (ctx.first && ctx.sms) out.push('Reply STOP to opt out.')

  return { text: out.join(' '), vehicleId: v?.id ?? ctx.vehicleId, intents, handoff, optOut, offeredSlots: offered }
}

export function roiCalc(r: DataState['roi'], adoptionMult = 1) {
  const adopt = Math.min(1, (r.adoption / 100) * adoptionMult)
  const rows = [
    { key: 'Lead response', hours: r.hLeads, pct: r.pLeads },
    { key: 'Scheduling', hours: r.hScheduling, pct: r.pScheduling },
    { key: 'Listings upkeep', hours: r.hListings, pct: r.pListings },
    { key: 'Paperwork follow-up', hours: r.hPaperwork, pct: r.pPaperwork },
  ].map((x) => ({ ...x, saved: x.hours * (x.pct / 100) * adopt }))
  const weekly = rows.reduce((s, x) => s + x.saved, 0)
  const totalWeekly = rows.reduce((s, x) => s + x.hours, 0)
  const monthly = weekly * 4.33
  const loaded = r.hourly * (1 + r.burden / 100)
  const value = monthly * loaded
  const net = value - r.fee
  const fte = monthly / 173
  return { rows, weekly, totalWeekly, monthly, loaded, value, net, fte, adopt }
}

export const slugOf = (v: Vehicle) => `${v.year}-${v.make}-${v.model}-${v.stock}`.toLowerCase().replace(/[^a-z0-9]+/g, '-')

export const isPublic = (v: Vehicle) => !v.archived && v.listing === 'published' && v.status !== 'sold'
export const publicVehicles = (s: DataState) => s.vehicles.filter(isPublic)

export function advertised(v: Vehicle, d: Dealer): { amount: number | null; note: string } {
  if (v.price == null) return { amount: null, note: 'Price not posted yet — the dealer will confirm it for you.' }
  if (d.dealerFee == null) return { amount: v.price, note: 'Plus tax, tag & title. Any dealer-required fees: confirm with dealer (fee not set in this demo).' }
  return { amount: v.price + d.dealerFee, note: `Includes $${d.dealerFee.toLocaleString('en-US')} dealer fee. Plus government tax, tag & title.` }
}

export const statusLabel = (v: Vehicle) => (v.status === 'available' ? 'Available' : v.status === 'pending' ? 'Sale pending' : v.status === 'sold' ? 'Sold' : 'Confirm availability')
