import type { Appointment, Hours, Wall } from './types'

// All demo times are Eastern Time wall-clock strings. Arithmetic is done in UTC so
// results are deterministic regardless of the viewer's own time zone.

export const toMs = (w: Wall) => {
  const [d, t] = w.split('T')
  const [y, m, day] = d.split('-').map(Number)
  const [hh, mm] = t.split(':').map(Number)
  return Date.UTC(y, m - 1, day, hh, mm)
}
export const fromMs = (ms: number): Wall => new Date(ms).toISOString().slice(0, 16)
export const addMin = (w: Wall, m: number) => fromMs(toMs(w) + m * 60000)
export const dow = (w: Wall) => new Date(toMs(w)).getUTCDay()
export const minutesOfDay = (w: Wall) => {
  const [hh, mm] = w.split('T')[1].split(':').map(Number)
  return hh * 60 + mm
}
export const dateOf = (w: Wall) => w.split('T')[0]
export const atTime = (w: Wall, hhmm: string): Wall => `${dateOf(w)}T${hhmm}`
const hm = (s: string) => {
  const [h, m] = s.split(':').map(Number)
  return h * 60 + m
}

export const fmtTime = (w: Wall) =>
  new Date(toMs(w)).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit', timeZone: 'UTC' })
export const fmtDay = (w: Wall) =>
  new Date(toMs(w)).toLocaleDateString('en-US', { weekday: 'short', month: 'short', day: 'numeric', timeZone: 'UTC' })
export const fmtDayLong = (w: Wall) =>
  new Date(toMs(w)).toLocaleDateString('en-US', { weekday: 'long', month: 'long', day: 'numeric', timeZone: 'UTC' })
export const fmtWhen = (w: Wall, now: Wall) => {
  if (dateOf(w) === dateOf(now)) return `Today ${fmtTime(w)}`
  if (dateOf(w) === dateOf(addMin(now, 1440))) return `Tomorrow ${fmtTime(w)}`
  if (dateOf(w) === dateOf(addMin(now, -1440))) return `Yesterday ${fmtTime(w)}`
  return `${fmtDay(w)} ${fmtTime(w)}`
}
export const ago = (w: Wall, now: Wall) => {
  const m = Math.round((toMs(now) - toMs(w)) / 60000)
  if (m < 1) return 'just now'
  if (m < 60) return `${m}m ago`
  if (m < 1440) return `${Math.floor(m / 60)}h ${m % 60 ? (m % 60) + 'm ' : ''}ago`
  return `${Math.floor(m / 1440)}d ago`
}

export const mondayOfThisWeek = (): string => {
  const d = new Date()
  const day = d.getDay()
  const diff = (day + 6) % 7
  d.setDate(d.getDate() - diff)
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const dd = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${dd}`
}

export const DOW_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday']

export const isOpen = (w: Wall, hours: Hours) => {
  const h = hours[dow(w)]
  if (!h) return false
  const m = minutesOfDay(w)
  return m >= hm(h.open) && m < hm(h.close)
}

export const inQuiet = (w: Wall, start: string, end: string) => {
  const m = minutesOfDay(w)
  const s = hm(start)
  const e = hm(end)
  return s > e ? m >= s || m < e : m >= s && m < e
}

export const nextSlots = (now: Wall, hours: Hours, appts: Appointment[], n = 3, dur = 60): Wall[] => {
  const out: Wall[] = []
  let t = toMs(now) + 60 * 60000
  t = Math.ceil(t / (30 * 60000)) * 30 * 60000
  const limit = toMs(now) + 8 * 1440 * 60000
  while (out.length < n && t < limit) {
    const w = fromMs(t)
    const h = hours[dow(w)]
    if (h) {
      const m = minutesOfDay(w)
      if (m >= hm(h.open) && m + dur <= hm(h.close)) {
        const clash = appts.some((a) => {
          const s = toMs(a.start)
          const e = s + a.duration * 60000
          return t < e && t + dur * 60000 > s && a.status !== 'no-show'
        })
        if (!clash) {
          out.push(w)
          t += 90 * 60000 // spread suggestions out
          continue
        }
      }
    }
    t += 30 * 60000
  }
  return out
}
