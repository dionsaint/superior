import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react'
import type { DataState, Role, ScreenId } from './types'
import { DATA_VERSION, seedState } from './data'

const KEY = 'superior-command-ai-demo'

export interface Toast {
  id: number
  text: string
  kind: 'demo' | 'ok' | 'warn' | 'info'
}

export interface Ctx {
  toast: (text: string, kind?: Toast['kind']) => void
}

export interface UiState {
  route: string
  screen: ScreenId
  leadId: string | null
  vehicleId: string | null
  dealId: string | null
  proposal: boolean
  tourOpen: boolean
  scenarioPicker: boolean
  mobileMenu: boolean
  split: boolean
  chatOpen: boolean
}

interface StoreValue {
  s: DataState
  act: (fn: (s: DataState, ctx: Ctx) => void) => void
  toast: (text: string, kind?: Toast['kind']) => void
  toasts: Toast[]
  dismiss: (id: number) => void
  ui: UiState
  setUi: (p: Partial<UiState>) => void
  nav: (screen: ScreenId, id?: string) => void
  go: (path: string) => void
  reset: () => void
  can: (perm: Perm) => boolean
  get: () => DataState
}

export type Perm =
  | 'view:roi'
  | 'view:settings'
  | 'view:deals'
  | 'approve:listing'
  | 'approve:doc'
  | 'approve:lead'
  | 'edit:rules'
  | 'view:inventory'

const PERMS: Record<Role, Perm[]> = {
  owner: ['view:roi', 'view:settings', 'view:deals', 'approve:listing', 'approve:doc', 'approve:lead', 'edit:rules', 'view:inventory'],
  sales: ['approve:lead', 'view:inventory', 'view:deals'],
  admin: ['view:deals', 'approve:doc', 'view:inventory', 'view:settings', 'approve:listing'],
  inventory: ['view:inventory', 'approve:listing'],
}

const load = (): DataState => {
  try {
    const raw = localStorage.getItem(KEY)
    if (raw) {
      const p = JSON.parse(raw) as DataState
      if (p.version === DATA_VERSION) return p
    }
  } catch {
    /* storage unavailable — fall back to seed */
  }
  return seedState()
}

const StoreCtx = createContext<StoreValue | null>(null)

const STAFF: ScreenId[] = ['dashboard', 'leads', 'listings', 'deals', 'calendar', 'frontdesk', 'roi', 'settings']
const routeFromHash = () => (typeof location !== 'undefined' && location.hash.startsWith('#/') ? location.hash.slice(1) : '/')
const screenOf = (route: string): ScreenId => {
  const seg = route.split('/')[2] as ScreenId
  return STAFF.includes(seg) ? seg : 'dashboard'
}

export function StoreProvider({ children }: { children: React.ReactNode }) {
  const [s, setS] = useState<DataState>(load)
  const [toasts, setToasts] = useState<Toast[]>([])
  const [ui, setUiState] = useState<UiState>({ route: routeFromHash(), screen: screenOf(routeFromHash()), split: false, chatOpen: false, leadId: null, vehicleId: null, dealId: null, proposal: false, tourOpen: false, scenarioPicker: false, mobileMenu: false })
  const tid = useRef(1)
  const ref = useRef(s)

  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(s))
    } catch {
      /* ignore */
    }
  }, [s])

  useEffect(() => {
    const on = () => setUiState((u) => ({ ...u, route: routeFromHash(), screen: screenOf(routeFromHash()) }))
    window.addEventListener('hashchange', on)
    window.addEventListener('popstate', on)
    return () => {
      window.removeEventListener('hashchange', on)
      window.removeEventListener('popstate', on)
    }
  }, [])

  const dismiss = useCallback((id: number) => setToasts((t) => t.filter((x) => x.id !== id)), [])
  const toast = useCallback(
    (text: string, kind: Toast['kind'] = 'info') => {
      const id = tid.current++
      setToasts((t) => [...t.slice(-3), { id, text, kind }])
      setTimeout(() => dismiss(id), kind === 'demo' ? 5200 : 4000)
    },
    [dismiss],
  )

  const act = useCallback(
    (fn: (s: DataState, ctx: Ctx) => void) => {
      const pending: [string, Toast['kind']][] = []
      const next = structuredClone(ref.current)
      fn(next, { toast: (t, k = 'info') => pending.push([t, k]) })
      ref.current = next
      setS(next)
      pending.forEach(([t, k]) => toast(t, k))
    },
    [toast],
  )

  const setUi = useCallback((p: Partial<UiState>) => setUiState((u) => ({ ...u, ...p })), [])

  const go = useCallback((path: string) => {
    setUiState((u) => ({ ...u, route: path, screen: screenOf(path), mobileMenu: false, chatOpen: path.startsWith('/staff') ? false : u.chatOpen }))
    if (location.hash !== `#${path}`) history.pushState(null, '', `#${path}`)
    window.scrollTo({ top: 0 })
  }, [])

  const nav = useCallback(
    (screen: ScreenId, id?: string) => {
      setUiState((u) => {
        const next: UiState = { ...u }
        if (id) {
          if (screen === 'leads') next.leadId = id
          if (screen === 'listings') next.vehicleId = id
          if (screen === 'deals') next.dealId = id
        }
        return next
      })
      go(`/staff/${screen}`)
    },
    [go],
  )

  const reset = useCallback(() => {
    const fresh = seedState()
    ref.current = fresh
    setS(fresh)
    setUiState((u) => ({ ...u, leadId: null, vehicleId: null, dealId: null, proposal: false }))
    toast('Demo reset to the original sample data.', 'ok')
  }, [toast])

  const can = useCallback((p: Perm) => PERMS[s.role].includes(p), [s.role])
  const get = useCallback(() => ref.current, [])

  return <StoreCtx.Provider value={{ s, act, toast, toasts, dismiss, ui, setUi, nav, reset, can, get, go }}>{children}</StoreCtx.Provider>
}

export const useStore = () => {
  const v = useContext(StoreCtx)
  if (!v) throw new Error('StoreProvider missing')
  return v
}

export const ROLE_LABEL: Record<Role, string> = { owner: 'Owner', sales: 'Salesperson', admin: 'Admin / Title', inventory: 'Inventory' }
