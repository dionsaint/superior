import React, { createContext, useCallback, useContext, useEffect, useRef, useState } from 'react'
import { ArrowLeft, ArrowRight, Calculator, Car, CheckCircle2, Clock, FileText, Globe, Moon, PhoneMissed, PlayCircle, RotateCcw, Sparkles, Sun, UserCheck, X, Zap } from 'lucide-react'
import { useStore, type Toast } from './store'
import type { DataState } from './types'
import { approveDocRequest, approveDraft, draftReply, runDocCheck, simulateLead, simulateMissedCall, addPhotos } from './actions'
import { slugOf } from './logic'
import { dateOf } from './time'
import { Btn, Modal, cx } from './ui'

// ------------------------------------------------------------------ types
type Api = ReturnType<typeof useStore>
interface Step {
  title: string
  body: React.ReactNode
  route?: string | ((s: DataState) => string)
  target?: string
  setup?: (api: Api) => void
  cta?: { label: string; run: (api: Api) => void }
}
interface Scenario {
  id: string
  title: string
  plain: string
  icon: React.ElementType
  steps: Step[]
}

const click = (t: string) => setTimeout(() => (document.querySelector(`[data-tour="${t}"]`) as HTMLButtonElement | null)?.click(), 60)
const slugById = (s: DataState, id: string) => slugOf(s.vehicles.find((v) => v.id === id)!)
const newest = (s: DataState) => s.leads[0]?.id

// ------------------------------------------------------------------ scenarios
export const SCENARIOS: Scenario[] = [
  {
    id: 'web-lead',
    title: '1 · Website shopper at 8:45 PM',
    plain: 'A shopper browses after closing, asks the AI about a car and requests a test drive. Watch it land in the staff inbox.',
    icon: Globe,
    steps: [
      {
        title: 'It’s 8:45 PM — the dealership is closed',
        body: 'We set the demo clock to tonight. A shopper opens the customer website on their phone. Everything they see comes from the same car records your staff manage.',
        route: '/',
        target: 'shop-cars',
        setup: ({ act }) => act((s) => { s.now = `${dateOf(s.now)}T20:45`; s.offHoursOverride = 'auto' }),
      },
      { title: 'They search the cars', body: 'Search, filters, sort and compare all work. Sold cars never show here, and drafts stay hidden until staff publish them.', route: '/inventory', target: 'inv-search' },
      { title: 'They open the 2019 Camry', body: 'Price, mileage and photos come straight from the staff record. If something is missing, the site says "Confirm with dealer" instead of guessing.', route: (s) => `/inventory/${slugById(s, 'v01')}`, target: 'vdp-price' },
      {
        title: 'They ask the AI a question',
        body: 'The assistant says it’s an AI, answers only from the car’s record, and — because it’s after hours — offers the next open test-drive times.',
        target: 'chat',
        setup: ({ setUi }) => {
          setUi({ chatOpen: true })
          setTimeout(() => window.dispatchEvent(new CustomEvent('demo-chat-ask', { detail: 'Is the Camry still available? What are the miles? Could I test drive it?' })), 350)
        },
      },
      {
        title: 'They pick a time and leave their name',
        body: 'We filled in a made-up shopper for you. Press the button to send the request (nothing real is sent).',
        target: 'chat-confirm',
        setup: () => setTimeout(() => window.dispatchEvent(new CustomEvent('demo-chat-pick')), 300),
        cta: { label: 'Send the request', run: () => click('chat-confirm') },
      },
      {
        title: 'It arrives in the staff inbox — instantly',
        body: 'The request is assigned to a salesperson automatically. The AI wrote a short, factual reply — but a person must press Approve before anything goes out.',
        route: '/staff/leads',
        target: 'lead-detail',
        setup: ({ act, setUi, get }) => {
          const id = newest(get())
          setUi({ leadId: id, chatOpen: false })
          if (id && !get().leads[0].draft) act((s, c) => draftReply(s, c, id))
        },
      },
      { title: 'The time is on the calendar', body: 'The requested slot shows as a "hold" so staff can confirm it in the morning. No double-booking.', route: '/staff/calendar', target: 'calendar' },
    ],
  },
  {
    id: 'missed-call',
    title: '2 · A missed call',
    plain: 'A call comes in while everyone is busy. The system catches it and drafts a callback text for the manager to approve.',
    icon: PhoneMissed,
    steps: [
      {
        title: 'Nobody could pick up',
        body: 'The missed call and voicemail are captured as a new customer, with a callback text already drafted. The caller asked to be texted, so that’s noted as consent (staff should still verify).',
        route: '/staff/leads',
        target: 'lead-detail',
        setup: ({ act, setUi, get }) => {
          act((s, c) => { simulateMissedCall(s, c) })
          setUi({ leadId: newest(get()) })
        },
      },
      {
        title: 'The manager approves the text',
        body: 'One click. In this demo nothing is actually sent — you’ll see a "DEMO — no real message sent" note, and it’s written to the activity log.',
        target: 'approve',
        cta: { label: 'Approve callback text', run: ({ act, get }) => act((s, c) => approveDraft(s, c, newest(get()))) },
      },
      { title: 'The owner’s list updates', body: 'The "Needs attention" list on the owner dashboard counts down as things get handled.', route: '/staff/dashboard', target: 'attention' },
    ],
  },
  {
    id: 'listing',
    title: '3 · Fix a listing → website updates',
    plain: 'A car shows "Please Call" and no mileage. Staff fix it side-by-side, approve, and the public page changes immediately.',
    icon: Car,
    steps: [
      { title: 'What shoppers see today', body: 'The 2017 Nissan Rogue shows "Call for price" and no mileage. Shoppers often skip listings like this.', route: (s) => `/inventory/${slugById(s, 'v03')}`, target: 'vdp-price' },
      {
        title: 'Staff open the car — side by side',
        body: 'One side is the edit form, the other is a live preview of the customer page (on a phone they stack). The health score shows what’s missing.',
        route: '/staff/listings',
        target: 'field-price',
        setup: ({ setUi, act }) => { act((s) => { s.role = 'owner' }); setUi({ vehicleId: 'v03', split: true }) },
      },
      {
        title: 'Type in the verified price and mileage',
        body: 'Staff read the odometer on the car and confirm the price. (We’ll type sample numbers for you.) The preview updates as you type.',
        target: 'field-miles',
        cta: { label: 'Type verified values', run: () => window.dispatchEvent(new CustomEvent('demo-fill', { detail: { price: 12995, mileage: 88410 } })) },
      },
      {
        title: 'Approve the change',
        body: 'Approving updates the website right away and queues the same change for Dealer Car Search / your DMS. Nothing is actually sent in the demo.',
        target: 'approve-listing',
        cta: { label: 'Approve changes', run: () => click('approve-listing') },
      },
      {
        title: 'Add photos (optional)',
        body: 'Photos can be added and re-ordered. In the demo these are labeled sample slots — real lot photos go here.',
        target: 'add-photos',
        cta: { label: 'Add sample photos', run: ({ act }) => act((s, c) => addPhotos(s, c, 'v03', Array.from({ length: 4 }, () => undefined))) },
      },
      { title: 'The customer page changed', body: 'Same car, now with a real price and mileage. The fix took seconds and the change is logged.', route: (s) => `/inventory/${slugById(s, 'v03')}`, target: 'vdp-price', setup: ({ setUi }) => setUi({ split: false, vehicleId: null }) },
    ],
  },
  {
    id: 'deal',
    title: '4 · Sold deal missing a signature',
    plain: 'A deal was marked "ready for delivery," but the AI notices the buyer never signed. A task opens and a person approves the customer message.',
    icon: FileText,
    steps: [
      { title: 'Deal #1042 looks ready', body: 'Staff marked it "Delivery ready." Every box on the checklist says done.', route: '/staff/deals', target: 'deal-d1', setup: ({ setUi, act }) => { act((s) => { s.role = 'owner' }); setUi({ dealId: 'd1' }) } },
      {
        title: 'Run the AI document check',
        body: 'The AI reads the (made-up) buyer’s order text and spots a blank buyer signature. It moves the deal back, creates a task for Admin/Title, and drafts a polite request. It never signs, files, or decides anything legal.',
        target: 'ai-check',
        cta: { label: 'Run document check', run: ({ act }) => act((s, c) => { runDocCheck(s, c, 'd1') }) },
      },
      {
        title: 'A person approves the request',
        body: 'Any message about documents needs human approval. Nothing is sent in the demo.',
        target: 'approve-doc',
        cta: { label: 'Approve request', run: ({ act }) => act((s, c) => approveDocRequest(s, c, 'd1')) },
      },
    ],
  },
  {
    id: 'roi',
    title: '5 · Owner adjusts the numbers',
    plain: 'Change staff count, pay and adoption. See hours freed and the pilot scorecard update — without promising layoffs.',
    icon: Calculator,
    steps: [
      {
        title: 'Your numbers, your assumptions',
        body: 'Every number here is an editable estimate. We’ll change it to 3 staff at $24/hour with 60% of the routine work handled by the system.',
        route: '/staff/roi',
        target: 'roi-inputs',
        setup: ({ act }) => act((s) => { s.role = 'owner' }),
        cta: { label: 'Change the assumptions', run: ({ act }) => act((s, c) => { s.roi.employees = 3; s.roi.hourly = 24; s.roi.adoption = 60; c.toast('Assumptions updated — results recalculated.', 'ok') }) },
      },
      { title: 'Time freed — not jobs cut', body: 'This shows hours of routine work your team gets back. Payroll only changes if you decide to change shifts or overtime.', target: 'roi-results' },
      { title: 'Prove it with a pilot', body: 'The scorecard tracks real before/after numbers during a 2–4 week trial. You can print a one-page proposal.', target: 'scorecard', cta: { label: 'Open pilot proposal', run: ({ setUi }) => setUi({ proposal: true }) } },
    ],
  },
]

// ------------------------------------------------------------------ context
interface TourState { queue: string[]; si: number; step: number }
const TourCtx = createContext<{ tour: TourState | null; start: (ids: string[]) => void; stop: () => void; next: () => void; back: () => void } | null>(null)
export const useTour = () => useContext(TourCtx)!

export function TourProvider({ children }: { children: React.ReactNode }) {
  const api = useStore()
  const [tour, setTour] = useState<TourState | null>(null)
  const ran = useRef(new Set<string>())
  const apiRef = useRef(api)
  apiRef.current = api

  const enter = useCallback((t: TourState) => {
    const sc = SCENARIOS.find((x) => x.id === t.queue[t.si])!
    const st = sc.steps[t.step]
    const a = apiRef.current
    if (st.route) {
      const r = typeof st.route === 'function' ? st.route(a.get()) : st.route
      if (a.ui.route !== r) a.go(r)
    }
    const key = `${sc.id}:${t.step}`
    if (st.setup && !ran.current.has(key)) {
      ran.current.add(key)
      setTimeout(() => st.setup!(apiRef.current), 120)
    }
  }, [])

  const start = useCallback((ids: string[]) => {
    ran.current = new Set()
    const t = { queue: ids, si: 0, step: 0 }
    apiRef.current.setUi({ scenarioPicker: false, mobileMenu: false })
    setTour(t)
    setTimeout(() => enter(t), 50)
  }, [enter])

  const stop = useCallback(() => setTour(null), [])
  const move = useCallback((d: 1 | -1) => {
    setTour((t) => {
      if (!t) return t
      let { si, step } = t
      const sc = SCENARIOS.find((x) => x.id === t.queue[si])!
      step += d
      if (step >= sc.steps.length) {
        if (si + 1 >= t.queue.length) {
          apiRef.current.toast('Guided demo finished. Everything you saw is still here to click around.', 'ok')
          return null
        }
        si++
        step = 0
      } else if (step < 0) {
        if (si === 0) return t
        si--
        step = SCENARIOS.find((x) => x.id === t.queue[si])!.steps.length - 1
      }
      const nt = { ...t, si, step }
      setTimeout(() => enter(nt), 30)
      return nt
    })
  }, [enter])

  return <TourCtx.Provider value={{ tour, start, stop, next: () => move(1), back: () => move(-1) }}>{children}</TourCtx.Provider>
}

// ------------------------------------------------------------------ overlay
function useTargetRect(target?: string, dep?: unknown) {
  const [r, setR] = useState<DOMRect | null>(null)
  useEffect(() => {
    if (!target) { setR(null); return }
    let scrolled = false
    const tick = () => {
      const el = document.querySelector(`[data-tour="${target}"]`) as HTMLElement | null
      if (!el) { setR(null); return }
      if (!scrolled) { el.scrollIntoView({ behavior: 'smooth', block: 'center' }); scrolled = true }
      setR(el.getBoundingClientRect())
    }
    tick()
    const iv = setInterval(tick, 250)
    return () => clearInterval(iv)
  }, [target, dep])
  return r
}

export function TourOverlay() {
  const t = useTour()
  const api = useStore()
  const sc = t.tour ? SCENARIOS.find((x) => x.id === t.tour!.queue[t.tour!.si]) : null
  const st = sc?.steps[t.tour!.step]
  const rect = useTargetRect(st?.target, `${t.tour?.si}-${t.tour?.step}`)
  if (!t.tour || !sc || !st) return null
  const total = t.tour.queue.reduce((n, id) => n + SCENARIOS.find((x) => x.id === id)!.steps.length, 0)
  const doneBefore = t.tour.queue.slice(0, t.tour.si).reduce((n, id) => n + SCENARIOS.find((x) => x.id === id)!.steps.length, 0)
  const idx = doneBefore + t.tour.step + 1
  return (
    <>
      {rect && rect.width > 0 && (
        <div className="tour-ring pointer-events-none fixed z-[80] rounded-xl border-[3px] border-brand-600 transition-all duration-200" style={{ top: rect.top - 6, left: rect.left - 6, width: rect.width + 12, height: rect.height + 12 }} />
      )}
      <div className="rise fixed inset-x-2 bottom-2 z-[90] rounded-2xl border border-silver-200 bg-white p-4 shadow-2xl sm:inset-x-auto sm:bottom-4 sm:left-4 sm:w-[390px]" role="dialog" aria-label="Guided demo">
        <div className="mb-2 flex items-center justify-between">
          <div className="text-[11px] font-bold uppercase tracking-wider text-brand-600">{sc.title}</div>
          <button onClick={t.stop} className="rounded-lg p-1 text-ink-400 hover:bg-silver-100" aria-label="End tour"><X className="h-4 w-4" /></button>
        </div>
        <h3 className="text-[16px] font-extrabold leading-snug">{st.title}</h3>
        <p className="mt-1.5 text-[13.5px] leading-relaxed text-ink-700">{st.body}</p>
        {st.cta && (
          <Btn variant="primary" size="sm" className="mt-3 w-full" icon={<Sparkles className="h-4 w-4" />} onClick={() => st.cta!.run(api)}>{st.cta.label}</Btn>
        )}
        <div className="mt-3 flex items-center gap-2">
          <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-silver-100"><div className="h-full rounded-full bg-brand-600 transition-all" style={{ width: `${(idx / total) * 100}%` }} /></div>
          <span className="text-[11px] font-semibold text-ink-500">{idx}/{total}</span>
        </div>
        <div className="mt-3 flex justify-between gap-2">
          <Btn size="sm" variant="ghost" icon={<ArrowLeft className="h-4 w-4" />} onClick={t.back} disabled={idx === 1}>Back</Btn>
          <Btn size="sm" variant="dark" onClick={t.next}>{idx === total ? 'Finish' : 'Next'} <ArrowRight className="h-4 w-4" /></Btn>
        </div>
      </div>
    </>
  )
}

// ------------------------------------------------------------------ picker
export function ScenarioPicker() {
  const { ui, setUi } = useStore()
  const t = useTour()
  return (
    <Modal open={ui.scenarioPicker} onClose={() => setUi({ scenarioPicker: false })} title="Try a scenario" wide>
      <p className="mb-4 text-sm text-ink-500">Each scenario walks you through one real dealership situation, step by step. Press <b>Next</b> to move along; buttons in the guide can do the clicking for you. All data is made up and nothing is ever sent.</p>
      <button onClick={() => t.start(SCENARIOS.map((x) => x.id))} className="mb-3 flex w-full items-center gap-4 rounded-2xl bg-brand-600 p-4 text-left text-white shadow-lg shadow-brand-600/20 hover:bg-brand-700">
        <PlayCircle className="h-9 w-9 shrink-0" />
        <div>
          <div className="text-[15px] font-extrabold">Start the full guided demo</div>
          <div className="text-[12.5px] text-white/85">All 5 scenarios in a row — about 5 minutes.</div>
        </div>
      </button>
      <div className="grid gap-2 sm:grid-cols-2">
        {SCENARIOS.map((sc) => {
          const I = sc.icon
          return (
            <button key={sc.id} onClick={() => t.start([sc.id])} className="flex gap-3 rounded-xl border border-silver-200 p-3 text-left transition hover:border-brand-600 hover:bg-brand-50/40">
              <I className="mt-0.5 h-5 w-5 shrink-0 text-brand-600" />
              <div>
                <div className="text-[13.5px] font-bold">{sc.title}</div>
                <div className="text-[12px] leading-snug text-ink-500">{sc.plain}</div>
              </div>
            </button>
          )
        })}
      </div>
    </Modal>
  )
}

// ------------------------------------------------------------------ quick actions
export function useQuickActions() {
  const api = useStore()
  const t = useTour()
  return {
    guided: () => api.setUi({ scenarioPicker: true }),
    busyMonday: () => {
      api.act((s, c) => {
        s.now = `${dateOf(s.now)}T10:15`
        s.offHoursOverride = 'auto'
        for (let i = 0; i < 5; i++) simulateLead(s, { toast: () => undefined }, i)
        simulateMissedCall(s, { toast: () => undefined })
        c.toast('Busy Monday simulated: 5 new inquiries from the website, Facebook, OfferUp, email and a walk-in, plus 1 missed call. (Made-up data.)', 'warn')
      })
      api.nav('dashboard')
    },
    asOwner: () => {
      api.act((s, c) => { s.role = 'owner'; c.toast('Viewing as Owner — you can see and approve everything.', 'info') })
      api.nav('dashboard')
    },
    savesTime: () => {
      api.nav('dashboard')
      setTimeout(() => document.querySelector('[data-tour="before-after"]')?.scrollIntoView({ behavior: 'smooth', block: 'start' }), 250)
    },
    proposal: () => {
      api.act((s) => { s.role = 'owner' })
      api.setUi({ proposal: true })
    },
    website: () => api.go('/'),
    cars: () => api.nav('listings'),
    tour: t,
  }
}

export function DemoControls() {
  const { s, act, reset } = useStore()
  const q = useQuickActions()
  const night = s.now.endsWith('T20:45')
  const items: { label: string; icon: React.ElementType; on: () => void; primary?: boolean }[] = [
    { label: 'Start guided demo', icon: PlayCircle, on: q.guided, primary: true },
    { label: 'See Customer Website', icon: Globe, on: q.website },
    { label: 'Manage Cars', icon: Car, on: q.cars },
    { label: 'Simulate a busy Monday', icon: Zap, on: q.busyMonday },
    { label: 'Try as owner', icon: UserCheck, on: q.asOwner },
    { label: 'See how it saves time', icon: Clock, on: q.savesTime },
    { label: 'Generate pilot proposal', icon: FileText, on: q.proposal },
  ]
  return (
    <div className="scroll-thin flex items-center gap-2 overflow-x-auto border-t border-silver-100 bg-silver-50/80 px-4 py-2" data-tour="demo-bar">
      <span className="shrink-0 text-[11px] font-bold uppercase tracking-wider text-ink-400">Try a scenario</span>
      {items.map((it) => {
        const I = it.icon
        return (
          <button key={it.label} onClick={it.on} className={cx('inline-flex h-8 shrink-0 items-center gap-1.5 rounded-full px-3 text-[12.5px] font-semibold transition', it.primary ? 'bg-brand-600 text-white hover:bg-brand-700' : 'border border-silver-200 bg-white text-ink-700 hover:border-brand-600 hover:text-brand-700')}>
            <I className="h-3.5 w-3.5" />{it.label}
          </button>
        )
      })}
      <span className="mx-1 h-5 w-px shrink-0 bg-silver-200" />
      <button onClick={() => act((st, c) => { st.now = `${dateOf(st.now)}T${night ? '11:20' : '20:45'}`; c.toast(night ? 'Demo clock: 11:20 AM (open).' : 'Demo clock: 8:45 PM (after hours). The AI now answers as "closed" and offers next open times.', 'info') })} className="inline-flex h-8 shrink-0 items-center gap-1.5 rounded-full border border-silver-200 bg-white px-3 text-[12.5px] font-semibold text-ink-700 hover:border-ink-400" title="Switch the demo clock">
        {night ? <Sun className="h-3.5 w-3.5" /> : <Moon className="h-3.5 w-3.5" />}{night ? 'Daytime' : 'After hours'}
      </button>
      <button onClick={reset} className="inline-flex h-8 shrink-0 items-center gap-1.5 rounded-full px-3 text-[12.5px] font-semibold text-ink-500 hover:text-ink-900"><RotateCcw className="h-3.5 w-3.5" />Reset</button>
    </div>
  )
}

// ------------------------------------------------------------------ toasts
const TOAST_TONE: Record<Toast['kind'], string> = {
  demo: 'border-amber-300 bg-amber-50 text-amber-950',
  ok: 'border-emerald-200 bg-white text-ink-900',
  warn: 'border-amber-200 bg-white text-ink-900',
  info: 'border-silver-200 bg-white text-ink-900',
}
export function Toasts() {
  const { toasts, dismiss } = useStore()
  return (
    <div className="pointer-events-none fixed right-3 top-3 z-[100] flex w-[min(92vw,380px)] flex-col gap-2" aria-live="polite">
      {toasts.map((t) => (
        <div key={t.id} className={cx('rise pointer-events-auto flex items-start gap-2 rounded-xl border px-3.5 py-2.5 text-[13px] shadow-lg', TOAST_TONE[t.kind])}>
          {t.kind === 'demo' ? <span className="mt-px shrink-0 rounded bg-amber-400 px-1 text-[10px] font-black text-amber-950">DEMO</span> : <CheckCircle2 className={cx('mt-0.5 h-4 w-4 shrink-0', t.kind === 'warn' ? 'text-amber-600' : t.kind === 'ok' ? 'text-emerald-600' : 'text-ink-400')} />}
          <span className="flex-1 leading-snug">{t.text}</span>
          <button onClick={() => dismiss(t.id)} className="text-ink-400 hover:text-ink-900" aria-label="Dismiss"><X className="h-3.5 w-3.5" /></button>
        </div>
      ))}
    </div>
  )
}
