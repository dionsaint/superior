import type { DataState, Deal, DealDoc, Lead, Member, Vehicle, Wall } from './types'
import { addMin, mondayOfThisWeek } from './time'

export const DATA_VERSION = 6

export const MEMBERS: Member[] = [
  { id: 'owner', label: 'Owner', role: 'Owner / GM', initials: 'OW', color: 'bg-slate-800' },
  { id: 's1', label: 'Salesperson A', role: 'Sales', initials: 'SA', color: 'bg-blue-600' },
  { id: 's2', label: 'Salesperson B', role: 'Sales', initials: 'SB', color: 'bg-indigo-500' },
  { id: 'admin', label: 'Admin / Title', role: 'Admin, title & inventory', initials: 'AT', color: 'bg-teal-600' },
]

export const PHOTO_SHOTS = [
  'Front 3/4 (driver side)',
  'Side profile (driver)',
  'Rear 3/4',
  'Rear',
  'Front',
  'Side profile (passenger)',
  'Dashboard & odometer',
  'Front seats',
  'Rear seats',
  'Cargo / bed',
  'Wheels & tires',
  'Engine bay',
  'Center console',
  'Infotainment screen',
  'Door panel',
  'Headliner / sunroof',
  'Spare tire & tools',
  'Keys',
  'Window sticker / Buyers Guide',
  'Detail close-up',
]

export const COLOR_HEX: Record<string, string> = {
  'Celestial Silver': '#b9bec6', 'Modern Steel': '#5c636c', 'Gun Metallic': '#6c7178', 'Summit White': '#f2f3f5',
  'Polar White': '#f4f5f7', 'Agate Black': '#22252b', 'Magnetic Gray': '#6f747a', 'Quartz White': '#eeefef',
  'Mosaic Black': '#1e2126', 'Snow White Pearl': '#f6f6f4', 'Mineral Gray': '#5d636b', 'Blue Velvet': '#2b3f6b',
  'Flame Red': '#b3181f', 'Super Black': '#17191d',
}

type VSeed = {
  id: string; stock: string; year: number; make: string; model: string; trim: string; body: Vehicle['body']; vin: string
  price: number | null; mileage: number | null; photos: number; description: string; daysOnLot: number
  status: Vehicle['status']; color: string; engine: string; transmission: string; drivetrain: string; mpg?: string
  dmsVin?: string; dmsTrim?: string; dmsStatus?: Vehicle['status']; duplicateOf?: string; notes?: string; title?: string
}

const desc = (s: string) => s

// Real example photos (Unsplash License — free to use). They show a similar vehicle, NOT the actual car for sale.
export const EXAMPLE_PHOTOS: Record<string, { id: string; by: string }> = {
  v01: { id: '1621007947382-bb3c3994e3fb', by: 'Kevin Bonilla' },
  v02: { id: '1623597780975-38ccd5030c83', by: 'Kushan Pancholi' },
  v03: { id: '1757922589576-129377dadac9', by: 'Michail Dementiev' },
  v04: { id: '1781574778174-3f4f0efd6e2c', by: 'Kenny Perez' },
  v05: { id: '1623869675781-80aa31012a5a', by: 'Bestami Sarıkaya' },
  v06: { id: '1612563893490-d86ed296e5e6', by: 'serjan midili' },
  v07: { id: '1645830102962-f2716eed466d', by: 'Hill Country Camera' },
  v08: { id: '1783184439860-a71a4c286438', by: 'Wasif Ali' },
  v09: { id: '1598248691267-4a62dfdfd8a8', by: 'Erik Mclean' },
  v10: { id: '1765863238259-2ccdba6a881e', by: 'Trac Vu' },
  v11: { id: '1582475186343-f25aa92e3be3', by: 'Urte Juskauskaite' },
  v12: { id: '1600191762849-bf8fd13e9dc0', by: 'Arvid Skywalker' },
  v13: { id: '1559416523-140ddc3d238c', by: 'Dusty Barnes' },
  v14: { id: '1591738802175-709fedef8288', by: 'Talia' },
  v15: { id: '1718903502278-f81c5a754294', by: 'Austris Augusts' },
  v16: { id: '1598248691267-4a62dfdfd8a8', by: 'Erik Mclean' },
}
export const HERO_PHOTO = { id: '1630165356623-266076eaceb6', by: 'Sara Kurfeß' }
export const unsplash = (id: string, w = 1200) => `https://images.unsplash.com/photo-${id}?auto=format&fit=crop&w=${w}&q=70`

let BASE = '2026-01-05'
const veh = (v: VSeed): Vehicle => {
  const listed = v.description.match(/(?:lists|record:?) ([^.]+)\./i)?.[1] ?? ''
  const features = listed ? listed.split(/,\s*|\s+and\s+/).map((x) => x.trim()).filter(Boolean) : []
  const acq = addMin(`${BASE}T09:00`, -v.daysOnLot * 1440).slice(0, 10)
  const { photos, notes, title, ...rest } = v
  return {
    ...rest,
    photos: PHOTO_SHOTS.slice(0, photos).map((shot, i) => ({ id: `${v.id}-p${i}`, shot })),
    features,
    conditionNotes: notes ?? '',
    disclosure: 'Warranty / As-Is status: shown on the FTC Buyers Guide on the vehicle — confirm with dealer.',
    titleStatus: title ?? 'Title in hand (staff-entered, demo)',
    fuel: 'Gasoline',
    acquired: acq,
    cost: v.price ? Math.round(v.price * 0.78 / 50) * 50 : 9800,
    prepCost: 350 + ((v.year * 37) % 9) * 110,
    listing: 'published',
    colorHex: COLOR_HEX[v.color] ?? '#9aa1aa',
    assignedTo: 'admin',
    updatedAt: `${BASE}T09:00`,
    syncState: 'synced',
  }
}

export const seedVehicles = (base: string): Vehicle[] => { BASE = base; return [
  veh({ id: 'v01', stock: 'D2401', year: 2019, make: 'Toyota', model: 'Camry', trim: 'SE', body: 'Sedan', vin: 'DEMO0TOYCAMRY0001', price: 18995, mileage: 61240, photos: 24, description: desc('2019 Toyota Camry SE in Celestial Silver with a 2.5L 4-cylinder and 8-speed automatic. Front-wheel drive. Listed features per dealer record: backup camera, Bluetooth, cloth sport seats.'), daysOnLot: 18, status: 'available', color: 'Celestial Silver', engine: '2.5L I4', transmission: '8-speed automatic', drivetrain: 'FWD', mpg: '29 city / 41 hwy (EPA est.)', notes: 'Dealer note (demo): light scratch on rear bumper — see photo slot 4.' }),
  veh({ id: 'v02', stock: 'D2402', year: 2018, make: 'Honda', model: 'CR-V', trim: 'EX', body: 'SUV', vin: 'DEMO0HONCRV000002', price: 19750, mileage: 74810, photos: 21, description: desc('2018 Honda CR-V EX, Modern Steel Metallic, 1.5L turbo 4-cylinder with CVT and all-wheel drive. Dealer record lists sunroof, heated front seats and Apple CarPlay.'), daysOnLot: 27, status: 'available', color: 'Modern Steel', engine: '1.5L turbo I4', transmission: 'CVT', drivetrain: 'AWD', mpg: '27 city / 33 hwy (EPA est.)' }),
  veh({ id: 'v03', stock: 'D2403', year: 2017, make: 'Nissan', model: 'Rogue', trim: 'SV', body: 'SUV', vin: 'DEMO0NISROGUE0003', price: null, mileage: null, photos: 14, description: desc('2017 Nissan Rogue SV in Gun Metallic. 2.5L 4-cylinder, CVT, front-wheel drive. Dealer record lists push-button start, rear camera and roof rails.'), daysOnLot: 44, status: 'available', color: 'Gun Metallic', engine: '2.5L I4', transmission: 'CVT', drivetrain: 'FWD', mpg: '26 city / 33 hwy (EPA est.)' }),
  veh({ id: 'v04', stock: 'D2404', year: 2020, make: 'Chevrolet', model: 'Silverado 1500', trim: 'LT Crew Cab', body: 'Truck', vin: 'DEMO0CHVSILV00004', price: 31490, mileage: 58300, photos: 28, description: desc('2020 Chevrolet Silverado 1500 LT Crew Cab, Summit White, 5.3L V8 with 8-speed automatic and 4WD. Dealer record lists trailering package and 20-inch wheels.'), daysOnLot: 9, status: 'available', color: 'Summit White', engine: '5.3L V8', transmission: '8-speed automatic', drivetrain: '4WD', notes: 'Dealer note (demo): bedliner installed by previous owner.' }),
  veh({ id: 'v05', stock: 'D2405', year: 2016, make: 'Mercedes-Benz', model: 'C 300', trim: 'Sedan', body: 'Sedan', vin: 'DEMO0MBC30000005', price: 16900, mileage: 82115, photos: 19, description: desc('2016 Mercedes-Benz C 300 Sedan in Polar White with a 2.0L turbo 4-cylinder and 7-speed automatic, rear-wheel drive. Dealer record lists navigation and leather-style seating.'), daysOnLot: 63, status: 'available', color: 'Polar White', engine: '2.0L turbo I4', transmission: '7-speed automatic', drivetrain: 'RWD' }),
  veh({ id: 'v06', stock: 'D2406', year: 2019, make: 'Ford', model: 'Escape', trim: 'SE', body: 'SUV', vin: 'DEMO0FRDESC00006', price: 13995, mileage: 79020, photos: 17, description: desc('2019 Ford Escape SE, Agate Black, 1.5L EcoBoost 4-cylinder, 6-speed automatic, front-wheel drive. Dealer record lists SYNC 3 and a power liftgate.'), daysOnLot: 35, status: 'available', color: 'Agate Black', engine: '1.5L turbo I4', transmission: '6-speed automatic', drivetrain: 'FWD' }),
  veh({ id: 'v07', stock: 'D2407', year: 2015, make: 'Ford', model: 'F-150', trim: 'XLT', body: 'Truck', vin: 'DEMO0FRDF15000007', price: 21500, mileage: 109400, photos: 2, description: desc('Nice truck. Call today!'), daysOnLot: 52, status: 'available', color: 'Magnetic Gray', engine: '3.5L V6 EcoBoost', transmission: '6-speed automatic', drivetrain: '4WD' }),
  veh({ id: 'v08', stock: 'D2408', year: 2018, make: 'Hyundai', model: 'Sonata', trim: 'SEL', body: 'Sedan', vin: 'DEMO0HYNSON00008', price: 12450, mileage: 68770, photos: 16, description: desc('2018 Hyundai Sonata SEL in Quartz White, 2.4L 4-cylinder with 6-speed automatic, front-wheel drive. Dealer record lists blind-spot monitoring and heated seats.'), daysOnLot: 22, status: 'available', color: 'Quartz White', engine: '2.4L I4', transmission: '6-speed automatic', drivetrain: 'FWD', mpg: '25 city / 35 hwy (EPA est.)' }),
  veh({ id: 'v09', stock: 'D2409', year: 2018, make: 'Chevrolet', model: 'Equinox', trim: 'LT', body: 'SUV', vin: 'DEMO0CHVEQX00009', price: 14800, mileage: 71360, photos: 18, description: desc('2018 Chevrolet Equinox LT in Mosaic Black, 1.5L turbo 4-cylinder, 6-speed automatic, front-wheel drive. Dealer record lists remote start and a 7-inch touchscreen.'), daysOnLot: 71, status: 'pending', color: 'Mosaic Black', engine: '1.5L turbo I4', transmission: '6-speed automatic', drivetrain: 'FWD' }),
  veh({ id: 'v10', stock: 'D2410', year: 2021, make: 'Kia', model: 'Soul', trim: 'LX', body: 'Hatchback', vin: 'DEMO0KIASOUL0010', price: 15250, mileage: 39880, photos: 20, description: desc('2021 Kia Soul LX in Snow White Pearl with a 2.0L 4-cylinder and IVT automatic, front-wheel drive. Dealer record lists Android Auto, Apple CarPlay and lane keeping assist.'), daysOnLot: 14, status: 'available', color: 'Snow White Pearl', engine: '2.0L I4', transmission: 'IVT automatic', drivetrain: 'FWD', mpg: '29 city / 35 hwy (EPA est.)' }),
  veh({ id: 'v11', stock: 'D2411', year: 2017, make: 'BMW', model: '330i', trim: 'xDrive', body: 'Sedan', vin: 'DEMO0BMW33000011', dmsVin: 'DEMO0BMW33000111', dmsTrim: 'Base (RWD)', price: 17995, mileage: 77450, photos: 22, description: desc('2017 BMW 330i in Mineral Gray, 2.0L turbo 4-cylinder with 8-speed automatic. Dealer record lists heated seats, navigation and a sunroof.'), daysOnLot: 39, status: 'available', color: 'Mineral Gray', engine: '2.0L turbo I4', transmission: '8-speed automatic', drivetrain: 'AWD' }),
  veh({ id: 'v12', stock: 'D2412', year: 2016, make: 'Chevrolet', model: 'Malibu', trim: 'LT', body: 'Sedan', vin: 'DEMO0CHVMAL00012', dmsStatus: 'sold', price: 9995, mileage: 96210, photos: 15, description: desc('2016 Chevrolet Malibu LT in Blue Velvet, 1.5L turbo 4-cylinder with 6-speed automatic, front-wheel drive. Dealer record lists rear camera and Bluetooth audio.'), daysOnLot: 118, status: 'available', color: 'Blue Velvet', engine: '1.5L turbo I4', transmission: '6-speed automatic', drivetrain: 'FWD' }),
  veh({ id: 'v13', stock: 'D2413', year: 2019, make: 'Toyota', model: 'Tacoma', trim: 'SR5 Double Cab', body: 'Truck', vin: 'DEMO0TOYTAC00013', price: 27900, mileage: 66540, photos: 26, description: desc('2019 Toyota Tacoma SR5 Double Cab, Magnetic Gray, 3.5L V6, 6-speed automatic, 4WD. Dealer record lists tow package, backup camera and bed liner.'), daysOnLot: 11, status: 'pending', color: 'Magnetic Gray', engine: '3.5L V6', transmission: '6-speed automatic', drivetrain: '4WD' }),
  veh({ id: 'v14', stock: 'D2414', year: 2014, make: 'Jeep', model: 'Wrangler Unlimited', trim: 'Sport', body: 'SUV', vin: 'DEMO0JEPWRG00014', dmsStatus: 'pending', price: null, mileage: 121300, photos: 12, description: desc('2014 Jeep Wrangler Unlimited Sport, Flame Red, 3.6L V6 with 5-speed automatic and 4WD. Dealer record lists removable hardtop and tow hitch.'), daysOnLot: 58, status: 'unclear', color: 'Flame Red', engine: '3.6L V6', transmission: '5-speed automatic', drivetrain: '4WD', title: 'Awaiting title from prior lienholder (demo)' }),
  veh({ id: 'v15', stock: 'D2415', year: 2020, make: 'Nissan', model: 'Altima', trim: '2.5 S', body: 'Sedan', vin: 'DEMO0NISALT00015', price: 15990, mileage: 54320, photos: 18, description: desc('2020 Nissan Altima 2.5 S in Super Black, 2.5L 4-cylinder with Xtronic CVT, front-wheel drive. Dealer record lists automatic emergency braking and Apple CarPlay.'), daysOnLot: 86, status: 'available', color: 'Super Black', engine: '2.5L I4', transmission: 'CVT', drivetrain: 'FWD', mpg: '28 city / 39 hwy (EPA est.)' }),
  veh({ id: 'v16', stock: 'D2416', year: 2018, make: 'Chevrolet', model: 'Equinox', trim: 'LT', body: 'SUV', vin: 'DEMO0CHVEQX00009', duplicateOf: 'v09', price: 14800, mileage: 71360, photos: 9, description: desc('2018 Chevrolet Equinox LT in Mosaic Black, 1.5L turbo 4-cylinder, 6-speed automatic, front-wheel drive. Remote start and touchscreen per dealer record.'), daysOnLot: 6, status: 'available', color: 'Mosaic Black', engine: '1.5L turbo I4', transmission: '6-speed automatic', drivetrain: 'FWD' }),
]}

const mk = (base: string, minutes: number): Wall => addMin(`${base}T11:20`, minutes)

export const seedLeads = (base: string): Lead[] => {
  const t = (m: number) => mk(base, m)
  const L = (l: Partial<Lead> & Pick<Lead, 'id' | 'name' | 'source'>): Lead => ({
    kind: 'inquiry',
    phone: '(727) 555-01' + l.id.slice(-2),
    email: l.name.split(' ')[0].toLowerCase() + '@example.com',
    vehicleId: null,
    budget: null,
    tradeIn: null,
    channel: 'sms',
    assignedTo: null,
    stage: 'new',
    consent: { sms: false, email: true, call: true, source: 'Web form checkbox', at: t(-120), stopped: false },
    urgency: 'med',
    nextAction: 'Respond',
    createdAt: t(-60),
    messages: [],
    automationPaused: false,
    humanTakeover: false,
    missed: false,
    callbackRequested: false,
    autoSentToday: 0,
    draft: null,
    ...l,
  })
  return [
    L({ id: 'l01', name: 'Marcus T.', source: 'website', vehicleId: 'v04', budget: 'Up to $32k', tradeIn: '2012 F-150 (customer-stated)', urgency: 'high', missed: true, createdAt: t(-14 * 60 - 20), nextAction: 'Reply — waiting since last night', consent: { sms: true, email: true, call: true, source: 'Website form — SMS opt-in checkbox', at: t(-14 * 60 - 20), stopped: false }, messages: [{ id: 'm1', from: 'customer', text: 'Is the white Silverado still there? Could I see it Saturday?', at: t(-14 * 60 - 20) }] }),
    L({ id: 'l02', name: 'Alicia R.', source: 'facebook', vehicleId: 'v02', urgency: 'high', missed: true, createdAt: t(-5 * 60), channel: 'sms', nextAction: 'Reply on Marketplace (manual)', consent: { sms: false, email: false, call: false, source: 'Marketplace message — no SMS opt-in', at: null, stopped: false }, messages: [{ id: 'm2', from: 'customer', text: 'Hi is this CR-V available? What are the miles?', at: t(-5 * 60) }] }),
    L({ id: 'l03', name: 'Dev P.', source: 'email', vehicleId: 'v10', budget: '$250/mo (customer-stated)', urgency: 'med', missed: true, createdAt: t(-3 * 60 - 10), channel: 'email', nextAction: 'Reply by email', messages: [{ id: 'm3', from: 'customer', text: 'Do you have the 2021 Soul in stock? I need something reliable for commuting.', at: t(-3 * 60 - 10) }] }),
    L({ id: 'l04', name: 'Tanya W.', source: 'phone', vehicleId: 'v13', urgency: 'high', callbackRequested: true, createdAt: t(-50), channel: 'phone', nextAction: 'Call back — requested', consent: { sms: false, email: false, call: true, source: 'Voicemail — asked for a call back', at: t(-50), stopped: false }, messages: [{ id: 'm4', from: 'system', text: 'Voicemail (synthetic transcript): "Calling about the Tacoma. Please call me back after 1."', at: t(-50) }] }),
    L({ id: 'l05', name: 'Luis G.', source: 'website', vehicleId: 'v01', assignedTo: 's1', stage: 'contacted', createdAt: t(-26 * 60), urgency: 'med', nextAction: 'Approve follow-up draft', consent: { sms: true, email: true, call: true, source: 'Website form — SMS opt-in checkbox', at: t(-26 * 60), stopped: false }, draft: 'Hi Luis, this is the Superior Auto Mall assistant (AI). The 2019 Camry SE you asked about shows 61,240 miles in our record. Would Tuesday at 2:00 PM or Wednesday at 11:00 AM work for a test drive? Reply STOP to opt out.', messages: [{ id: 'm5', from: 'customer', text: 'What are the miles on the silver Camry?', at: t(-26 * 60) }, { id: 'm6', from: 'staff', text: 'Hi Luis — thanks for reaching out! Checking on that for you now.', at: t(-25 * 60), status: 'sent-demo' }] }),
    L({ id: 'l06', name: 'Brianna K.', source: 'offerup', vehicleId: 'v08', assignedTo: 's2', stage: 'contacted', createdAt: t(-30 * 60), channel: 'sms', urgency: 'low', nextAction: 'Approve follow-up draft', consent: { sms: true, email: false, call: true, source: 'Texted dealership first (inbound) — staff verified', at: t(-30 * 60), stopped: false }, draft: 'Hi Brianna, following up on the 2018 Sonata. Happy to hold a test-drive time for you — Thursday at 3:00 PM work? Reply STOP to opt out. (AI assistant)', messages: [{ id: 'm7', from: 'customer', text: 'Still available? Can I come by this week?', at: t(-30 * 60) }, { id: 'm8', from: 'staff', text: 'Yes — what day works best?', at: t(-29 * 60), status: 'sent-demo' }] }),
    L({ id: 'l07', name: 'Omar S.', source: 'walkin', vehicleId: 'v06', assignedTo: 's1', stage: 'appointment', createdAt: t(-2 * 1440), channel: 'phone', nextAction: 'Test drive today 2:00 PM', consent: { sms: true, email: true, call: true, source: 'In-store consent form (paper) — staff entered', at: t(-2 * 1440), stopped: false }, messages: [{ id: 'm9', from: 'system', text: 'Walk-in logged by Salesperson A. Interested in Escape; returning for test drive.', at: t(-2 * 1440) }] }),
    L({ id: 'l08', name: 'Hannah L.', source: 'website', vehicleId: 'v15', assignedTo: 's2', stage: 'appointment', createdAt: t(-1440 - 60), nextAction: 'Test drive tomorrow 11:00 AM', consent: { sms: true, email: true, call: true, source: 'Website form — SMS opt-in checkbox', at: t(-1440 - 60), stopped: false }, messages: [{ id: 'm10', from: 'customer', text: 'Can I test drive the Altima tomorrow morning?', at: t(-1440 - 60) }, { id: 'm11', from: 'staff', text: 'Booked you for 11:00 AM tomorrow. See you then!', at: t(-1440 - 30), status: 'sent-demo' }] }),
    L({ id: 'l09', name: 'Chris D.', source: 'phone', vehicleId: 'v05', assignedTo: 's1', stage: 'negotiating', createdAt: t(-3 * 1440), channel: 'phone', nextAction: 'Owner to review offer', consent: { sms: false, email: true, call: true, source: 'Phone — verbal, logged by staff', at: t(-3 * 1440), stopped: false }, messages: [{ id: 'm12', from: 'system', text: 'Customer made an offer on the C 300 in person. Owner review needed.', at: t(-1440) }] }),
    L({ id: 'l10', name: 'Renee F.', source: 'email', vehicleId: 'v11', assignedTo: 's2', stage: 'negotiating', createdAt: t(-4 * 1440), channel: 'email', nextAction: 'Send revised numbers (staff)', messages: [{ id: 'm13', from: 'customer', text: 'Can you confirm the BMW is AWD before I come in?', at: t(-2 * 1440) }] }),
    L({ id: 'l11', name: 'Jamal B.', source: 'website', vehicleId: 'v09', assignedTo: 's1', stage: 'sold', createdAt: t(-6 * 1440), nextAction: 'Post-sale check-in (staff)', consent: { sms: true, email: true, call: true, source: 'Website form — SMS opt-in checkbox', at: t(-6 * 1440), stopped: false } }),
    L({ id: 'l12', name: 'Kim N.', source: 'facebook', vehicleId: 'v07', assignedTo: 's2', stage: 'lost', createdAt: t(-9 * 1440), nextAction: '—', consent: { sms: false, email: false, call: false, source: 'Marketplace message — no opt-in', at: null, stopped: true }, messages: [{ id: 'm14', from: 'customer', text: 'STOP', at: t(-8 * 1440) }, { id: 'm15', from: 'system', text: 'Opt-out recorded. Automation disabled for this contact.', at: t(-8 * 1440) }] }),
  ]
}

const DOCS = (o: Partial<Record<string, Partial<DealDoc>>> = {}): DealDoc[] => {
  const base: DealDoc[] = [
    { key: 'buyers_order', label: "Buyer's order", status: 'complete', owner: 's1', applicable: true },
    { key: 'buyers_guide', label: 'FTC Buyers Guide', status: 'complete', owner: 'admin', applicable: true },
    { key: 'odometer', label: 'Odometer disclosure', status: 'complete', owner: 'admin', applicable: true },
    { key: 'title', label: 'Title transfer packet', status: 'pending', owner: 'admin', applicable: true },
    { key: 'insurance', label: 'Proof of insurance', status: 'complete', owner: 's1', applicable: true },
    { key: 'stips', label: 'Lender stipulations', status: 'na', owner: 'admin', applicable: false },
    { key: 'delivery', label: 'Delivery receipt', status: 'pending', owner: 's1', applicable: true },
  ]
  return base.map((d) => ({ ...d, ...(o[d.key] || {}) }))
}

const SAMPLE_ORDER = (name: string, veh: string, sig: boolean, odo: string) => `SAMPLE BUYER'S ORDER — SYNTHETIC DEMO TEXT (not a real form)
Dealer: Superior Auto Mall (demo)        Deal #: ____
Buyer: ${name}
Vehicle: ${veh}
Odometer reading at sale: ${odo}
Cash price: [see DMS]      Trade allowance: [see DMS]
Buyers Guide displayed & provided: ☑
Buyer signature: ${sig ? '/s/ ' + name : '______________________'}
Co-buyer signature (if any): N/A
Dealer representative: /s/ Sales (demo)`

export const seedDeals = (base: string): Deal[] => {
  const t = (m: number) => mk(base, m)
  const D = (d: Omit<Deal, 'aiChecked' | 'pendingRequest' | 'summary'>): Deal => ({ aiChecked: false, pendingRequest: null, summary: null, ...d })
  return [
    D({ id: 'd1', number: '#1042', customer: 'Jamal B.', vehicleLabel: '2018 Chevrolet Equinox LT', stage: 'delivery', salesperson: 's1', docs: DOCS({ delivery: { status: 'pending' }, title: { status: 'pending' } }), events: [{ at: t(-3 * 1440), text: 'Deal created in DMS (synthetic record)', who: 'Salesperson A' }, { at: t(-2 * 1440), text: 'Checklist marked complete by staff', who: 'Salesperson A' }, { at: t(-1440), text: 'Moved to Delivery ready', who: 'Salesperson A' }], waitingDays: 1, waitingFor: 'Delivery appointment', depositFlag: true, sampleDocText: SAMPLE_ORDER('Jamal B.', '2018 Chevrolet Equinox LT · Stock D2409', false, '71,360') }),
    D({ id: 'd2', number: '#1039', customer: 'Luis G. (prior)', vehicleLabel: '2019 Toyota Tacoma SR5', stage: 'title', salesperson: 's2', docs: DOCS({ insurance: { status: 'missing', note: 'Insurance card not in file' }, title: { status: 'pending', note: 'Packet assembled — awaiting owner review' } }), events: [{ at: t(-6 * 1440), text: 'Deal funded (synthetic)', who: 'Admin / Title' }, { at: t(-4 * 1440), text: 'Title packet assembled', who: 'Admin / Title' }], waitingDays: 4, waitingFor: 'Title packet waiting for owner review', depositFlag: true, sampleDocText: SAMPLE_ORDER('Luis G.', '2019 Toyota Tacoma SR5 · Stock D2413', true, '66,540') }),
    D({ id: 'd3', number: '#1046', customer: 'Kim N. (new)', vehicleLabel: '2021 Kia Soul LX', stage: 'deposit', salesperson: 's2', docs: DOCS({ buyers_order: { status: 'pending' }, odometer: { status: 'pending' }, insurance: { status: 'pending' } }), events: [{ at: t(-90), text: 'Deposit flag set (demo — no payment processed)', who: 'Salesperson B' }], waitingDays: 0, waitingFor: 'Paperwork appointment', depositFlag: true, sampleDocText: SAMPLE_ORDER('Kim N.', '2021 Kia Soul LX · Stock D2410', true, '39,880') }),
    D({ id: 'd4', number: '#1044', customer: 'Chris D.', vehicleLabel: '2016 Mercedes-Benz C 300', stage: 'financing', salesperson: 's1', docs: DOCS({ buyers_order: { status: 'pending' }, stips: { status: 'pending', applicable: true } }), events: [{ at: t(-1440), text: 'Submitted to lender by staff (outside this tool)', who: 'Owner' }], waitingDays: 1, waitingFor: 'Lender decision (handled in DMS/lender portal)', depositFlag: false, sampleDocText: SAMPLE_ORDER('Chris D.', '2016 Mercedes-Benz C 300 · Stock D2405', true, '82,115') }),
    D({ id: 'd5', number: '#1045', customer: 'Renee F.', vehicleLabel: '2017 BMW 330i', stage: 'id', salesperson: 's2', docs: DOCS({ buyers_order: { status: 'pending' } }), events: [{ at: t(-2 * 1440), text: 'ID verification requested in person', who: 'Salesperson B' }], waitingDays: 2, waitingFor: 'ID verification (in person)', depositFlag: false, sampleDocText: SAMPLE_ORDER('Renee F.', '2017 BMW 330i · Stock D2411', true, '77,450') }),
    D({ id: 'd6', number: '#1041', customer: 'Hannah L. (prior)', vehicleLabel: '2020 Chevrolet Silverado 1500', stage: 'stips', salesperson: 's1', docs: DOCS({ stips: { status: 'missing', applicable: true, note: 'Lender stip: proof of residence' } }), events: [{ at: t(-3 * 1440), text: 'Lender returned stipulations (synthetic)', who: 'Admin / Title' }], waitingDays: 3, waitingFor: 'Lender stipulation — proof of residence', depositFlag: true, sampleDocText: SAMPLE_ORDER('Hannah L.', '2020 Chevrolet Silverado · Stock D2404', true, '58,300') }),
    D({ id: 'd7', number: '#1037', customer: 'Omar S. (prior)', vehicleLabel: '2018 Honda CR-V EX', stage: 'signature', salesperson: 's2', docs: DOCS({ buyers_order: { status: 'pending', note: 'Customer to sign at pickup' } }), events: [{ at: t(-1440), text: 'Customer scheduled to sign Thursday', who: 'Salesperson B' }], waitingDays: 1, waitingFor: 'Buyer signature at scheduled visit', depositFlag: true, sampleDocText: SAMPLE_ORDER('Omar S.', '2018 Honda CR-V EX · Stock D2402', false, '74,810') }),
  ]
}

export const seedState = (): DataState => {
  const base = mondayOfThisWeek()
  const now: Wall = `${base}T11:20`
  const t = (m: number) => addMin(now, m)
  return {
    version: DATA_VERSION,
    now,
    role: 'owner',
    theme: 'white',
    dealer: { name: 'Superior Auto Mall', street: '541 34th St S', city: 'St. Petersburg, FL', zip: '', phone: '727-526-8500', dealerFee: null },
    favorites: [],
    compare: [],
    members: MEMBERS,
    vehicles: seedVehicles(base).map((v) => ({ ...v, examplePhoto: EXAMPLE_PHOTOS[v.id] })).map((v) => (v.id === 'v11' ? { ...v, syncState: 'conflict' as const } : v.id === 'v05' ? { ...v, syncState: 'failed' as const } : v)),
    leads: seedLeads(base),
    deals: seedDeals(base),
    promises: [
      { id: 'p1', dealNumber: '#1039', customer: 'Luis G.', vehicle: '2019 Tacoma', item: 'Replace cracked driver-side mirror cap (sample entry)', owner: 'admin', due: 'Fri', status: 'scheduled', sample: true },
      { id: 'p2', dealNumber: '#1041', customer: 'Hannah L.', vehicle: '2020 Silverado', item: 'Second key fob — ordered (sample entry)', owner: 'owner', due: 'Next Tue', status: 'open', sample: true },
      { id: 'p3', dealNumber: '#1036', customer: 'Kim N.', vehicle: '2019 Escape', item: 'Detail interior before pickup (sample entry)', owner: 's2', due: 'Done', status: 'done', sample: true },
    ],
    appointments: [
      { id: 'a1', leadId: 'l07', customer: 'Omar S.', vehicleId: 'v06', start: t(160), duration: 60, salesperson: 's1', notes: 'Returning walk-in. Wants to compare with CR-V.', reminder: 'queued', status: 'booked', kind: 'Test drive' },
      { id: 'a2', leadId: 'l08', customer: 'Hannah L.', vehicleId: 'v15', start: `${addMin(now, 1440).slice(0, 10)}T11:00`, duration: 60, salesperson: 's2', notes: 'Booked via website chat yesterday.', reminder: 'queued', status: 'booked', kind: 'Test drive' },
      { id: 'a3', leadId: null, customer: 'Jamal B.', vehicleId: 'v09', start: `${addMin(now, 2880).slice(0, 10)}T15:00`, duration: 60, salesperson: 's1', notes: 'Delivery — Deal #1042', reminder: 'none', status: 'booked', kind: 'Delivery' },
    ],
    rules: [
      { id: 'r1', name: 'New after-hours lead', trigger: 'New inbound lead', conditions: 'Outside business hours AND channel consent present', action: 'Send AI-identified acknowledgment + offer next 3 open slots', review: 'auto-safe', enabled: true },
      { id: 'r2', name: 'Missed call', trigger: 'Missed inbound call', conditions: 'Caller ID available', action: 'Create callback task, draft callback text', review: 'staff-confirm', enabled: true },
      { id: 'r3', name: 'Test drive tomorrow', trigger: 'Appointment in 24h', conditions: 'SMS consent AND not opted out AND outside quiet hours', action: 'Queue reminder with reschedule link', review: 'auto-safe', enabled: true },
      { id: 'r4', name: 'Missing deal document', trigger: 'Deal checklist item missing', conditions: 'Deal stage past Deposit', action: 'Create task for document owner; draft customer request', review: 'staff-confirm', enabled: true },
      { id: 'r5', name: 'Inventory record missing mileage', trigger: 'Listing scan', conditions: 'Mileage field empty', action: 'Flag listing, create Inventory task', review: 'auto-safe', enabled: true },
      { id: 'r6', name: 'Unanswered inquiry after 4 hours', trigger: 'Lead unanswered', conditions: 'No outbound reply within 4 business hours', action: 'Escalate to Owner + reassign suggestion', review: 'staff-confirm', enabled: true },
    ],
    tasks: [
      { id: 'tk1', title: 'Review offer on C 300 (Chris D.)', owner: 'owner', due: t(100), status: 'todo', link: { screen: 'leads', id: 'l09' }, createdBy: 'staff' },
      { id: 'tk2', title: 'Owner review: title packet Deal #1039', owner: 'owner', due: t(40), status: 'awaiting-approval', link: { screen: 'deals', id: 'd2' }, createdBy: 'ai' },
      { id: 'tk3', title: 'Prep Escape for 2:00 PM test drive', owner: 's1', due: t(120), status: 'in-progress', link: { screen: 'calendar' }, createdBy: 'ai' },
      { id: 'tk4', title: 'Collect proof of residence — Deal #1041', owner: 'admin', due: t(220), status: 'todo', link: { screen: 'deals', id: 'd6' }, createdBy: 'ai' },
      { id: 'tk5', title: 'Verify odometer & price on 2017 Rogue', owner: 'admin', due: t(300), status: 'todo', link: { screen: 'listings', id: 'v03' }, createdBy: 'ai' },
      { id: 'tk6', title: 'Answer AWD question for Renee F.', owner: 's2', due: t(60), status: 'todo', link: { screen: 'leads', id: 'l10' }, createdBy: 'staff' },
    ],
    audit: [
      { id: 'au1', at: t(-180), actor: 'AI (demo)', kind: 'automation', text: 'Overnight listing scan: 6 listings flagged for quality issues', done: true, link: { screen: 'listings' } },
      { id: 'au2', at: t(-150), actor: 'AI (demo)', kind: 'automation', text: 'Reminder queued for Omar S. test drive (not sent — demo)', done: true, link: { screen: 'calendar' } },
      { id: 'au3', at: t(-120), actor: 'AI (demo)', kind: 'suggestion', text: 'Drafted follow-ups for Luis G. and Brianna K. — awaiting approval', done: false, link: { screen: 'leads', id: 'l05' } },
      { id: 'au4', at: t(-90), actor: 'AI (demo)', kind: 'suggestion', text: 'Deal #1039 title packet has waited 4 days — owner review recommended', done: false, link: { screen: 'deals', id: 'd2' } },
      { id: 'au5', at: t(-60), actor: 'AI (demo)', kind: 'automation', text: 'Captured voicemail from Tanya W. and created callback request', done: true, link: { screen: 'leads', id: 'l04' } },
      { id: 'au6', at: t(-30), actor: 'AI (demo)', kind: 'suggestion', text: 'Possible duplicate listing: Stock D2416 matches D2409 VIN', done: false, link: { screen: 'listings', id: 'v16' } },
    ],
    sync: [
      { id: 'sy1', vehicleId: 'v11', label: 'VIN', before: 'DMS: DEMO0BMW33000111', after: 'Website: DEMO0BMW33000011', target: 'Dealer Car Search / DMS', at: t(-200), state: 'conflict' },
      { id: 'sy2', vehicleId: 'v05', label: 'Photo set (19)', before: '—', after: 'Updated photo order', target: 'Dealer Car Search feed (simulated)', at: t(-400), state: 'failed' },
    ],
    hours: {
      0: null,
      1: { open: '10:00', close: '17:00' },
      2: { open: '10:00', close: '17:00' },
      3: { open: '10:00', close: '17:00' },
      4: { open: '10:00', close: '17:00' },
      5: { open: '10:00', close: '17:00' },
      6: { open: '10:00', close: '16:00' },
    },
    roi: { employees: 4, hourly: 22, burden: 15, hLeads: 12, hScheduling: 5, hListings: 6, hPaperwork: 8, adoption: 50, fee: 499, pLeads: 50, pScheduling: 60, pListings: 55, pPaperwork: 35 },
    quietStart: '21:00',
    quietEnd: '08:00',
    freqCap: 2,
    offHoursOverride: 'auto',
    rrIndex: 0,
    seq: 100,
  }
}
